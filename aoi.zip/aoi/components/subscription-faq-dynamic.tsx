"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

interface FAQItem {
  question: string
  answer: string
  tiers?: string[]
}

const faqsByTier = {
  general: [
    {
      question: "¿Cuál es la diferencia entre suscripción y mecenazgo?",
      answer:
        "La suscripción es un apoyo recurrente mensual que te da acceso continuo a contenido exclusivo, comunidad y beneficios. El mecenazgo es una aportación única para financiar un proyecto específico.",
    },
    {
      question: "¿Puedo cambiar de plan después de suscribirme?",
      answer:
        "Claro. Puedes cambiar de plan, subir o bajar, cuando quieras. El cambio entra en efecto el próximo ciclo de facturación.",
    },
    {
      question: "¿Cómo recibiremos las recompensas?",
      answer:
        "Las recompensas de suscripción se enviarán en cuanto te suscribas. Los enlaces para unirte a Discord se enviarán por correo electrónico una vez te suscribas. Las recompensas de la campaña de Kickstarter se enviarán una vez la campaña tenga éxito.",
    },
  ],
  apoyo: [
    {
      question: "¿Cuál es el beneficio más importante del plan Apoyo?",
      answer:
        "Mantenerte informado. Recibirás actualizaciones mensuales por email sobre el progreso del proyecto, además de descuentos exclusivos en la tienda cuando lancemos nuevas piezas.",
    },
    {
      question: "¿Puedo acceder a los videos del plan Colector?",
      answer:
        "No, los videos exclusivos están disponibles solo para Colector y Mecenas+. Pero como Apoyo recibirás actualizaciones y acceso a descuentos especiales.",
    },
  ],
  colector: [
    {
      question: "¿Cuándo comienzan mis votaciones mensuales?",
      answer:
        "Tus votaciones comienzan el mes siguiente a tu suscripción. Cada mes recibirás opciones sobre qué técnicas o estilos explorar para nuevas piezas.",
    },
    {
      question: "¿Qué incluye la sesión Q&A?",
      answer:
        "Sesiones en vivo donde puedes hacer preguntas directamente a Daniel sobre su proceso creativo, técnicas, experiencias neurodivergentes, y todo lo que se te ocurra.",
    },
    {
      question: "¿Cuándo tengo acceso a la comunidad Discord?",
      answer:
        "Inmediatamente después de confirmar tu suscripción recibirás un enlace exclusivo por correo electrónico. Los enlaces para unirte se enviarán por email una vez te suscribas. Allí podrás conectar con otros coleccionistas y colaboradores.",
    },
    {
      question: "¿Cuánto tardan las piezas hechas a mano?",
      answer:
        "Se calcula de 1 a 2 meses debido al número de apoyantes en el proyecto de Kickstarter. Las cerámicas hechas a mano requieren tiempo y cuidado. Las noticias, fotos y demás actualizaciones siempre se harán por medio de Discord.",
    },
  ],
  mecenas: [
    {
      question: "¿Cuándo recibo mi pieza exclusiva trimestral?",
      answer:
        "Al final de cada trimestre (cada 3 meses) recibirás una pieza cerámica exclusiva y única creada especialmente para el programa Mecenas+. El envío es gratis internacional.",
    },
    {
      question: "¿Puedo influir en qué piezas se crean?",
      answer:
        "Sí. Los Mecenas+ tienen influencia directa sobre decisiones mayores del proyecto. Tus opiniones ayudan a guiar la dirección artística.",
    },
    {
      question: "¿Cómo es el video call privado mensual?",
      answer:
        "Una sesión personalizada de 30 minutos cada mes donde hablas directamente con Daniel. Puedes hablar sobre tu conexión con el arte, hacer preguntas, o simplemente compartir la experiencia.",
    },
    {
      question: "¿Qué pasa si una pieza llega dañada?",
      answer:
        "Si alguna pieza de cerámica llega dañada, simplemente envíame una foto y la reemplazaré. Uso embalaje profesional diseñado para cerámicas frágiles para minimizar este riesgo.",
    },
  ],
}

interface FAQDynamicProps {
  selectedTier?: "apoyo" | "colector" | "mecenas" | null
}

export function SubscriptionFAQDynamic({ selectedTier }: FAQDynamicProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const faqs = selectedTier ? [...faqsByTier.general, ...(faqsByTier[selectedTier] || [])] : faqsByTier.general

  return (
    <section className="py-20 px-6">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-light mb-4">Preguntas Frecuentes</h2>
          {selectedTier && <p className="text-accent font-medium capitalize">Información del plan {selectedTier}</p>}
        </div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="border border-border/50 rounded-lg overflow-hidden hover:border-accent/30 transition-colors"
            >
              <button
                onClick={() => setOpenIndex(openIndex === i ? null : i)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-secondary/30 transition-colors"
              >
                <span className="font-medium text-foreground pr-4">{faq.question}</span>
                <ChevronDown
                  className={`w-5 h-5 text-accent flex-shrink-0 transition-transform duration-200 ${
                    openIndex === i ? "rotate-180" : ""
                  }`}
                />
              </button>

              {openIndex === i && (
                <div className="px-6 pb-6 text-muted-foreground border-t border-border/30 pt-4">{faq.answer}</div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
