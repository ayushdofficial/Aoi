<?php
/**
 * Aoi Cerámica Theme Functions
 */

// Enqueue styles and scripts
function aoi_ceramica_enqueue_scripts() {
    // Google Fonts
    wp_enqueue_style('aoi-fonts', 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600;700&display=swap', array(), null);
    
    // Theme stylesheet
    wp_enqueue_style('aoi-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Theme JavaScript
    wp_enqueue_script('aoi-main-js', get_template_directory_uri() . '/js/main.js', array(), '1.0.0', true);
    
    // Localize script for AJAX
    wp_localize_script('aoi-main-js', 'aoiAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('aoi_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'aoi_ceramica_enqueue_scripts');

// Theme setup
function aoi_ceramica_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'aoi-ceramica'),
    ));
}
add_action('after_setup_theme', 'aoi_ceramica_setup');

// AJAX Handler for Email Capture
function aoi_handle_email_capture() {
    check_ajax_referer('aoi_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    $variant = sanitize_text_field($_POST['variant']);
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Invalid email address'));
        return;
    }
    
    // Here you can integrate with your email service
    // Example: Mailchimp, ConvertKit, etc.
    
    // For now, we'll just save to WordPress options
    $subscribers = get_option('aoi_subscribers', array());
    $subscribers[] = array(
        'email' => $email,
        'variant' => $variant,
        'date' => current_time('mysql')
    );
    update_option('aoi_subscribers', $subscribers);
    
    wp_send_json_success(array('message' => '¡Gracias por unirte!'));
}
add_action('wp_ajax_aoi_email_capture', 'aoi_handle_email_capture');
add_action('wp_ajax_nopriv_aoi_email_capture', 'aoi_handle_email_capture');

// Shortcode for Patreon Link
function aoi_patreon_link($atts) {
    $atts = shortcode_atts(array(
        'text' => 'Únete en Patreon',
        'class' => 'btn btn-primary'
    ), $atts);
    
    return '<a href="https://www.patreon.com/aoi_kitsune" target="_blank" rel="noopener noreferrer" class="' . esc_attr($atts['class']) . '">' . esc_html($atts['text']) . '</a>';
}
add_shortcode('patreon_link', 'aoi_patreon_link');

// Remove WordPress admin bar for clean preview
show_admin_bar(false);
?>
