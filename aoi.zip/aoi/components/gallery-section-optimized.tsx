"use client"
import { useState } from "react"
import { X } from "lucide-react"
import Image from "next/image"

interface Piece {
  id: number
  title: string
  description: string
  image: string
  tags: string[]
}

const pieces: Piece[] = [
  {
    id: 1,
    title: "Kintsugi Bowl - Liquid Gold",
    description: "Ceramic bowl broken and repaired with traditional Japanese kintsugi technique",
    image: "/kintsugi-bowl-gold-ceramic-japanese-repair-art.jpg",
    tags: ["Kintsugi", "Japan", "Gold"],
  },
  {
    id: 2,
    title: "Mexican Artisan Vase",
    description: "Hand-woven vase with Oaxaca clay, naturally finished",
    image: "/mexican-artisan-ceramic-vase-earth-tones-pottery.jpg",
    tags: ["Mexico", "Artisan", "Earth"],
  },
  {
    id: 3,
    title: "Minimalist Vessel",
    description: "Organic form inspired by nature, elegant matte glaze",
    image: "/minimalist-ceramic-vessel-organic-form-sculpture-a.jpg",
    tags: ["Minimalism", "Form", "Art"],
  },
  {
    id: 4,
    title: "Wabi-Sabi Tea Bowl",
    description: "Bowl for tea ceremony with intentional imperfections",
    image: "/wabi-sabi-tea-bowl-japanese-ceramic-imperfection-b.jpg",
    tags: ["Wabi-Sabi", "Japan", "Tea"],
  },
  {
    id: 5,
    title: "Sculptural Planter",
    description: "Combined piece of ceramic and golden metal with live plants",
    image: "/sculptural-ceramic-planter-gold-accents-modern-art.jpg",
    tags: ["Sculpture", "Golden", "Modern"],
  },
  {
    id: 6,
    title: "Interactive Installation",
    description: "Series of fragments united by gold, inviting reflection",
    image: "/ceramic-installation-golden-repair-kintsugi-art-pi.jpg",
    tags: ["Installation", "Kintsugi", "Reflection"],
  },
]

export function GallerySectionOptimized() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null)

  return (
    <>
      <section data-gallery-section className="py-24 px-6 bg-background">
        <div className="max-w-7xl mx-auto">
          <div className="mb-16 text-center">
            <h2 className="text-5xl md:text-6xl font-light mb-6 text-balance">
              Gallery of
              <span className="block text-accent font-medium">Masterpieces</span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Each piece tells a story of transformation, repair and beauty
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pieces.map((piece, index) => (
              <button
                key={piece.id}
                onClick={() => setSelectedImage(index)}
                className="group relative aspect-square rounded-lg overflow-hidden cursor-pointer bg-card border border-accent/10 hover:border-accent/40 transition-all duration-300 hover:shadow-xl hover:shadow-accent/10"
              >
                <Image
                  src={piece.image || "/placeholder.svg"}
                  alt={piece.title}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-4">
                  <h3 className="text-white font-medium text-lg">{piece.title}</h3>
                  <p className="text-white/70 text-sm mt-1">{piece.description}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {selectedImage !== null && (
        <div
          className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
          onClick={() => setSelectedImage(null)}
        >
          <button
            onClick={() => setSelectedImage(null)}
            className="absolute top-6 right-6 text-white hover:text-accent transition-colors"
          >
            <X className="w-8 h-8" />
          </button>
          <div className="bg-card rounded-lg max-w-3xl w-full overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="relative aspect-square md:aspect-video">
              <Image
                src={pieces[selectedImage].image || "/placeholder.svg"}
                alt={pieces[selectedImage].title}
                fill
                className="object-cover"
              />
            </div>
            <div className="p-8">
              <h3 className="text-3xl font-medium text-white mb-2">{pieces[selectedImage].title}</h3>
              <p className="text-white/70 mb-6">{pieces[selectedImage].description}</p>
              <div className="flex flex-wrap gap-2">
                {pieces[selectedImage].tags.map((tag, i) => (
                  <span key={i} className="px-3 py-1 bg-accent/20 text-accent rounded-full text-sm">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
