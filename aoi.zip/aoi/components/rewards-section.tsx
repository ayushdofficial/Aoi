"use client"

import { useEffect, useRef, useState } from "react"
import { useRouter } from "next/navigation"
import { MessageCircle, Video, BookOpen, Crown, Check, Shield, Lock, CreditCard } from "lucide-react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function RewardsSection() {
  const header = useScrollAnimation()
  const cards = useScrollAnimation()
  const steps = useScrollAnimation()
  const trust = useScrollAnimation()
  const router = useRouter()

  const rewards = [
    {
      id: "circulo-inicial",
      tier: "$1 USD",
      name: "Círculo Inicial",
      icon: MessageCircle,
      color: "from-stone-400 to-stone-500",
      voteWeight: 1,
      description: "Para quienes quieren apoyar y sentirse parte del proyecto.",
      benefits: [
        "Acceso al canal de bienvenida en Discord",
        "Actualizaciones mensuales del progreso",
        "Acceso a votos básicos (piezas y destinos)",
      ],
    },
    {
      id: "aprendiz-digital",
      tier: "$5 USD",
      name: "Aprendiz Digital",
      icon: BookOpen,
      color: "from-amber-600 to-amber-700",
      voteWeight: 5,
      description: "Ideal para quienes quieren participar más activamente.",
      benefits: [
        "Todo del nivel anterior",
        "Acceso completo a Discord privado",
        "Transmisión en vivo mensual del proceso",
        "Mini-guía digital de técnicas básicas (PDF)",
        "Participación en todas las votaciones",
      ],
      popular: false,
    },
    {
      id: "taller-virtual",
      tier: "$10 USD",
      name: "Taller Virtual",
      icon: Video,
      color: "from-accent to-amber-500",
      voteWeight: 10,
      description: "Para quienes desean aprender y tener voz en el proyecto.",
      benefits: [
        "Todo de los niveles anteriores",
        "Biblioteca digital de recetas y técnicas (PDFs)",
        "Sesiones de preguntas y respuestas en vivo trimestrales",
        "Acceso anticipado al contenido del viaje",
        "Influencia decisiva en piezas y destinos",
      ],
      popular: true,
    },
    {
      id: "maestro-del-horno",
      tier: "$15 USD",
      name: "Maestro del Horno",
      icon: Crown,
      color: "from-amber-400 to-yellow-500",
      voteWeight: 15,
      description: "Para quienes quieren dar forma a la dirección del proyecto.",
      benefits: [
        "Todo de los niveles anteriores",
        "Transmisiones exclusivas desde Japón",
        "Mini-libro digital personal sobre mi proceso",
        "Preguntas prioritarias durante transmisiones",
        "Mayor influencia en las decisiones",
      ],
    },
  ]

  const handleSelectReward = (rewardId: string) => {
    router.push(`/pago?nivel=${rewardId}`)
  }

  return (
    <section className="py-24 px-6 bg-card overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-16 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p
            className={`text-base uppercase tracking-[0.2em] text-accent mb-4 transition-all duration-700 delay-200 ${
              header.isVisible ? "opacity-100 tracking-[0.2em]" : "opacity-0 tracking-[0.1em]"
            }`}
          >
            Recompensas Digitales
          </p>
          <h2
            className={`text-4xl md:text-6xl font-light mb-6 transition-all duration-700 delay-300 ${
              header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            Sistema de Votación Ponderada
          </h2>
          {/* Animated golden line */}
          <div className="flex justify-center mb-6">
            <div
              className={`h-0.5 bg-gradient-to-r from-transparent via-accent to-transparent transition-all duration-1000 delay-500 ${
                header.isVisible ? "w-32" : "w-0"
              }`}
            />
          </div>
          <p
            className={`text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto transition-all duration-700 delay-500 ${
              header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            Tu apoyo no solo hace posible este proyecto: lo transforma en un viaje compartido. Cada nivel te da más voz
            en las decisiones creativas.
          </p>
        </div>

        <div ref={cards.ref} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-6">
          {rewards.map((reward, index) => (
            <div
              key={index}
              className={`relative bg-background border rounded-sm transition-all duration-700 group
                hover:shadow-2xl hover:shadow-accent/10 hover:-translate-y-2
                ${reward.popular ? "border-accent shadow-lg shadow-accent/10" : "border-border hover:border-accent/50"} 
                ${cards.isVisible ? "opacity-100 translate-y-0 scale-100" : "opacity-0 translate-y-16 scale-95"}`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              {/* Popular badge with pulse animation */}
              {reward.popular && (
                <div
                  className={`absolute -top-3 left-1/2 -translate-x-1/2 z-10 px-4 py-1.5 bg-accent text-accent-foreground text-xs font-bold uppercase tracking-wide rounded-full shadow-lg
                    transition-all duration-500 animate-pulse
                    ${cards.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-0"}`}
                  style={{ transitionDelay: `${index * 150 + 300}ms` }}
                >
                  Más popular
                </div>
              )}

              {/* Header with shimmer effect on hover */}
              <div className={`relative p-6 bg-gradient-to-br ${reward.color} text-white overflow-hidden`}>
                {/* Shimmer effect */}
                <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent" />

                <reward.icon
                  className={`w-8 h-8 mb-3 opacity-90 transition-all duration-700 ${
                    cards.isVisible ? "opacity-90 rotate-0 scale-100" : "opacity-0 -rotate-12 scale-75"
                  }`}
                  style={{ transitionDelay: `${index * 150 + 200}ms` }}
                />
                <p
                  className={`text-3xl font-bold transition-all duration-500 ${
                    cards.isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-4"
                  }`}
                  style={{ transitionDelay: `${index * 150 + 300}ms` }}
                >
                  {reward.tier}
                </p>
                <p
                  className={`text-xl font-medium opacity-90 transition-all duration-500 ${
                    cards.isVisible ? "opacity-90 translate-x-0" : "opacity-0 -translate-x-4"
                  }`}
                  style={{ transitionDelay: `${index * 150 + 400}ms` }}
                >
                  {reward.name}
                </p>
              </div>

              {/* Content */}
              <div className="p-6">
                <p className="text-base text-muted-foreground mb-4">{reward.description}</p>

                {/* Vote weight indicator with animated bar */}
                <div className="flex items-center gap-2 mb-6 p-3 bg-secondary/50 rounded-sm">
                  <span className="text-sm text-muted-foreground">Peso de voto:</span>
                  <span
                    className={`text-accent font-bold text-lg transition-all duration-700 ${
                      cards.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-50"
                    }`}
                    style={{ transitionDelay: `${index * 150 + 500}ms` }}
                  >
                    {reward.voteWeight}x
                  </span>
                  <div className="flex-1 h-2 bg-secondary rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-accent to-amber-400 transition-all duration-1000 ease-out"
                      style={{
                        width: cards.isVisible ? `${(reward.voteWeight / 15) * 100}%` : "0%",
                        transitionDelay: `${index * 150 + 600}ms`,
                      }}
                    />
                  </div>
                </div>

                <ul className="space-y-3">
                  {reward.benefits.map((benefit, i) => (
                    <li
                      key={i}
                      className={`flex items-start gap-2 text-base transition-all duration-500 ${
                        cards.isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-4"
                      }`}
                      style={{ transitionDelay: `${index * 150 + 700 + i * 100}ms` }}
                    >
                      <Check
                        className={`w-5 h-5 text-accent shrink-0 mt-0.5 transition-all duration-300 ${
                          cards.isVisible ? "scale-100" : "scale-0"
                        }`}
                        style={{ transitionDelay: `${index * 150 + 750 + i * 100}ms` }}
                      />
                      <span className="text-muted-foreground">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-6 pt-0">
                <button
                  onClick={() => handleSelectReward(reward.id)}
                  className={`relative w-full py-3 rounded-sm font-medium text-lg overflow-hidden transition-all duration-500 
                    ${
                      reward.popular
                        ? "bg-accent text-accent-foreground hover:bg-accent/90"
                        : "bg-secondary hover:bg-accent hover:text-accent-foreground"
                    }
                    ${cards.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}
                  style={{ transitionDelay: `${index * 150 + 800}ms` }}
                >
                  {/* Shimmer on hover */}
                  <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                  <span className="relative">Elegir {reward.name}</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        <div ref={steps.ref} className="mt-16 grid md:grid-cols-3 gap-8 text-center">
          {[
            {
              num: "1",
              title: "Elige tu nivel",
              desc: "Cada nivel incluye todos los beneficios anteriores más nuevas ventajas",
            },
            { num: "2", title: "Vota en las decisiones", desc: "Tu voto cuenta más según tu nivel de apoyo" },
            {
              num: "3",
              title: "Da forma al viaje",
              desc: "Decide qué piezas creo y qué lugares en Japón visitamos",
            },
          ].map((step, index) => (
            <div
              key={index}
              className={`p-6 transition-all duration-700 ${
                steps.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 200}ms` }}
            >
              <div
                className={`w-14 h-14 mx-auto mb-4 rounded-full bg-accent/10 flex items-center justify-center
                  transition-all duration-500 hover:bg-accent/20 hover:scale-110
                  ${steps.isVisible ? "scale-100 rotate-0" : "scale-0 rotate-180"}`}
                style={{ transitionDelay: `${index * 200 + 100}ms` }}
              >
                <span className="text-accent font-bold text-xl">{step.num}</span>
              </div>
              <h3
                className={`font-medium text-xl mb-2 transition-all duration-500 ${
                  steps.isVisible ? "opacity-100" : "opacity-0"
                }`}
                style={{ transitionDelay: `${index * 200 + 200}ms` }}
              >
                {step.title}
              </h3>
              <p
                className={`text-base text-muted-foreground transition-all duration-500 ${
                  steps.isVisible ? "opacity-100" : "opacity-0"
                }`}
                style={{ transitionDelay: `${index * 200 + 300}ms` }}
              >
                {step.desc}
              </p>
            </div>
          ))}
        </div>

        <SectionCTA text="Elige tu nivel" />

        <div
          ref={trust.ref}
          className={`mt-16 pt-12 border-t border-border transition-all duration-1000 ${
            trust.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
            <div
              className={`flex items-center gap-3 transition-all duration-500 group cursor-default ${
                trust.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
              style={{ transitionDelay: "100ms" }}
            >
              <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:bg-green-500/20 group-hover:shadow-lg group-hover:shadow-green-500/20">
                <Shield className="w-6 h-6 text-green-500 transition-transform duration-300 group-hover:scale-110" />
              </div>
              <div className="text-left">
                <p className="font-medium text-foreground transition-colors duration-300 group-hover:text-green-500">
                  Pagos 100% Seguros
                </p>
                <p className="text-sm text-muted-foreground">Encriptación SSL</p>
              </div>
            </div>

            <div
              className={`flex items-center gap-3 transition-all duration-500 group cursor-default ${
                trust.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
              style={{ transitionDelay: "200ms" }}
            >
              <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:bg-blue-500/20 group-hover:shadow-lg group-hover:shadow-blue-500/20">
                <Lock className="w-6 h-6 text-blue-500 transition-transform duration-300 group-hover:scale-110" />
              </div>
              <div className="text-left">
                <p className="font-medium text-foreground transition-colors duration-300 group-hover:text-blue-500">
                  Datos Protegidos
                </p>
                <p className="text-sm text-muted-foreground">Privacidad garantizada</p>
              </div>
            </div>

            <div
              className={`flex items-center gap-3 transition-all duration-500 group cursor-default ${
                trust.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
              style={{ transitionDelay: "300ms" }}
            >
              <div className="w-12 h-12 rounded-full bg-amber-500/10 flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:bg-amber-500/20 group-hover:shadow-lg group-hover:shadow-amber-500/20">
                <CreditCard className="w-6 h-6 text-amber-500 transition-transform duration-300 group-hover:scale-110" />
              </div>
              <div className="text-left">
                <p className="font-medium text-foreground transition-colors duration-300 group-hover:text-amber-500">
                  Pago Único
                </p>
                <p className="text-sm text-muted-foreground">Sin suscripciones</p>
              </div>
            </div>

            <div
              className={`flex items-center gap-3 transition-all duration-500 group cursor-default ${
                trust.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
              style={{ transitionDelay: "400ms" }}
            >
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center transition-all duration-300 group-hover:scale-110 group-hover:bg-accent/20 group-hover:shadow-lg group-hover:shadow-accent/20">
                <Check className="w-6 h-6 text-accent transition-transform duration-300 group-hover:scale-110" />
              </div>
              <div className="text-left">
                <p className="font-medium text-foreground transition-colors duration-300 group-hover:text-accent">
                  Satisfacción Garantizada
                </p>
                <p className="text-sm text-muted-foreground">Reembolso en 7 días</p>
              </div>
            </div>
          </div>

          <p
            className={`text-center text-sm text-muted-foreground mt-8 transition-all duration-500 ${
              trust.isVisible ? "opacity-100" : "opacity-0"
            }`}
            style={{ transitionDelay: "500ms" }}
          >
            Procesamos los pagos de forma segura. Tu información financiera{" "}
            <span className="font-bold text-foreground relative inline-block">
              <span className="relative z-10">nunca</span>
              <span
                className={`absolute inset-0 bg-accent/20 rounded-sm transition-all duration-700 ${
                  trust.isVisible ? "scale-x-100 opacity-100" : "scale-x-0 opacity-0"
                }`}
                style={{ transitionDelay: "800ms", transformOrigin: "left" }}
              />
            </span>{" "}
            se almacena en nuestros servidores.
          </p>
        </div>
      </div>
    </section>
  )
}
