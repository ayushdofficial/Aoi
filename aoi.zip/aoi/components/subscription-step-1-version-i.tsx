"use client"

import { ArrowRight, Heart, Sparkles, Star, Video, Users, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"

interface SubscriptionStep1Props {
  onNext: (email: string) => void
}

export function SubscriptionStep1VersionI({ onNext }: SubscriptionStep1Props) {
  const handlePatreonClick = () => {
    window.open("https://www.patreon.com/cw/aoi_kitsune", "_blank")
  }

  return (
    <div className="bg-cream min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-cream">
        <div className="max-w-7xl mx-auto px-6 py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="inline-block">
                <div className="bg-coral/10 text-coral px-4 py-2 rounded-full text-sm font-bold">
                  ✨ Un proyecto único y auténtico
                </div>
              </div>

              <h1 className="text-5xl lg:text-7xl font-bold text-charcoal leading-[1.05]">
                Apoya el arte de
                <span className="block text-coral mt-2">transformar lo roto</span>
              </h1>

              <p className="text-xl text-charcoal/70 leading-relaxed max-w-xl">
                Soy Daniel, ceramista neurodivergente de México. Estoy preparando mi viaje a Japón para aprender
                kintsugi con los maestros. Tu apoyo hace posible este sueño.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  onClick={handlePatreonClick}
                  className="bg-coral hover:bg-coral/90 text-white font-bold h-14 px-8 text-lg rounded-full shadow-lg hover:shadow-xl transition-all"
                >
                  Únete en Patreon
                  <ExternalLink className="ml-2 w-5 h-5" />
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  onClick={() => {
                    document.querySelector("[data-story-section]")?.scrollIntoView({ behavior: "smooth" })
                  }}
                  className="border-2 border-charcoal/20 hover:border-coral hover:bg-coral/5 text-charcoal font-semibold h-14 px-8 text-lg rounded-full"
                >
                  Conoce mi historia
                </Button>
              </div>

              <div className="flex items-center gap-8 pt-6">
                <div className="flex -space-x-3">
                  <div className="w-10 h-10 rounded-full bg-charcoal/20 border-2 border-cream"></div>
                  <div className="w-10 h-10 rounded-full bg-charcoal/30 border-2 border-cream"></div>
                  <div className="w-10 h-10 rounded-full bg-charcoal/40 border-2 border-cream"></div>
                  <div className="w-10 h-10 rounded-full bg-coral/30 border-2 border-cream flex items-center justify-center text-xs font-bold text-white">
                    +47
                  </div>
                </div>
                <p className="text-sm text-charcoal/60">
                  <span className="font-bold text-charcoal">47 mecenas</span> ya están apoyando este proyecto
                </p>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative">
              <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="/ceramic-artist-working-with-kintsugi-pottery-in-st.jpg"
                  alt="Daniel trabajando en su taller de cerámica"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Floating Card */}
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-6 max-w-xs border-2 border-coral/20">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-12 h-12 bg-coral/10 rounded-full flex items-center justify-center">
                    <Heart className="w-6 h-6 text-coral" />
                  </div>
                  <div>
                    <div className="font-bold text-charcoal">Desde $99 MXN/mes</div>
                    <div className="text-sm text-charcoal/60">Cancela cuando quieras</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-white" data-story-section>
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Image Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="aspect-square rounded-2xl overflow-hidden shadow-lg">
                  <img
                    src="/kintsugi-gold-repair-on-ceramic-bowl.jpg"
                    alt="Kintsugi en proceso"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="aspect-square rounded-2xl overflow-hidden shadow-lg">
                  <img
                    src="/mexican-pottery-traditional-ceramics.jpg"
                    alt="Cerámica mexicana"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div className="space-y-4 pt-8">
                <div className="aspect-square rounded-2xl overflow-hidden shadow-lg">
                  <img
                    src="/japanese-pottery-studio-workspace.jpg"
                    alt="Taller de cerámica"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="aspect-square rounded-2xl overflow-hidden shadow-lg">
                  <img
                    src="/ceramic-artist-hands-working-with-clay.jpg"
                    alt="Manos trabajando arcilla"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="space-y-6">
              <div className="inline-block bg-coral/10 text-coral px-4 py-2 rounded-full text-sm font-bold">
                Mi historia
              </div>

              <h2 className="text-4xl lg:text-5xl font-bold text-charcoal leading-tight">
                De México a Japón: fusionando tradiciones
              </h2>

              <div className="space-y-4 text-lg text-charcoal/80 leading-relaxed">
                <p>
                  Soy un artista ceramista de México, neurodivergente y apasionado por crear piezas que cuentan
                  historias de transformación. Llevo 22 años trabajando con arcilla, desde que tenía 12 años. Hoy tengo
                  34 años y descubrí algo que cambió mi vida: el kintsugi.
                </p>
                <p>
                  El kintsugi es el arte japonés de reparar cerámica rota con oro, celebrando las imperfecciones en
                  lugar de ocultarlas. Como persona neurodivergente, esta filosofía resuena profundamente conmigo.
                </p>
                <p>
                  En 2017, tuve el honor de empezar con la maestra{" "}
                  <a
                    href="https://www.instagram.com/huellas_de_agua/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-coral font-semibold hover:underline"
                  >
                    Irma Giménez en el taller Huellas de Agua
                  </a>
                  , donde profundicé en técnicas que transformaron mi práctica artística.
                </p>
                <p className="font-semibold text-charcoal">
                  Mi sueño es viajar a Japón para aprender esta técnica con maestros tradicionales y fusionarla con la
                  rica herencia de la cerámica mexicana.
                </p>
              </div>

              <blockquote className="border-l-4 border-coral pl-6 py-2">
                <p className="text-xl italic text-charcoal/80 font-medium">
                  "La neurodivergencia no es una limitación. Es la lente única que me permite ver belleza donde otros
                  ven lo roto."
                </p>
                <footer className="text-sm text-charcoal/60 mt-2">— Aoi (@aoi_ceramica)</footer>
              </blockquote>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-cream">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-charcoal mb-6">Al unirte en Patreon, obtienes</h2>
            <p className="text-xl text-charcoal/70 max-w-2xl mx-auto">
              No es solo apoyo financiero. Es formar parte de una comunidad que cree en el arte auténtico y la
              neurodiversidad.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Benefit 1 */}
            <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-shadow border-2 border-transparent hover:border-coral/20">
              <div className="w-16 h-16 bg-coral/10 rounded-2xl flex items-center justify-center mb-6">
                <Video className="w-8 h-8 text-coral" />
              </div>
              <h3 className="text-2xl font-bold text-charcoal mb-4">Contenido exclusivo</h3>
              <p className="text-charcoal/70 leading-relaxed">
                Videos del proceso creativo, tutoriales de técnicas, y acceso a mi diario de artista. Ve cómo cada pieza
                cobra vida desde la primera pincelada.
              </p>
            </div>

            {/* Benefit 2 */}
            <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-shadow border-2 border-transparent hover:border-coral/20">
              <div className="w-16 h-16 bg-coral/10 rounded-2xl flex items-center justify-center mb-6">
                <Users className="w-8 h-8 text-coral" />
              </div>
              <h3 className="text-2xl font-bold text-charcoal mb-4">Comunidad cercana</h3>
              <p className="text-charcoal/70 leading-relaxed">
                Únete a otros mecenas que celebran el arte diferente y la neurodivergencia. Conexión real,
                conversaciones auténticas, sin intermediarios.
              </p>
            </div>

            {/* Benefit 3 */}
            <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-shadow border-2 border-transparent hover:border-coral/20">
              <div className="w-16 h-16 bg-coral/10 rounded-2xl flex items-center justify-center mb-6">
                <Star className="w-8 h-8 text-coral" />
              </div>
              <h3 className="text-2xl font-bold text-charcoal mb-4">Acceso prioritario</h3>
              <p className="text-charcoal/70 leading-relaxed">
                Sé el primero en ver nuevas creaciones, recibe descuentos exclusivos en piezas y participa en decisiones
                creativas. Tu voz importa.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-block bg-coral/10 text-coral px-4 py-2 rounded-full text-sm font-bold">
                Tu impacto
              </div>

              <h2 className="text-4xl lg:text-5xl font-bold text-charcoal leading-tight">
                Cada peso cuenta hacia algo más grande
              </h2>

              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-coral/10 rounded-full flex items-center justify-center">
                    <span className="text-xl font-bold text-coral">1</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-charcoal mb-2">Materiales de calidad</h3>
                    <p className="text-charcoal/70">
                      Tu apoyo me permite trabajar con arcillas y pigmentos premium para crear piezas que duran
                      generaciones.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-coral/10 rounded-full flex items-center justify-center">
                    <span className="text-xl font-bold text-coral">2</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-charcoal mb-2">Viaje a Japón</h3>
                    <p className="text-charcoal/70">
                      Cada mes me acerca más a aprender kintsugi en Japón. Un sueño que parecía imposible ahora está al
                      alcance.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-coral/10 rounded-full flex items-center justify-center">
                    <span className="text-xl font-bold text-coral">3</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-charcoal mb-2">Tiempo para crear</h3>
                    <p className="text-charcoal/70">
                      Me liberas de trabajos secundarios para dedicarme completamente a mi arte y crecer como ceramista.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="/japanese-pottery-master-teaching-kintsugi-techniqu.jpg"
                  alt="Maestro de kintsugi enseñando"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-cream">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-charcoal mb-4">Voces de la comunidad</h2>
            <p className="text-xl text-charcoal/70">Lo que dicen quienes ya apoyan este proyecto</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-charcoal/10 rounded-full"></div>
                <div>
                  <div className="font-bold text-charcoal">María G.</div>
                  <div className="text-sm text-charcoal/60">Mecenas desde 2024</div>
                </div>
              </div>
              <p className="text-charcoal/80 leading-relaxed">
                "Apoyar a Daniel no es caridad. Es invertir en una visión del mundo que solo un artista neurodivergente
                puede ofrecer. Sus piezas son poesía visual."
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-charcoal/10 rounded-full"></div>
                <div>
                  <div className="font-bold text-charcoal">Carlos M.</div>
                  <div className="text-sm text-charcoal/60">Mecenas desde 2023</div>
                </div>
              </div>
              <p className="text-charcoal/80 leading-relaxed">
                "Ver el proceso detrás de cada pieza es mágico. Daniel transforma la arcilla con una sensibilidad que
                nunca había visto. Vale cada peso."
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-charcoal/10 rounded-full"></div>
                <div>
                  <div className="font-bold text-charcoal">Ana R.</div>
                  <div className="text-sm text-charcoal/60">Mecenas desde 2024</div>
                </div>
              </div>
              <p className="text-charcoal/80 leading-relaxed">
                "Su viaje a Japón será transformador. Me emociona ser parte de algo tan especial y auténtico. El arte
                neurodivergente merece ser celebrado."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-coral to-coral/90">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="mb-8">
            <div className="w-20 h-20 bg-white/20 backdrop-blur rounded-full flex items-center justify-center mx-auto mb-6">
              <Sparkles className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6">Sé parte de esta historia</h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto mb-8">
              Desde $99 MXN al mes, puedes hacer la diferencia en la vida de un artista y ser testigo de un viaje único:
              de México a Japón, del barro al oro.
            </p>
          </div>

          <Button
            onClick={handlePatreonClick}
            size="lg"
            className="bg-white hover:bg-white/90 text-coral font-bold h-16 px-12 text-xl rounded-full shadow-2xl hover:shadow-3xl transition-all hover:scale-105"
          >
            Únete en Patreon ahora
            <ArrowRight className="ml-2 w-6 h-6" />
          </Button>

          <p className="text-white/80 text-sm mt-6">Cancela cuando quieras • Sin compromisos • 100% transparente</p>

          <div className="flex flex-wrap items-center justify-center gap-8 mt-12 pt-8 border-t border-white/20">
            <div className="text-center">
              <div className="text-3xl font-bold text-white">22</div>
              <div className="text-sm text-white/80">años creando</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white">200+</div>
              <div className="text-sm text-white/80">piezas únicas</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white">47</div>
              <div className="text-sm text-white/80">mecenas activos</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <section className="py-12 bg-charcoal text-white">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="text-center md:text-left">
              <h3 className="text-2xl font-bold mb-2">Aoi • Ceramista Neurodivergente</h3>
              <p className="text-white/60">Transformando lo roto en arte desde México</p>
            </div>
            <div className="flex gap-4">
              <Button
                onClick={handlePatreonClick}
                variant="outline"
                className="border-white/20 hover:border-coral hover:bg-coral/10 text-white rounded-full bg-transparent"
              >
                Visitar Patreon
                <ExternalLink className="ml-2 w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
