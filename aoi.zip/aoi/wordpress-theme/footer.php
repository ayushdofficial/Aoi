<?php
/**
 * Theme Footer
 *
 * @package Aoi_Ceramica
 */
?>

    <footer class="site-footer section bg-charcoal text-white">
        <div class="container">
            <div class="grid grid-cols-3 gap-8">
                <div>
                    <h3 class="text-2xl font-bold mb-4">Aoi Cerámica</h3>
                    <p class="text-gray-300">
                        Arte neurodivergente que transforma lo roto en belleza. 
                        Fusionando la tradición cerámica mexicana con el kintsugi japonés.
                    </p>
                </div>
                
                <div>
                    <h4 class="text-xl font-semibold mb-4">Enlaces</h4>
                    <ul class="space-y-2">
                        <li><a href="https://www.patreon.com/cw/aoi_kitsune" target="_blank" class="text-gray-300 hover:text-accent">Patreon</a></li>
                        <li><a href="https://www.instagram.com/aoi_ceramica/" target="_blank" class="text-gray-300 hover:text-accent">Instagram</a></li>
                        <li><a href="https://www.instagram.com/huellas_de_agua/" target="_blank" class="text-gray-300 hover:text-accent">Huellas de Agua</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="text-xl font-semibold mb-4">Contacto</h4>
                    <p class="text-gray-300">
                        <a href="mailto:aoiceramica@gmail.com" class="hover:text-accent">aoiceramica@gmail.com</a>
                    </p>
                </div>
            </div>
            
            <div class="border-t border-white/20 mt-8 pt-8 text-center">
                <p class="text-gray-400">
                    &copy; <?php echo date('Y'); ?> Aoi Cerámica - Daniel Lojo. Todos los derechos reservados.
                </p>
            </div>
        </div>
    </footer>

    <!-- Version Tab Navigation -->
    <div class="version-tabs">
        <div class="version-tabs-container">
            <?php
            $versions = array(
                'a' => array('label' => 'Versión A', 'desc' => 'Clásica'),
                'b' => array('label' => 'Versión B', 'desc' => 'Testimonios'),
                'c' => array('label' => 'Versión C', 'desc' => 'Timeline'),
                'd' => array('label' => 'Versión D', 'desc' => 'Personalizada'),
                'f' => array('label' => 'Versión F', 'desc' => 'Educativa'),
                'g' => array('label' => 'Versión G', 'desc' => 'Urgencia'),
                'h' => array('label' => 'Versión H', 'desc' => 'Premium'),
                'i' => array('label' => 'Versión I', 'desc' => 'Patreon'),
            );
            
            $active = aoi_get_active_variant();
            
            foreach ($versions as $key => $version) {
                $active_class = ($key === $active) ? 'active' : '';
                printf(
                    '<button class="version-tab %s" data-variant="%s">
                        <div class="version-tab-label">%s</div>
                        <div class="version-tab-desc">%s</div>
                    </button>',
                    $active_class,
                    esc_attr($key),
                    esc_html($version['label']),
                    esc_html($version['desc'])
                );
            }
            ?>
        </div>
    </div>
    
    <!-- Scroll to Top Button -->
    <button class="scroll-to-top" id="scrollToTop" aria-label="Scroll to top">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 15l-6-6-6 6"/>
        </svg>
    </button>

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
