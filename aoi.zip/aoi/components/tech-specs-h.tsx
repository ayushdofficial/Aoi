"use client"

import { CheckCircle2 } from "lucide-react"

export function TechSpecsH() {
  const specs = [
    {
      category: "Formación",
      items: [
        { label: "Duración del viaje", value: "8 meses" },
        { label: "Inicio del proyecto", value: "Agosto 2026" },
        { label: "Ubicación", value: "Japón" },
        { label: "Certificación", value: "Oficial" },
      ],
    },
    {
      category: "Experiencia",
      items: [
        { label: "Transmisiones en vivo", value: "Semanales" },
        { label: "Idioma principal", value: "Español" },
        { label: "Idiomas adicionales", value: "Según disponibilidad" },
        { label: "Acceso a contenido", value: "Exclusivo Discord" },
      ],
    },
    {
      category: "Recompensas",
      items: [
        { label: "Piezas hechas a mano", value: "100% únicas" },
        { label: "Tiempo de entrega", value: "1-2 meses" },
        { label: "Calidad garantizada", value: "Certificada" },
        { label: "Envío", value: "Internacional" },
      ],
    },
  ]

  return (
    <section className="py-24 px-6 bg-muted/30">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-block bg-accent/10 border border-accent/30 rounded-full px-6 py-2 mb-6">
            <span className="text-sm uppercase tracking-widest text-accent font-medium">Especificaciones</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Todo lo que necesitas saber</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Transparencia total sobre el proyecto y sus características
          </p>
        </div>

        {/* Specs Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {specs.map((spec, index) => (
            <div
              key={index}
              className="bg-background rounded-2xl p-8 border border-border hover:border-accent/50 transition-colors"
            >
              <h3 className="text-2xl font-bold mb-6 text-accent">{spec.category}</h3>
              <div className="space-y-4">
                {spec.items.map((item, itemIndex) => (
                  <div key={itemIndex} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                    <div className="flex-1">
                      <div className="text-sm text-muted-foreground">{item.label}</div>
                      <div className="font-semibold">{item.value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-12 bg-background rounded-2xl p-8 border border-accent/30">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
              <CheckCircle2 className="w-6 h-6 text-accent" />
            </div>
            <div>
              <h4 className="text-xl font-bold mb-2">Compromiso de calidad</h4>
              <p className="text-muted-foreground leading-relaxed">
                Cada pieza será creada con los más altos estándares de calidad. Las transmisiones en vivo serán en
                español porque Daniel solo habla español, pero haremos lo posible para ofrecer subtítulos o resúmenes en
                inglés u otros idiomas para nuestros apoyadores internacionales.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
