<?php
/**
 * Aoi Ceramica Sales Funnel Theme Functions
 *
 * @package Aoi_Ceramica
 */

// Theme Setup
function aoi_ceramica_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('custom-logo');
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'aoi-ceramica'),
        'footer' => __('Footer Menu', 'aoi-ceramica'),
    ));
    
    // Add image sizes
    add_image_size('gallery-square', 600, 600, true);
    add_image_size('hero-large', 1920, 1080, true);
}
add_action('after_setup_theme', 'aoi_ceramica_setup');

// Enqueue Scripts and Styles
function aoi_ceramica_scripts() {
    // Main stylesheet
    wp_enqueue_style('aoi-ceramica-style', get_stylesheet_uri(), array(), '2.0.0');
    
    // Google Fonts
    wp_enqueue_style('aoi-ceramica-fonts', 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@300;400;500;600;700&display=swap', array(), null);
    
    // Main JavaScript
    wp_enqueue_script('aoi-ceramica-main', get_template_directory_uri() . '/js/main.js', array(), '2.0.0', true);
    
    // Localize script for AJAX
    wp_localize_script('aoi-ceramica-main', 'aoiCeramica', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('aoi_ceramica_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'aoi_ceramica_scripts');

// Custom Post Types (if needed for future extensions)
function aoi_ceramica_register_post_types() {
    // Testimonials
    register_post_type('testimonial', array(
        'labels' => array(
            'name' => __('Testimonials', 'aoi-ceramica'),
            'singular_name' => __('Testimonial', 'aoi-ceramica'),
        ),
        'public' => true,
        'has_archive' => false,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-format-quote',
    ));
    
    // Gallery Items
    register_post_type('gallery_item', array(
        'labels' => array(
            'name' => __('Gallery', 'aoi-ceramica'),
            'singular_name' => __('Gallery Item', 'aoi-ceramica'),
        ),
        'public' => true,
        'has_archive' => false,
        'supports' => array('title', 'thumbnail'),
        'menu_icon' => 'dashicons-format-gallery',
    ));
}
add_action('init', 'aoi_ceramica_register_post_types');

// Shortcodes
function aoi_patreon_link_shortcode($atts) {
    $atts = shortcode_atts(array(
        'text' => 'Únete en Patreon',
        'class' => 'btn btn-primary',
    ), $atts);
    
    return sprintf(
        '<a href="https://www.patreon.com/cw/aoi_kitsune" target="_blank" rel="noopener noreferrer" class="%s">%s</a>',
        esc_attr($atts['class']),
        esc_html($atts['text'])
    );
}
add_shortcode('patreon_link', 'aoi_patreon_link_shortcode');

// Email capture AJAX handler
function aoi_ceramica_handle_email_capture() {
    check_ajax_referer('aoi_ceramica_nonce', 'nonce');
    
    $email = sanitize_email($_POST['email']);
    $variant = sanitize_text_field($_POST['variant']);
    
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Invalid email address'));
    }
    
    // Save to database or send to email marketing service
    // This is where you'd integrate with Mailchimp, ConvertKit, etc.
    
    // For now, just log it
    error_log("Email captured: $email for variant: $variant");
    
    wp_send_json_success(array('message' => 'Email captured successfully'));
}
add_action('wp_ajax_capture_email', 'aoi_ceramica_handle_email_capture');
add_action('wp_ajax_nopriv_capture_email', 'aoi_ceramica_handle_email_capture');

// Get active variant from cookie or default
function aoi_get_active_variant() {
    if (isset($_COOKIE['aoi_variant'])) {
        $variant = sanitize_text_field($_COOKIE['aoi_variant']);
        if (in_array($variant, array('a', 'b', 'c', 'd', 'f', 'g', 'h', 'i'))) {
            return $variant;
        }
    }
    
    if (isset($_GET['variant'])) {
        $variant = sanitize_text_field($_GET['variant']);
        if (in_array($variant, array('a', 'b', 'c', 'd', 'f', 'g', 'h', 'i'))) {
            return $variant;
        }
    }
    
    return 'i'; // Default to Patreon version
}

// Widget Areas
function aoi_ceramica_widgets_init() {
    register_sidebar(array(
        'name' => __('Footer Widget Area', 'aoi-ceramica'),
        'id' => 'footer-1',
        'description' => __('Appears in the footer', 'aoi-ceramica'),
        'before_widget' => '<div class="footer-widget">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ));
}
add_action('widgets_init', 'aoi_ceramica_widgets_init');

// Custom body classes for variants
function aoi_ceramica_body_classes($classes) {
    $variant = aoi_get_active_variant();
    $classes[] = 'variant-' . $variant;
    return $classes;
}
add_filter('body_class', 'aoi_ceramica_body_classes');

// Disable WordPress emojis (performance)
function aoi_disable_emojis() {
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('admin_print_styles', 'print_emoji_styles');
}
add_action('init', 'aoi_disable_emojis');
?>
