<!-- Version F: Educativa - Educational 2-step process -->
<section class="hero-section" style="background: linear-gradient(to bottom, rgba(0,0,0,0.7), rgba(0,0,0,0.6)), url('/wp-content/themes/aoi-ceramica-theme/images/ceramic-hero.jpg') center/cover;">
    <div class="container hero-content" style="color: white;">
        <div style="display: inline-block; background: rgba(255,83,73,0.2); color: var(--accent); padding: 8px 16px; border-radius: 20px; font-weight: 700; margin-bottom: 16px;">
            ✨ Un proyecto único y auténtico
        </div>
        <h1 class="hero-title" style="color: white;">Descubre el arte detrás de cada pieza</h1>
        <p class="hero-subtitle" style="color: rgba(255,255,255,0.9);">Comprende el proceso creativo de un artista neurodivergente y apoya la fusión de la tradición cerámica mexicana con el kintsugi japonés</p>
        <button onclick="document.querySelector('[data-video-section]').scrollIntoView({behavior: 'smooth'})" class="btn btn-primary btn-lg">Ver el proceso</button>
    </div>
</section>

<section class="section bg-white" data-video-section>
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">El proceso creativo</h2>
            <p class="section-subtitle">Desde la arcilla hasta la pieza terminada</p>
        </div>
        <div style="max-width: 900px; margin: 0 auto;">
            <div style="aspect-ratio: 16/9; background: var(--muted); border-radius: calc(var(--radius) * 2); display: flex; align-items: center; justify-center;">
                <p style="color: var(--muted-foreground);">Video del proceso (añadir video aquí)</p>
            </div>
        </div>
    </div>
</section>

<section class="section bg-secondary">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Los pasos de la creación</h2>
        </div>
        <div class="tiers-grid">
            <div class="tier-card">
                <div style="width: 60px; height: 60px; background: rgba(255,83,73,0.1); border-radius: 50%; display: flex; align-items: center; justify-center; margin-bottom: 16px;">
                    <span style="font-size: 1.5rem; font-weight: 700; color: var(--accent);">1</span>
                </div>
                <h3 style="font-size: 1.25rem; margin-bottom: 8px;">Selección de arcilla</h3>
                <p style="color: var(--muted-foreground);">Cada tipo de arcilla tiene su propia personalidad y características únicas.</p>
            </div>
            <div class="tier-card">
                <div style="width: 60px; height: 60px; background: rgba(255,83,73,0.1); border-radius: 50%; display: flex; align-items: center; justify-center; margin-bottom: 16px;">
                    <span style="font-size: 1.5rem; font-weight: 700; color: var(--accent);">2</span>
                </div>
                <h3 style="font-size: 1.25rem; margin-bottom: 8px;">Modelado a mano</h3>
                <p style="color: var(--muted-foreground);">El proceso de dar forma es meditativo y requiere años de práctica.</p>
            </div>
            <div class="tier-card">
                <div style="width: 60px; height: 60px; background: rgba(255,83,73,0.1); border-radius: 50%; display: flex; align-items: center; justify-center; margin-bottom: 16px;">
                    <span style="font-size: 1.5rem; font-weight: 700; color: var(--accent);">3</span>
                </div>
                <h3 style="font-size: 1.25rem; margin-bottom: 8px;">Quema y acabado</h3>
                <p style="color: var(--muted-foreground);">El horno transforma la arcilla en una pieza permanente y duradera.</p>
            </div>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/sections/email-capture'); ?>
<?php get_template_part('template-parts/sections/faq'); ?>
