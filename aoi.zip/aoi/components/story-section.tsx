"use client"

import { useEffect, useRef, useState } from "react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function StorySection() {
  const intro = useScrollAnimation()
  const storyBlock = useScrollAnimation()
  const timeline = useScrollAnimation()
  const quote = useScrollAnimation()
  const neuroSection = useScrollAnimation()

  return (
    <section className="pt-24 pb-12 px-6 bg-secondary/30 overflow-hidden">
      <div className="max-w-4xl mx-auto">
        <div
          ref={intro.ref}
          className={`text-center mb-20 transition-all duration-1000 ${
            intro.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">My Story</p>
          <h2 className="text-4xl md:text-6xl font-light mb-6">Hello, I'm Daniel</h2>
          <p className="text-2xl md:text-3xl text-muted-foreground font-light">
            Mexican ceramist, neurodivergent artist, and clay storyteller
          </p>
        </div>

        <div ref={storyBlock.ref} className="grid md:grid-cols-2 gap-12 md:gap-16 items-center mb-20">
          <div
            className={`aspect-[4/5] relative transition-all duration-1000 delay-200 ${
              storyBlock.isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"
            }`}
          >
            <img
              src="/hands-molding-clay-ceramic-artist-warm-lighting-st.jpg"
              alt="Artist's hands shaping clay"
              className="w-full h-full object-cover rounded-sm"
            />
            <div
              className={`absolute -bottom-4 -right-4 w-24 h-24 border-2 border-accent rounded-sm transition-all duration-700 delay-700 ${
                storyBlock.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-75"
              }`}
            />
          </div>

          <div
            className={`space-y-6 transition-all duration-1000 delay-400 ${
              storyBlock.isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"
            }`}
          >
            <p className="text-xl md:text-2xl leading-relaxed">
              <span className="text-accent font-medium">Every piece I create is a conversation without words.</span>
            </p>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              Since I was 12, clay has been my language. I'm now 34 and have been creating for 22 years. I grew up
              around lit kilns and the teachings of two key figures: My father,{" "}
              <strong className="text-foreground">Juan Lojo Romero</strong>, and my teacher,{" "}
              <strong className="text-foreground">Alberto Díaz de Cossío</strong>.
            </p>
          </div>
        </div>

        <div
          ref={timeline.ref}
          className={`mb-20 transition-all duration-1000 ${
            timeline.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <h3 className="text-2xl md:text-3xl font-light text-center mb-12">The journey so far</h3>
          <div className="relative">
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-accent/30 -translate-x-1/2" />

            <div className="space-y-12">
              {[
                {
                  year: "2003",
                  title: "First Steps",
                  desc: "At 12 years old, I begin formal training with my father and teacher Alberto.",
                },
                {
                  year: "2017",
                  title: "Huellas de Agua Workshop",
                  desc: "I start with teacher Irma Giménez at Huellas de Agua workshop, deepening my advanced techniques.",
                },
                {
                  year: "2018",
                  title: "Discovering Kintsugi",
                  desc: "I become fascinated with the Japanese philosophy of repairing fractures with gold.",
                },
                {
                  year: "2023",
                  title: "Current Project",
                  desc: "I decide to combine my Mexican heritage with Japanese techniques in a transformative journey.",
                },
                {
                  year: "2026",
                  title: "The Journey to Japan",
                  desc: "A month of immersion in kintsugi culture and Japanese ceramics in August 2026.",
                },
              ].map((item, index) => (
                <div
                  key={index}
                  className={`grid md:grid-cols-2 gap-8 items-center transition-all duration-700 ${
                    timeline.isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
                  }`}
                  style={{ transitionDelay: `${index * 150}ms` }}
                >
                  {index % 2 === 0 ? (
                    <>
                      <div className="text-right">
                        <p className="text-3xl font-bold text-accent mb-2">{item.year}</p>
                        <h4 className="text-xl font-medium mb-2">{item.title}</h4>
                        <p className="text-muted-foreground">{item.desc}</p>
                      </div>
                      <div className="relative flex justify-start">
                        <div className="w-4 h-4 rounded-full bg-accent border-4 border-background relative z-10" />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="relative flex justify-end">
                        <div className="w-4 h-4 rounded-full bg-accent border-4 border-background relative z-10" />
                      </div>
                      <div>
                        <p className="text-3xl font-bold text-accent mb-2">{item.year}</p>
                        <h4 className="text-xl font-medium mb-2">{item.title}</h4>
                        <p className="text-muted-foreground">{item.desc}</p>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        <blockquote
          ref={quote.ref}
          className={`relative py-12 px-8 md:px-16 text-center transition-all duration-1000 ${
            quote.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
          }`}
        >
          <div
            className={`absolute top-0 left-1/2 -translate-x-1/2 h-px bg-accent transition-all duration-1000 delay-300 ${
              quote.isVisible ? "w-16" : "w-0"
            }`}
          />
          <p className="text-2xl md:text-4xl font-light leading-relaxed italic">
            "They taught me that ceramics is not just technique:
            <span className="text-accent"> it's time, philosophy, and healing.</span>"
          </p>
          <div
            className={`absolute bottom-0 left-1/2 -translate-x-1/2 h-px bg-accent transition-all duration-1000 delay-500 ${
              quote.isVisible ? "w-16" : "w-0"
            }`}
          />
        </blockquote>

        <div ref={neuroSection.ref} className="grid md:grid-cols-2 gap-12 md:gap-16 items-center mt-20">
          <div
            className={`order-2 md:order-1 space-y-6 transition-all duration-1000 delay-200 ${
              neuroSection.isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"
            }`}
          >
            <p className="text-xl md:text-2xl leading-relaxed">
              As a neurodivergent person, I found in clay{" "}
              <span className="text-accent font-medium">a sensory refuge</span>.
            </p>
            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
              A place where noise fades, time stretches, and forms begin to speak.
            </p>
            <p className="text-2xl md:text-3xl font-medium mt-8">
              Today, I want to take that voice to the other side of the world.
            </p>
          </div>

          <div
            className={`order-1 md:order-2 aspect-[4/5] relative transition-all duration-1000 delay-400 ${
              neuroSection.isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"
            }`}
          >
            <img
              src="/japanese-kintsugi-pottery-gold-veins-minimalist-ce.jpg"
              alt="Kintsugi ceramics with golden veins"
              className="w-full h-full object-cover rounded-sm"
            />
            <div
              className={`absolute -top-4 -left-4 w-24 h-24 border-2 border-accent rounded-sm transition-all duration-700 delay-700 ${
                neuroSection.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-75"
              }`}
            />
          </div>
        </div>

        <SectionCTA text="Be part of the creation" variant="subtle" scrollTarget="[data-email-capture-section]" />
      </div>
    </section>
  )
}
