<section class="section bg-white" data-email-capture-section>
    <div class="container" style="max-width: 700px;">
        <div class="section-header">
            <p style="text-transform: uppercase; letter-spacing: 0.2em; color: var(--accent); margin-bottom: 16px;">Únete</p>
            <h2 class="section-title">Sé parte de la creación</h2>
            <p class="section-subtitle">Recibe actualizaciones exclusivas y sé el primero en conocer las novedades del proyecto</p>
        </div>
        
        <div style="background: linear-gradient(to bottom right, rgba(255,83,73,0.1), rgba(255,83,73,0.05)); border: 2px solid rgba(255,83,73,0.2); border-radius: calc(var(--radius) * 2); padding: 48px; text-align: center;">
            <form class="email-capture-form">
                <input type="email" name="email" placeholder="tu@email.com" required class="input-field" style="margin-bottom: 16px;" />
                <button type="submit" class="btn btn-primary btn-lg" style="width: 100%;">Unirme al viaje</button>
            </form>
            <p style="margin-top: 16px; color: var(--muted-foreground); font-size: 0.875rem;">Tu email está seguro. No compartimos datos con terceros.</p>
        </div>
    </div>
</section>
