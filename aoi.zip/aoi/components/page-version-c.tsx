import { HeroSectionC } from "@/components/hero-section-c"
import { TrustSectionC } from "@/components/trust-section-c"
import { StorySection } from "@/components/story-section"
import { GallerySectionOptimized } from "@/components/gallery-section-optimized"
import { WhySupportSection } from "@/components/why-support-section"
import { BenefitsSectionWithImages } from "@/components/benefits-section-with-images"
import { EmailCaptureWithImage } from "@/components/email-capture-with-image"
import { FAQSection } from "@/components/faq-section"
import { FinalCTA } from "@/components/final-cta"

export function PageVersionC() {
  return (
    <>
      <HeroSectionC />
      <TrustSectionC />
      <StorySection />
      <GallerySectionOptimized />
      <WhySupportSection />
      <BenefitsSectionWithImages />
      <EmailCaptureWithImage />
      <FAQSection />
      <FinalCTA />
    </>
  )
}
