"use client"

import { useEffect, useRef, useState } from "react"
import { Calendar, MapPin, Sparkles, Mountain } from "lucide-react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function JapanJourneySection() {
  const header = useScrollAnimation()
  const mainContent = useScrollAnimation()
  const stretchGoal = useScrollAnimation()

  return (
    <section className="py-24 px-6 bg-secondary/30 overflow-hidden">
      <div className="max-w-5xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-16 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">El Viaje a Japón</p>
          <h2 className="text-4xl md:text-6xl font-light mb-6">
            Un mes inmerso en
            <span className="block text-accent">el arte del Kintsugi</span>
          </h2>
          <div className="flex justify-center mb-6">
            <div
              className={`h-0.5 bg-gradient-to-r from-transparent via-accent to-transparent transition-all duration-1000 delay-300 ${
                header.isVisible ? "w-32" : "w-0"
              }`}
            />
          </div>
        </div>

        <div ref={mainContent.ref} className="grid md:grid-cols-2 gap-12 items-center mb-16">
          <div
            className={`transition-all duration-1000 ${
              mainContent.isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"
            }`}
          >
            <div className="relative aspect-[4/3] overflow-hidden rounded-sm">
              <img
                src="/japanese-kintsugi-workshop-golden-repair-ceramics-.jpg"
                alt="Taller de kintsugi en Japón"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/40 to-transparent" />
              <div className="absolute bottom-4 left-4 flex items-center gap-2 text-background">
                <Calendar className="w-5 h-5" />
                <span className="font-medium">Agosto 2026</span>
              </div>
            </div>
          </div>

          <div
            className={`space-y-6 transition-all duration-1000 delay-200 ${
              mainContent.isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"
            }`}
          >
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                <MapPin className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="text-xl font-medium mb-2">Residencia Toma House AIR</h3>
                <p className="text-lg text-muted-foreground">
                  Narita, Japón — Un curso especializado de cerámica enfocado en la técnica ancestral del kintsugi,
                  donde las fracturas se iluminan con oro.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                <Sparkles className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="text-xl font-medium mb-2">La filosofía de la reparación</h3>
                <p className="text-lg text-muted-foreground">
                  Más que una técnica, el kintsugi es una filosofía: abrazar las imperfecciones, honrar la historia y
                  transformar las heridas en belleza.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Stretch Goal Section */}
        <div
          ref={stretchGoal.ref}
          className={`relative bg-gradient-to-br from-accent/5 to-accent/10 border border-accent/20 rounded-sm p-8 md:p-12 transition-all duration-1000 ${
            stretchGoal.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
          }`}
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-3xl" />

          <div className="relative z-10 grid md:grid-cols-2 gap-8 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Mountain className="w-8 h-8 text-accent" />
                <span className="text-sm uppercase tracking-widest text-accent font-medium">Si superamos la meta</span>
              </div>
              <h3 className="text-2xl md:text-3xl font-light mb-4">
                Explorando pueblos cerámicos y <span className="text-accent">talleres ocultos</span>
              </h3>
              <p className="text-lg text-muted-foreground">
                Si superamos nuestra meta de financiamiento, extenderé el viaje para visitar pueblos cerámicos
                tradicionales, conocer artesanos locales y explorar talleres rurales que traerán nueva inspiración y
                técnicas a mi obra.
              </p>
            </div>

            <div className="relative aspect-[4/3] overflow-hidden rounded-sm">
              <img
                src="/traditional-japanese-ceramic-village-rural-pottery.jpg"
                alt="Pueblo cerámico tradicional japonés"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/30 to-transparent" />
            </div>
          </div>
        </div>

        <SectionCTA text="Únete al viaje" />
      </div>
    </section>
  )
}
