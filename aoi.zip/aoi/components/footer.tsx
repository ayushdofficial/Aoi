"use client"

import { useState, useEffect, useRef } from "react"
import { Mail, Instagram, Youtube } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function Footer() {
  const footer = useScrollAnimation()

  return (
    <footer ref={footer.ref} className="bg-secondary/30 border-t border-border/50 py-16 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div
            className={`transition-all duration-700 ${
              footer.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <div className="mb-4">
              <span className="text-4xl text-accent opacity-60">金</span>
            </div>
            <p className="text-muted-foreground leading-relaxed">
              Un puente cultural de cerámica entre México y Japón. Transformando las fracturas en arte.
            </p>
          </div>

          {/* Mini FAQ */}
          <div
            className={`transition-all duration-700 delay-100 ${
              footer.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <h4 className="text-lg font-medium mb-4">Preguntas frecuentes</h4>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1" className="border-border/50">
                <AccordionTrigger className="text-sm hover:text-accent">¿Cuándo inicia el proyecto?</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">
                  El viaje a Japón está programado para agosto de 2026. Las actualizaciones comienzan inmediatamente
                  después de tu registro.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-2" className="border-border/50">
                <AccordionTrigger className="text-sm hover:text-accent">¿Recibiré algo físico?</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">
                  Este proyecto se enfoca en recompensas digitales: contenido exclusivo, acceso a transmisiones en vivo,
                  y participación en decisiones creativas.
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="item-3" className="border-border/50">
                <AccordionTrigger className="text-sm hover:text-accent">
                  ¿Puedo cancelar mi suscripción?
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">
                  Sí, puedes cancelar en cualquier momento. Mantendrás acceso hasta el final de tu período de
                  facturación actual.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>

          {/* Contact & Social */}
          <div
            className={`transition-all duration-700 delay-200 ${
              footer.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <h4 className="text-lg font-medium mb-4">Conecta conmigo</h4>
            <div className="space-y-3 mb-6">
              <a
                href="mailto:aoiceramica@gmail.com"
                className="flex items-center gap-3 text-muted-foreground hover:text-accent transition-colors"
              >
                <Mail className="w-5 h-5" />
                <span className="text-sm">aoiceramica@gmail.com</span>
              </a>
              <a
                href="https://www.instagram.com/aoi_ceramica"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-muted-foreground hover:text-accent transition-colors"
              >
                <Instagram className="w-5 h-5" />
                <span className="text-sm">@aoi_ceramica</span>
              </a>
              <a
                href="https://www.youtube.com/@aoiceramica5053"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-muted-foreground hover:text-accent transition-colors"
              >
                <Youtube className="w-5 h-5" />
                <span className="text-sm">Canal de YouTube</span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className={`border-t border-border/50 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 transition-all duration-700 delay-300 ${
            footer.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-sm text-muted-foreground">© 2025 Daniel Lojo. Todos los derechos reservados.</p>
          <div className="flex gap-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-accent transition-colors">
              Privacidad
            </a>
            <a href="#" className="hover:text-accent transition-colors">
              Términos
            </a>
            <a href="#" className="hover:text-accent transition-colors">
              Cookies
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
