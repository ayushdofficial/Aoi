"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { StorySection } from "@/components/story-section"
import { Heart, Sparkles, Users, Shield, Star } from "lucide-react"

interface SubscriptionStep1Props {
  onNext: (email: string) => void
}

export function SubscriptionStep1({ onNext }: SubscriptionStep1Props) {
  const [email, setEmail] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !email.includes("@")) {
      setError("Por favor ingresa un email válido")
      return
    }

    onNext(email)
  }

  return (
    <div className="space-y-0">
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: "url('/beautiful-ceramic-pottery-art-kintsugi-gold.jpg')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/75 via-black/60 to-black/80 z-10" />

        <div className="relative z-20 max-w-3xl mx-auto text-center px-6 py-20">
          <div className="mb-8 text-left bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6 max-w-xl mx-auto">
            <p className="text-sm text-accent uppercase tracking-wider font-medium mb-2">Hola, soy</p>
            <h2 className="text-3xl md:text-4xl font-light text-white mb-3">Daniel</h2>
            <p className="text-lg text-gray-200 leading-relaxed">
              Artista ceramista de <span className="text-accent font-medium">México</span>, neurodivergente y creador de
              piezas únicas que fusionan la filosofía del kintsugi japonés con la tradición cerámica mexicana. A través
              de mi arte, transformo lo imperfecto en belleza.
            </p>
          </div>

          {/* Badge de urgencia */}
          <div className="inline-flex items-center gap-2 bg-accent/20 backdrop-blur-sm border border-accent/30 rounded-full px-4 py-2 mb-8">
            <Heart className="w-4 h-4 text-accent" />
            <span className="text-sm text-accent font-medium">Solo 47 mecenas activos</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-light mb-6 text-white text-balance leading-tight">
            Tu apoyo hace posible
            <span className="block text-accent mt-2">el arte neurodivergente</span>
          </h1>

          <p className="text-xl md:text-2xl text-gray-200 mb-6 font-light leading-relaxed max-w-2xl mx-auto">
            Sé parte del viaje de un artista que ve el mundo diferente y transforma la cerámica mexicana con la
            filosofía del kintsugi japonés.
          </p>

          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg p-6 mb-10 max-w-xl mx-auto">
            <p className="text-lg text-gray-100 italic">
              "La neurodivergencia no es una limitación. Es la lente única que me permite
              <span className="text-accent font-medium"> transformar el silencio en oro</span>."
            </p>
            <p className="text-sm text-gray-400 mt-2">— Daniel, ceramista neurodivergente</p>
          </div>

          {/* Stats de confianza */}
          <div className="flex flex-wrap justify-center gap-8 mb-10">
            <div className="text-center">
              <p className="text-3xl font-light text-white">15+</p>
              <p className="text-sm text-gray-400">años creando</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-light text-white">200+</p>
              <p className="text-sm text-gray-400">piezas únicas</p>
            </div>
            <div className="text-center">
              <p className="text-3xl font-light text-white">47</p>
              <p className="text-sm text-gray-400">suscriptores</p>
            </div>
          </div>

          {/* CTA to scroll */}
          <Button
            size="lg"
            className="bg-accent hover:bg-accent/90 text-accent-foreground font-medium h-14 px-8 text-lg"
            onClick={() => {
              document.querySelector("[data-email-capture-section]")?.scrollIntoView({ behavior: "smooth" })
            }}
          >
            Quiero apoyar a Daniel
            <Heart className="ml-2 w-5 h-5" />
          </Button>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/30 rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-2 bg-white/50 rounded-full" />
          </div>
        </div>
      </section>

      {/* Story Section */}
      <StorySection />

      <section className="py-20 px-6 bg-secondary/50" data-email-capture-section>
        <div className="max-w-3xl mx-auto">
          <div className="mb-12 text-center">
            <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">Haz la diferencia</p>
            <h2 className="text-4xl md:text-5xl font-light mb-6 text-balance">Tu suscripción cambia una vida</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              No es solo una transacción. Es un acto de fe en el arte neurodivergente y en un artista que necesita de tu
              apoyo para seguir creando.
            </p>
          </div>

          {/* Impacto emocional */}
          <div className="bg-accent/5 border border-accent/20 rounded-lg p-8 mb-12">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center flex-shrink-0">
                <Heart className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="text-xl font-medium mb-3">Lo que tu apoyo significa para mí</h3>
                <p className="text-lg text-muted-foreground leading-relaxed mb-4">
                  Como artista neurodivergente, el mundo del arte tradicional no siempre ha sido amable conmigo. Las
                  galerías pueden ser abrumadoras. Las negociaciones, agotadoras. Pero{" "}
                  <span className="text-foreground font-medium">
                    tu suscripción me permite enfocarme en lo que sé hacer: crear
                  </span>
                  .
                </p>
                <p className="text-lg text-muted-foreground leading-relaxed">
                  Cada mes que me apoyas, es un mes más donde puedo dedicarme al torno, experimentar con nuevas técnicas
                  y preparar mi viaje a Japón para aprender el kintsugi de los maestros.
                </p>
              </div>
            </div>
          </div>

          {/* Beneficios con iconos */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="space-y-4 text-center">
              <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center mx-auto">
                <Sparkles className="w-7 h-7 text-accent" />
              </div>
              <h3 className="text-xl font-medium">Contenido Exclusivo</h3>
              <p className="text-muted-foreground">
                Videos del proceso creativo, tutoriales y acceso a mi diario de artista
              </p>
            </div>

            <div className="space-y-4 text-center">
              <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center mx-auto">
                <Users className="w-7 h-7 text-accent" />
              </div>
              <h3 className="text-xl font-medium">Comunidad Cercana</h3>
              <p className="text-muted-foreground">
                Únete a otros mecenas que creen en el arte diferente y la neurodivergencia
              </p>
            </div>

            <div className="space-y-4 text-center">
              <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center mx-auto">
                <Star className="w-7 h-7 text-accent" />
              </div>
              <h3 className="text-xl font-medium">Prioridad en Piezas</h3>
              <p className="text-muted-foreground">Acceso anticipado a nuevas creaciones y descuentos exclusivos</p>
            </div>
          </div>

          {/* Cita de impacto */}
          <blockquote className="border-l-4 border-accent pl-6 py-4 mb-12">
            <p className="text-xl italic text-muted-foreground">
              "Apoyar a Daniel no es caridad. Es invertir en una visión del mundo que solo un artista neurodivergente
              puede ofrecer."
            </p>
            <footer className="text-sm text-accent mt-2">— María G., suscriptora desde 2024</footer>
          </blockquote>

          {/* Email Capture mejorado */}
          <div className="bg-gradient-to-br from-accent/15 to-accent/5 rounded-2xl p-8 border border-accent/20">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Shield className="w-5 h-5 text-accent" />
              <span className="text-sm text-accent font-medium">Cancela cuando quieras</span>
            </div>

            <h3 className="text-2xl md:text-3xl font-light mb-2 text-center">Comienza a apoyar hoy</h3>
            <p className="text-muted-foreground text-center mb-6">Desde $99 MXN/mes puedes hacer la diferencia</p>

            <form onSubmit={handleSubmit} className="space-y-4 max-w-md mx-auto">
              <div>
                <Input
                  type="email"
                  placeholder="tu@email.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value)
                    setError("")
                  }}
                  className="bg-background border-accent/30 h-14 text-lg text-center"
                  autoComplete="email"
                />
                {error && <p className="text-red-500 text-sm mt-2 text-center">{error}</p>}
              </div>

              <Button
                type="submit"
                className="w-full h-14 bg-accent hover:bg-accent/90 text-accent-foreground font-medium text-lg"
              >
                Ver Planes de Suscripción
              </Button>

              <p className="text-xs text-muted-foreground text-center">
                Tu email está seguro. No compartimos datos con terceros.
              </p>
            </form>
          </div>
        </div>
      </section>
    </div>
  )
}
