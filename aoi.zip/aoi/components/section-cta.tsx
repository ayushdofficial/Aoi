"use client"

import { Button } from "@/components/ui/button"

interface SectionCTAProps {
  text?: string
  variant?: "default" | "subtle" | "accent"
  scrollTarget?: string
}

export function SectionCTA({ text = "Únete al viaje", variant = "default", scrollTarget }: SectionCTAProps) {
  const handleClick = () => {
    if (scrollTarget) {
      const element = document.querySelector(scrollTarget)
      element?.scrollIntoView({ behavior: "smooth" })
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  const variants = {
    default: "bg-accent hover:bg-accent/90 text-accent-foreground",
    subtle: "bg-secondary hover:bg-secondary/80 text-foreground",
    accent: "bg-primary hover:bg-primary/90 text-primary-foreground",
  }

  return (
    <div className="flex justify-center mt-8">
      <Button
        onClick={handleClick}
        className={`h-12 px-8 text-lg font-medium transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-accent/20 ${variants[variant]}`}
      >
        {text}
      </Button>
    </div>
  )
}
