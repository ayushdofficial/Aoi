"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Check, Sparkles } from "lucide-react"
import { useRouter } from "next/navigation"

export function ImprovedEmailCapture() {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      setIsSubmitted(true)
      setTimeout(() => {
        router.push("/recompensas")
      }, 1500)
    }
  }

  const benefits = [
    "Actualizaciones exclusivas del viaje a Japón",
    "Acceso anticipado a nuevas piezas",
    "Fotos privadas del proceso creativo",
    "Participa en las votaciones de la comunidad",
    "Mini eBook sobre cerámica japonesa (PDF)",
    "Certificado digital de fundador",
  ]

  return (
    <section className="py-24 px-6 bg-gradient-to-br from-accent/10 via-background to-secondary/30">
      <div className="max-w-4xl mx-auto">
        <div className="bg-card border border-accent/20 rounded-sm p-8 md:p-12 shadow-2xl">
          <div className="text-center mb-8">
            <div className="inline-block p-3 bg-accent/10 rounded-full mb-4">
              <Sparkles className="w-8 h-8 text-accent" />
            </div>
            <h2 className="text-3xl md:text-5xl font-light mb-4">
              Únete al <span className="text-accent font-medium">viaje antes del lanzamiento</span>
            </h2>
            <p className="text-xl text-muted-foreground">
              Los primeros en registrarse recibirán beneficios exclusivos que no estarán disponibles después.
            </p>
          </div>

          {!isSubmitted ? (
            <>
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 mb-8">
                <Input
                  type="email"
                  placeholder="Tu correo electrónico"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-14 px-6 text-lg bg-background/80 backdrop-blur-sm border-border/50 focus:border-accent transition-all duration-300 hover:border-accent/50"
                  required
                />
                <Button
                  type="submit"
                  className="h-14 px-8 text-lg bg-accent hover:bg-accent/90 text-accent-foreground transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-accent/20 whitespace-nowrap"
                >
                  Quiero ser fundador
                </Button>
              </form>

              <div className="grid sm:grid-cols-2 gap-3">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-accent shrink-0 mt-0.5" />
                    <span className="text-sm text-muted-foreground">{benefit}</span>
                  </div>
                ))}
              </div>

              <p className="text-center text-sm text-muted-foreground mt-6">
                Sin spam. Solo actualizaciones valiosas del proyecto. Cancela cuando quieras.
              </p>
            </>
          ) : (
            <div className="text-center py-8 animate-success-notification">
              <div className="inline-block p-4 bg-accent/20 rounded-full mb-4">
                <Check className="w-12 h-12 text-accent" />
              </div>
              <h3 className="text-2xl font-medium mb-2">¡Bienvenido al viaje!</h3>
              <p className="text-muted-foreground">Redirigiendo a tus recompensas...</p>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
