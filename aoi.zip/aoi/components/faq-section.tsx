"use client"

import { useEffect, useRef, useState } from "react"
import { ChevronDown } from "lucide-react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function FAQSection() {
  const header = useScrollAnimation()
  const faqList = useScrollAnimation()
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const faqs = [
    {
      question: "How does crowdfunding work?",
      answer:
        "The project will be run on Kickstarter, an all-or-nothing crowdfunding platform. This means if we reach the funding goal, all backers will be charged and rewards will be delivered. If we don't reach the goal, nobody is charged. Your support is only processed once we succeed together.",
    },
    {
      question: "When do you travel to Japan?",
      answer:
        "The trip to Japan is scheduled for August 2026. I'll attend the Toma House AIR residency in Narita for one month of intensive kintsugi training. If we exceed our goal, I'll extend the trip to visit ceramic villages.",
    },
    {
      question: "How will we receive the rewards?",
      answer:
        "Rewards from this page will be sent as soon as the user contributes. Links to join Discord will be sent via email within 48 hours of your contribution. Rewards from the Kickstarter campaign will be sent once the campaign succeeds.",
    },
    {
      question: "What language will the live streams be in?",
      answer:
        "Live streams will be in Spanish, as Daniel only speaks Spanish. However, we'll do our best so that project supporters can hear it in English or another language if possible, through subtitles or translated summaries.",
    },
    {
      question: "What language is the project in?",
      answer:
        "The project and main communications are in Spanish. Live streams will be in Spanish, as Daniel only speaks Spanish, but we'll do our best to offer translated content (subtitles, summaries) in English or other languages for international backers.",
    },
    {
      question: "How long do handmade pieces take?",
      answer:
        "Estimated 1 to 2 months due to the number of supporters in the Kickstarter project. Handmade ceramics require time and care. Each piece is unique and made with intention. News, photos, and other updates will always be shared through Discord.",
    },
    {
      question: "What if a piece arrives damaged?",
      answer:
        "If any ceramic piece arrives damaged, simply send me a photo and I'll replace it. I use professional packaging designed for fragile ceramics to minimize this risk.",
    },
    {
      question: "Can I upgrade my tier later?",
      answer:
        "Yes! During the campaign, you can upgrade your support at any time. After the campaign ends, upgrading may be possible depending on availability—just contact me directly.",
    },
  ]

  return (
    <section className="py-24 px-6 bg-secondary/30 overflow-hidden">
      <div className="max-w-3xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-16 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">Questions</p>
          <h2 className="text-4xl md:text-6xl font-light mb-6">Frequently Asked</h2>
          <div className="flex justify-center mb-6">
            <div
              className={`h-0.5 bg-gradient-to-r from-transparent via-accent to-transparent transition-all duration-1000 delay-300 ${
                header.isVisible ? "w-32" : "w-0"
              }`}
            />
          </div>
        </div>

        <div ref={faqList.ref} className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className={`border border-border/50 rounded-sm overflow-hidden transition-all duration-700 ${
                faqList.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              } ${openIndex === index ? "border-accent/50 bg-card" : "bg-background hover:border-accent/30"}`}
              style={{ transitionDelay: `${index * 50}ms` }}
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-6 py-5 flex items-center justify-between text-left"
              >
                <span className="font-medium text-lg pr-4">{faq.question}</span>
                <ChevronDown
                  className={`w-5 h-5 text-accent shrink-0 transition-transform duration-300 ${
                    openIndex === index ? "rotate-180" : ""
                  }`}
                />
              </button>
              <div
                className={`grid transition-all duration-300 ${
                  openIndex === index ? "grid-rows-[1fr]" : "grid-rows-[0fr]"
                }`}
              >
                <div className="overflow-hidden">
                  <p className="px-6 pb-5 text-base text-muted-foreground leading-relaxed">{faq.answer}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <SectionCTA text="Ready to join?" variant="subtle" />
      </div>
    </section>
  )
}
