<section class="section bg-white">
    <div class="container animate-on-scroll">
        <div class="section-header">
            <p style="text-transform: uppercase; letter-spacing: 0.2em; color: var(--accent); margin-bottom: 16px;">Galería</p>
            <h2 class="section-title">Mi Trabajo</h2>
            <p class="section-subtitle">Cada pieza lleva tiempo, intención y un fragmento de mi viaje como ceramista</p>
        </div>
        
        <div class="gallery-grid">
            <div class="gallery-item">
                <div style="width: 100%; height: 100%; background: var(--muted);"></div>
                <div class="gallery-overlay">
                    <h3 style="font-size: 1.25rem; margin-bottom: 8px;">Vasija del Silencio</h3>
                    <p style="font-size: 0.875rem; opacity: 0.9;">Gres modelado a mano</p>
                </div>
            </div>
            <div class="gallery-item">
                <div style="width: 100%; height: 100%; background: var(--muted);"></div>
                <div class="gallery-overlay">
                    <h3 style="font-size: 1.25rem; margin-bottom: 8px;">Memoria Reparada</h3>
                    <p style="font-size: 0.875rem; opacity: 0.9;">Técnica kintsugi</p>
                </div>
            </div>
            <div class="gallery-item">
                <div style="width: 100%; height: 100%; background: var(--muted);"></div>
                <div class="gallery-overlay">
                    <h3 style="font-size: 1.25rem; margin-bottom: 8px;">Susurros en Arcilla</h3>
                    <p style="font-size: 0.875rem; opacity: 0.9;">Pieza escultórica</p>
                </div>
            </div>
            <div class="gallery-item">
                <div style="width: 100%; height: 100%; background: var(--muted);"></div>
                <div class="gallery-overlay">
                    <h3 style="font-size: 1.25rem; margin-bottom: 8px;">Tierra y Raíz</h3>
                    <p style="font-size: 0.875rem; opacity: 0.9;">Colección de macetas</p>
                </div>
            </div>
            <div class="gallery-item">
                <div style="width: 100%; height: 100%; background: var(--muted);"></div>
                <div class="gallery-overlay">
                    <h3 style="font-size: 1.25rem; margin-bottom: 8px;">Ceremonia del Té</h3>
                    <p style="font-size: 0.875rem; opacity: 0.9;">Tazón wabi-sabi</p>
                </div>
            </div>
            <div class="gallery-item">
                <div style="width: 100%; height: 100%; background: var(--muted);"></div>
                <div class="gallery-overlay">
                    <h3 style="font-size: 1.25rem; margin-bottom: 8px;">Fracturas Doradas</h3>
                    <p style="font-size: 0.875rem; opacity: 0.9;">Técnica mixta</p>
                </div>
            </div>
        </div>
    </div>
</section>
