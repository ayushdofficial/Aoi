"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Check, ArrowLeft, Heart, Sparkles, Star, Users } from "lucide-react"

interface SubscriptionStep3Props {
  email: string
  planId: string
  onBack: () => void
}

export function SubscriptionStep3({ email, planId, onBack }: SubscriptionStep3Props) {
  const plans = {
    observer: { name: "Observador", price: "$99 MXN/mes", color: "bg-blue-500" },
    collector: { name: "Coleccionista", price: "$299 MXN/mes", color: "bg-purple-500" },
    patron: { name: "Mecenas", price: "$599 MXN/mes", color: "bg-amber-500" },
  }

  const selectedPlan = plans[planId as keyof typeof plans] || plans.observer

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-accent/10 py-4 px-6">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Button variant="ghost" onClick={onBack} className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Cambiar plan
          </Button>
          <p className="text-sm text-muted-foreground">{email}</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-16">
        {/* Success Header */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-6 animate-success-notification">
            <Check className="w-10 h-10 text-accent" />
          </div>
          <h1 className="text-4xl md:text-5xl font-light mb-4">Un paso más...</h1>
          <p className="text-xl text-muted-foreground">Estás a punto de apoyar el arte neurodivergente</p>
        </div>

        {/* Plan Summary Card */}
        <Card className="p-8 mb-8 border-accent/20">
          <div className="flex items-start justify-between mb-6">
            <div>
              <p className="text-sm text-muted-foreground mb-2">Plan seleccionado</p>
              <h2 className="text-3xl font-light mb-2">{selectedPlan.name}</h2>
              <p className="text-2xl text-accent font-medium">{selectedPlan.price}</p>
            </div>
            <div className={`w-16 h-16 ${selectedPlan.color} rounded-xl flex items-center justify-center`}>
              <Heart className="w-8 h-8 text-white" />
            </div>
          </div>

          <div className="border-t border-accent/10 pt-6 space-y-4">
            <div className="flex items-start gap-3">
              <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Contenido exclusivo mensual</p>
                <p className="text-sm text-muted-foreground">Videos, tutoriales y diario del artista</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Comunidad privada</p>
                <p className="text-sm text-muted-foreground">Acceso a grupo de mecenas</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium">Descuentos exclusivos</p>
                <p className="text-sm text-muted-foreground">En todas las piezas cerámicas</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Payment Options */}
        <div className="space-y-4 mb-8">
          <h3 className="text-xl font-medium mb-4">Elige tu método de pago</h3>

          <Button
            size="lg"
            className="w-full h-16 bg-accent hover:bg-accent/90 text-accent-foreground justify-between text-lg"
            onClick={() => {
              // Simular procesamiento de pago
              alert("Redirigiendo al proceso de pago seguro...")
            }}
          >
            <span>Pagar con tarjeta</span>
            <span className="font-bold">{selectedPlan.price}</span>
          </Button>

          <Button
            size="lg"
            variant="outline"
            className="w-full h-16 border-2 border-accent/30 hover:bg-accent/5 justify-between text-lg bg-transparent"
            onClick={() => {
              alert("Redirigiendo a PayPal...")
            }}
          >
            <span>Pagar con PayPal</span>
            <span className="font-semibold">{selectedPlan.price}</span>
          </Button>
        </div>

        {/* Trust Indicators */}
        <div className="bg-secondary/30 rounded-lg p-6 mb-8">
          <div className="grid md:grid-cols-3 gap-6 text-center">
            <div>
              <Sparkles className="w-8 h-8 text-accent mx-auto mb-2" />
              <p className="text-sm font-medium mb-1">Cancela cuando quieras</p>
              <p className="text-xs text-muted-foreground">Sin compromisos ni penalizaciones</p>
            </div>
            <div>
              <Star className="w-8 h-8 text-accent mx-auto mb-2" />
              <p className="text-sm font-medium mb-1">Pago 100% seguro</p>
              <p className="text-xs text-muted-foreground">Protegido por Stripe</p>
            </div>
            <div>
              <Users className="w-8 h-8 text-accent mx-auto mb-2" />
              <p className="text-sm font-medium mb-1">47 mecenas activos</p>
              <p className="text-xs text-muted-foreground">Ya apoyan este proyecto</p>
            </div>
          </div>
        </div>

        {/* What Happens Next */}
        <div className="border border-accent/20 rounded-lg p-8 mb-8">
          <h3 className="text-2xl font-light mb-6">Qué sucede después</h3>
          <div className="space-y-6">
            <div className="flex gap-4">
              <div className="w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold text-accent">
                1
              </div>
              <div>
                <p className="font-medium mb-1">Recibes un correo de bienvenida</p>
                <p className="text-sm text-muted-foreground">
                  Con acceso a la comunidad privada y contenido exclusivo inmediato
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold text-accent">
                2
              </div>
              <div>
                <p className="font-medium mb-1">Se te cobra mensualmente</p>
                <p className="text-sm text-muted-foreground">
                  El mismo día cada mes. Puedes cancelar en cualquier momento desde tu panel
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold text-accent">
                3
              </div>
              <div>
                <p className="font-medium mb-1">Tu apoyo hace la diferencia</p>
                <p className="text-sm text-muted-foreground">
                  Cada peso va directamente a permitir que Daniel se enfoque en crear arte único
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Final Message from Artist */}
        <div className="bg-gradient-to-br from-accent/10 to-accent/5 rounded-lg p-8 border border-accent/20">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center flex-shrink-0">
              <span className="text-3xl">🎨</span>
            </div>
            <div>
              <h3 className="text-xl font-medium mb-3">Un mensaje de Daniel</h3>
              <p className="text-lg text-muted-foreground leading-relaxed mb-4">
                Gracias por creer en mi arte y en el poder de la neurodivergencia. Tu apoyo me permite dedicar mi vida a
                crear piezas que celebran la imperfección y la belleza de lo roto reparado con oro.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed italic">
                Cada mes que me apoyas, es un paso más cerca de mi viaje a Japón para aprender kintsugi con los maestros
                tradicionales. Juntos, estamos haciendo posible este sueño.
              </p>
              <p className="text-accent font-medium mt-4">Con gratitud, Daniel</p>
            </div>
          </div>
        </div>

        {/* Legal */}
        <p className="text-xs text-muted-foreground text-center mt-8">
          Al continuar, aceptas nuestros{" "}
          <button className="underline hover:text-foreground">términos de servicio</button> y{" "}
          <button className="underline hover:text-foreground">política de privacidad</button>. Puedes cancelar tu
          suscripción en cualquier momento desde tu panel de control.
        </p>
      </div>
    </div>
  )
}
