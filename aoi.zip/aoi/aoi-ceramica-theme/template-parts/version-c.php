<!-- Version C: Timeline - Timeline storytelling approach -->
<section class="hero-section" style="background: var(--cream);">
    <div class="container hero-content">
        <p style="text-transform: uppercase; letter-spacing: 0.2em; color: var(--accent); margin-bottom: 1rem;">Mi Viaje</p>
        <h1 class="hero-title">Una historia de transformación</h1>
        <p class="hero-subtitle">De México a Japón: 22 años de cerámica, un sueño por cumplir</p>
        <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; margin-top: 32px;">
            <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-primary btn-lg">Apoya el viaje</a>
        </div>
    </div>
</section>

<section class="section bg-white">
    <div class="container" style="max-width: 900px;">
        <div class="section-header">
            <h2 class="section-title">El camino hasta aquí</h2>
        </div>
        <div class="timeline">
            <div class="timeline-line"></div>
            <div class="timeline-item">
                <div style="text-align: right;">
                    <p style="font-size: 2rem; font-weight: 700; color: var(--accent); margin-bottom: 8px;">2003</p>
                    <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">Primeros pasos</h3>
                    <p style="color: var(--muted-foreground);">A los 12 años, comienzo mi formación formal con mi padre y el maestro Alberto.</p>
                </div>
                <div class="timeline-dot"></div>
                <div></div>
            </div>
            <div class="timeline-item">
                <div></div>
                <div class="timeline-dot"></div>
                <div>
                    <p style="font-size: 2rem; font-weight: 700; color: var(--accent); margin-bottom: 8px;">2017</p>
                    <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">Taller Huellas de Agua</h3>
                    <p style="color: var(--muted-foreground);">Comienzo con la maestra Irma Giménez, profundizando en técnicas avanzadas.</p>
                </div>
            </div>
            <div class="timeline-item">
                <div style="text-align: right;">
                    <p style="font-size: 2rem; font-weight: 700; color: var(--accent); margin-bottom: 8px;">2018</p>
                    <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">Descubriendo el Kintsugi</h3>
                    <p style="color: var(--muted-foreground);">Me fascina la filosofía japonesa de reparar fracturas con oro.</p>
                </div>
                <div class="timeline-dot"></div>
                <div></div>
            </div>
            <div class="timeline-item">
                <div></div>
                <div class="timeline-dot"></div>
                <div>
                    <p style="font-size: 2rem; font-weight: 700; color: var(--accent); margin-bottom: 8px;">2026</p>
                    <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">El Viaje a Japón</h3>
                    <p style="color: var(--muted-foreground);">Un mes de inmersión en la cultura del kintsugi y cerámica japonesa en agosto 2026.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/sections/story'); ?>
<?php get_template_part('template-parts/sections/gallery'); ?>
<?php get_template_part('template-parts/sections/email-capture'); ?>
<?php get_template_part('template-parts/sections/faq'); ?>
