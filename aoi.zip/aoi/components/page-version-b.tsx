import { HeroSectionB } from "@/components/hero-section-b"
import { EmailCaptureWithImage } from "@/components/email-capture-with-image"
import { GallerySectionOptimized } from "@/components/gallery-section-optimized"
import { StorySection } from "@/components/story-section"
import { WhySupportSection } from "@/components/why-support-section"
import { BenefitsSectionWithImages } from "@/components/benefits-section-with-images"
import { TrustSection } from "@/components/trust-section"
import { FinalCTA } from "@/components/final-cta"
import { FAQSection } from "@/components/faq-section"

export function PageVersionB() {
  return (
    <>
      <HeroSectionB />
      <EmailCaptureWithImage />
      <GallerySectionOptimized />
      <StorySection />
      <WhySupportSection />
      <BenefitsSectionWithImages />
      <TrustSection />
      <FAQSection />
      <FinalCTA />
    </>
  )
}
