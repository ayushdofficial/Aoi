"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowRight, Mail } from "lucide-react"
import Image from "next/image"

export function CTASectionH() {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      localStorage.setItem("userEmail", email)
      setIsSubmitted(true)
      setTimeout(() => {
        window.location.href = "/recompensas"
      }, 1500)
    }
  }

  return (
    <section className="relative py-32 px-6 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/beautiful-ceramic-workshop-in-japan-with-golden-li.jpg"
          alt="Workshop background"
          fill
          className="object-cover"
          quality={90}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/70 to-black/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <div className="inline-block bg-accent/20 border border-accent/40 rounded-full px-6 py-2 mb-8 backdrop-blur-sm">
          <span className="text-sm uppercase tracking-widest text-accent font-medium">Start your journey</span>
        </div>

        <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-white text-balance">
          Be part of this
          <span className="block text-accent">golden story</span>
        </h2>

        <p className="text-xl text-white/90 max-w-2xl mx-auto mb-12 leading-relaxed text-pretty">
          Enter your email to discover exclusive rewards and be part of this cultural adventure
        </p>

        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <div className="relative flex-1">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="h-14 pl-12 text-lg bg-background/90 backdrop-blur-sm border-border"
                />
              </div>
              <Button
                type="submit"
                size="lg"
                className="h-14 px-8 text-lg bg-accent hover:bg-accent/90 text-accent-foreground transition-all duration-300 hover:scale-105 group"
              >
                Continue
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
            <p className="text-sm text-white/60">
              By continuing, you agree to receive information about the project. No spam, we promise.
            </p>
          </form>
        ) : (
          <div className="bg-accent/20 border border-accent/40 rounded-2xl p-8 max-w-md mx-auto backdrop-blur-sm animate-fade-in-scale">
            <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-accent" />
            </div>
            <p className="text-xl font-semibold text-white mb-2">Excellent!</p>
            <p className="text-white/80">Redirecting to rewards...</p>
          </div>
        )}
      </div>
    </section>
  )
}
