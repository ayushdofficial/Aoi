<!-- Version I: Patreon - Main 3-step Patreon-focused flow -->
<section class="hero-section" style="background: var(--cream);">
    <div class="container">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 48px; align-items: center;">
            <div>
                <div style="display: inline-block; background: rgba(255,83,73,0.1); color: var(--accent); padding: 8px 16px; border-radius: 20px; font-size: 0.875rem; font-weight: 700; margin-bottom: 16px;">
                    ✨ Un proyecto único y auténtico
                </div>
                <h1 style="font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 700; line-height: 1.1; margin-bottom: 24px;">
                    Apoya el arte de<br/>
                    <span style="color: var(--accent);">transformar lo roto</span>
                </h1>
                <p style="font-size: 1.25rem; color: var(--muted-foreground); margin-bottom: 32px; line-height: 1.6;">
                    Soy Daniel, ceramista neurodivergente de México. Estoy preparando mi viaje a Japón para aprender kintsugi con los maestros. Tu apoyo hace posible este sueño.
                </p>
                <div style="display: flex; gap: 16px; flex-wrap: wrap;">
                    <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-primary btn-lg">
                        Únete en Patreon →
                    </a>
                    <button onclick="document.querySelector('[data-story-section]').scrollIntoView({behavior: 'smooth'})" class="btn btn-outline btn-lg">
                        Conoce mi historia
                    </button>
                </div>
                <div style="display: flex; align-items: center; gap: 24px; margin-top: 32px;">
                    <div style="display: flex; margin-left: -8px;">
                        <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--muted); border: 2px solid var(--cream);"></div>
                        <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--muted); border: 2px solid var(--cream); margin-left: -12px;"></div>
                        <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--accent); border: 2px solid var(--cream); margin-left: -12px; display: flex; align-items: center; justify-center; color: white; font-size: 0.75rem; font-weight: 700;">+47</div>
                    </div>
                    <p style="font-size: 0.875rem; color: var(--muted-foreground);">
                        <strong style="color: var(--foreground);">47 mecenas</strong> ya están apoyando este proyecto
                    </p>
                </div>
            </div>
            <div style="position: relative;">
                <div style="aspect-ratio: 4/5; border-radius: 24px; overflow: hidden; box-shadow: 0 20px 60px rgba(0,0,0,0.15);">
                    <div style="width: 100%; height: 100%; background: var(--muted);"></div>
                </div>
                <div style="position: absolute; bottom: -24px; left: -24px; background: white; border-radius: 16px; padding: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); border: 2px solid rgba(255,83,73,0.2); max-width: 280px;">
                    <div style="display: flex; gap: 12px; align-items: center;">
                        <div style="width: 48px; height: 48px; background: rgba(255,83,73,0.1); border-radius: 50%; display: flex; align-items: center; justify-center;">
                            <span style="font-size: 1.5rem;">❤️</span>
                        </div>
                        <div>
                            <div style="font-weight: 700;">Desde $99 MXN/mes</div>
                            <div style="font-size: 0.875rem; color: var(--muted-foreground);">Cancela cuando quieras</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section bg-white" data-story-section>
    <div class="container">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 48px; align-items: center;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div style="display: flex; flex-direction: column; gap: 16px;">
                    <div style="aspect-ratio: 1; border-radius: 16px; background: var(--muted); overflow: hidden;"></div>
                    <div style="aspect-ratio: 1; border-radius: 16px; background: var(--muted); overflow: hidden;"></div>
                </div>
                <div style="display: flex; flex-direction: column; gap: 16px; padding-top: 32px;">
                    <div style="aspect-ratio: 1; border-radius: 16px; background: var(--muted); overflow: hidden;"></div>
                    <div style="aspect-ratio: 1; border-radius: 16px; background: var(--muted); overflow: hidden;"></div>
                </div>
            </div>
            <div>
                <div style="display: inline-block; background: rgba(255,83,73,0.1); color: var(--accent); padding: 8px 16px; border-radius: 20px; font-size: 0.875rem; font-weight: 700; margin-bottom: 16px;">
                    Mi historia
                </div>
                <h2 style="font-size: 2.5rem; font-weight: 700; margin-bottom: 24px;">De México a Japón: fusionando tradiciones</h2>
                <div style="space-y: 16px;">
                    <p style="font-size: 1.125rem; color: var(--muted-foreground); line-height: 1.7; margin-bottom: 16px;">
                        Soy un artista ceramista de México, neurodivergente y apasionado por crear piezas que cuentan historias de transformación. Llevo 22 años trabajando con arcilla, desde que tenía 12 años.
                    </p>
                    <p style="font-size: 1.125rem; color: var(--muted-foreground); line-height: 1.7; margin-bottom: 16px;">
                        El kintsugi es el arte japonés de reparar cerámica rota con oro, celebrando las imperfecciones en lugar de ocultarlas. Como persona neurodivergente, esta filosofía resuena profundamente conmigo.
                    </p>
                    <p style="font-size: 1.125rem; font-weight: 600; color: var(--foreground);">
                        Mi sueño es viajar a Japón para aprender esta técnica con maestros tradicionales y fusionarla con la rica herencia de la cerámica mexicana.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section bg-secondary">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Al unirte en Patreon, obtienes</h2>
            <p class="section-subtitle">No es solo apoyo financiero. Es formar parte de una comunidad que cree en el arte auténtico</p>
        </div>
        <div class="tiers-grid">
            <div class="tier-card">
                <div style="width: 64px; height: 64px; background: rgba(255,83,73,0.1); border-radius: 16px; display: flex; align-items: center; justify-center; margin-bottom: 24px;">
                    <span style="font-size: 2rem;">🎥</span>
                </div>
                <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 16px;">Contenido exclusivo</h3>
                <p style="color: var(--muted-foreground); line-height: 1.6;">
                    Videos del proceso creativo, tutoriales de técnicas, y acceso a mi diario de artista.
                </p>
            </div>
            <div class="tier-card">
                <div style="width: 64px; height: 64px; background: rgba(255,83,73,0.1); border-radius: 16px; display: flex; align-items: center; justify-center; margin-bottom: 24px;">
                    <span style="font-size: 2rem;">👥</span>
                </div>
                <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 16px;">Comunidad cercana</h3>
                <p style="color: var(--muted-foreground); line-height: 1.6;">
                    Únete a otros mecenas que celebran el arte diferente y la neurodivergencia.
                </p>
            </div>
            <div class="tier-card">
                <div style="width: 64px; height: 64px; background: rgba(255,83,73,0.1); border-radius: 16px; display: flex; align-items: center; justify-center; margin-bottom: 24px;">
                    <span style="font-size: 2rem;">⭐</span>
                </div>
                <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 16px;">Acceso prioritario</h3>
                <p style="color: var(--muted-foreground); line-height: 1.6;">
                    Sé el primero en ver nuevas creaciones y participa en decisiones creativas.
                </p>
            </div>
        </div>
    </div>
</section>

<section class="section" style="background: linear-gradient(135deg, var(--accent) 0%, var(--terracotta) 100%); color: white; text-align: center;">
    <div class="container" style="max-width: 800px;">
        <div style="width: 80px; height: 80px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; align-items: center; justify-center; margin: 0 auto 24px;">
            <span style="font-size: 2.5rem;">✨</span>
        </div>
        <h2 style="font-size: 3rem; font-weight: 700; margin-bottom: 24px; color: white;">Sé parte de esta historia</h2>
        <p style="font-size: 1.25rem; margin-bottom: 32px; color: rgba(255,255,255,0.9); line-height: 1.6;">
            Desde $99 MXN al mes, puedes hacer la diferencia en la vida de un artista y ser testigo de un viaje único.
        </p>
        <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-lg" style="background: white; color: var(--accent); box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
            Únete en Patreon ahora →
        </a>
        <p style="margin-top: 24px; color: rgba(255,255,255,0.8); font-size: 0.875rem;">Cancela cuando quieras • Sin compromisos • 100% transparente</p>
    </div>
</section>

<?php get_template_part('template-parts/sections/faq'); ?>
