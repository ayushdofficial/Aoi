import { Card } from "@/components/ui/card"
import { CheckCircle, Gift, Unlock, Users } from "lucide-react"

const onboardingSteps = [
  {
    title: "Te Unes a la Comunidad",
    description: "Acceso inmediato al Discord exclusivo",
    icon: Unlock,
  },
  {
    title: "Primeras Semanas",
    description: "Actualizaciones mensuales con fotos exclusivas del estudio",
    icon: Gift,
  },
  {
    title: "Primer Mes Completo",
    description: "Acceso a la biblioteca digital de técnicas en PDF",
    icon: CheckCircle,
  },
  {
    title: "Mes 3+",
    description: "Q&A en vivo, transmisiones desde Japón, votaciones",
    icon: Users,
  },
]

export function SubscriberOnboardingSection() {
  return (
    <section className="w-full py-20 px-4 bg-gradient-to-b from-muted/30 to-background">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">Lo Que Sucede Cuando Te Suscribes</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Tu viaje como mecenas comienza aquí</p>
        </div>

        <div className="space-y-6">
          {onboardingSteps.map((step, index) => {
            const Icon = step.icon
            return (
              <div key={index} className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-14 w-14 rounded-full bg-primary/20 border-2 border-primary/40">
                    <Icon className="h-7 w-7 text-primary" />
                  </div>
                </div>
                <Card className="flex-1 p-6 border border-border/50 hover:border-primary/50 transition-colors bg-card/50">
                  <h3 className="text-xl font-bold text-foreground mb-2">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </Card>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
