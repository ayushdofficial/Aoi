<?php
/**
 * Version I - Patreon Focus (3-Step Flow)
 * This is the primary version focusing on Patreon subscription
 * 
 * @package Aoi_Ceramica
 */
?>

<div class="version-content active" data-version="i">
    
    <!-- Hero Section -->
    <section class="hero bg-cream">
        <div class="container">
            <div class="grid grid-cols-2 gap-12 items-center">
                <!-- Left Content -->
                <div class="space-y-6">
                    <div class="inline-block bg-coral/10 text-coral px-4 py-2 rounded-full text-sm font-bold">
                        ✨ Un proyecto único y auténtico
                    </div>
                    
                    <h1 class="text-5xl lg:text-7xl font-bold text-charcoal">
                        Apoya el arte de
                        <span class="block text-coral mt-2">transformar lo roto</span>
                    </h1>
                    
                    <p class="text-xl text-charcoal/70 leading-relaxed">
                        Soy Daniel, ceramista neurodivergente de México. Estoy preparando mi viaje a Japón para 
                        aprender kintsugi con los maestros. Tu apoyo hace posible este sueño.
                    </p>
                    
                    <div class="flex flex-col sm:flex-row gap-4">
                        <a href="https://www.patreon.com/cw/aoi_kitsune" target="_blank" rel="noopener" 
                           class="btn btn-primary btn-lg btn-rounded">
                            Únete en Patreon
                            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                                <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3"/>
                            </svg>
                        </a>
                        <button class="btn btn-outline btn-lg btn-rounded" onclick="document.querySelector('[data-story-section]').scrollIntoView({behavior: 'smooth'})">
                            Conoce mi historia
                        </button>
                    </div>
                    
                    <div class="flex items-center gap-6 pt-6">
                        <div class="flex -space-x-3">
                            <div class="w-10 h-10 rounded-full bg-charcoal/20 border-2 border-cream"></div>
                            <div class="w-10 h-10 rounded-full bg-charcoal/30 border-2 border-cream"></div>
                            <div class="w-10 h-10 rounded-full bg-charcoal/40 border-2 border-cream"></div>
                            <div class="w-10 h-10 rounded-full bg-coral/30 border-2 border-cream flex items-center justify-center text-xs font-bold text-white">
                                +47
                            </div>
                        </div>
                        <p class="text-sm text-charcoal/60">
                            <span class="font-bold text-charcoal">47 mecenas</span> ya están apoyando este proyecto
                        </p>
                    </div>
                </div>
                
                <!-- Right Image -->
                <div class="relative">
                    <div class="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl">
                        <img src="<?php echo get_template_directory_uri(); ?>/images/ceramic-artist-working.jpg" 
                             alt="Daniel trabajando en su taller de cerámica"
                             class="w-full h-full object-cover">
                    </div>
                    
                    <!-- Floating Card -->
                    <div class="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-6 max-w-xs border-2 border-coral/20">
                        <div class="flex items-center gap-3 mb-3">
                            <div class="w-12 h-12 bg-coral/10 rounded-full flex items-center justify-center">
                                <svg width="24" height="24" fill="currentColor" class="text-coral" viewBox="0 0 24 24">
                                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                                </svg>
                            </div>
                            <div>
                                <div class="font-bold text-charcoal">Desde $99 MXN/mes</div>
                                <div class="text-sm text-charcoal/60">Cancela cuando quieras</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Story Section -->
    <section class="section bg-white" data-story-section>
        <div class="container">
            <div class="grid lg:grid-cols-2 gap-16 items-center">
                <!-- Image Grid -->
                <div class="grid grid-cols-2 gap-4">
                    <div class="space-y-4">
                        <div class="aspect-square rounded-2xl overflow-hidden shadow-lg">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/kintsugi-gold-repair.jpg" 
                                 alt="Kintsugi en proceso" class="w-full h-full object-cover">
                        </div>
                        <div class="aspect-square rounded-2xl overflow-hidden shadow-lg">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/mexican-pottery.jpg" 
                                 alt="Cerámica mexicana" class="w-full h-full object-cover">
                        </div>
                    </div>
                    <div class="space-y-4 pt-8">
                        <div class="aspect-square rounded-2xl overflow-hidden shadow-lg">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/japanese-studio.jpg" 
                                 alt="Taller de cerámica" class="w-full h-full object-cover">
                        </div>
                        <div class="aspect-square rounded-2xl overflow-hidden shadow-lg">
                            <img src="<?php echo get_template_directory_uri(); ?>/images/ceramic-hands.jpg" 
                                 alt="Manos trabajando arcilla" class="w-full h-full object-cover">
                        </div>
                    </div>
                </div>
                
                <!-- Content -->
                <div class="space-y-6">
                    <div class="inline-block bg-coral/10 text-coral px-4 py-2 rounded-full text-sm font-bold">
                        Mi historia
                    </div>
                    
                    <h2 class="text-4xl lg:text-5xl font-bold text-charcoal">
                        De México a Japón: fusionando tradiciones
                    </h2>
                    
                    <div class="space-y-4 text-lg text-charcoal/80">
                        <p>
                            Soy un artista ceramista de México, neurodivergente y apasionado por crear piezas que cuentan 
                            historias de transformación. Llevo 22 años trabajando con arcilla, desde que tenía 12 años.
                        </p>
                        <p>
                            El kintsugi es el arte japonés de reparar cerámica rota con oro, celebrando las imperfecciones 
                            en lugar de ocultarlas. Como persona neurodivergente, esta filosofía resuena profundamente conmigo.
                        </p>
                        <p>
                            En 2017, tuve el honor de empezar con la maestra 
                            <a href="https://www.instagram.com/huellas_de_agua/" target="_blank" class="text-coral font-semibold hover:underline">
                                Irma Giménez en el taller Huellas de Agua
                            </a>, donde profundicé en técnicas que transformaron mi práctica artística.
                        </p>
                        <p class="font-semibold text-charcoal">
                            Mi sueño es viajar a Japón para aprender esta técnica con maestros tradicionales y 
                            fusionarla con la rica herencia de la cerámica mexicana.
                        </p>
                    </div>
                    
                    <blockquote class="border-l-4 border-coral pl-6 py-2">
                        <p class="text-xl italic text-charcoal/80 font-medium">
                            "La neurodivergencia no es una limitación. Es la lente única que me permite ver 
                            belleza donde otros ven lo roto."
                        </p>
                        <footer class="text-sm text-charcoal/60 mt-2">— Aoi (@aoi_ceramica)</footer>
                    </blockquote>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Benefits Section -->
    <section class="section bg-cream">
        <div class="container">
            <div class="text-center mb-16">
                <h2 class="text-4xl lg:text-5xl font-bold text-charcoal mb-6">
                    Al unirte en Patreon, obtienes
                </h2>
                <p class="text-xl text-charcoal/70 max-w-2xl mx-auto">
                    No es solo apoyo financiero. Es formar parte de una comunidad que cree en el arte auténtico 
                    y la neurodiversidad.
                </p>
            </div>
            
            <div class="grid md:grid-cols-3 gap-8">
                <!-- Benefit 1 -->
                <div class="card hover:border-coral/20">
                    <div class="w-16 h-16 bg-coral/10 rounded-2xl flex items-center justify-center mb-6">
                        <svg width="32" height="32" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" class="text-coral">
                            <path d="M23 7l-7 5 7 5V7zM14 5H3c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2z"/>
                        </svg>
                    </div>
                    <h3 class="text-2xl font-bold text-charcoal mb-4">Contenido exclusivo</h3>
                    <p class="text-charcoal/70 leading-relaxed">
                        Videos del proceso creativo, tutoriales de técnicas, y acceso a mi diario de artista. 
                        Ve cómo cada pieza cobra vida desde la primera pincelada.
                    </p>
                </div>
                
                <!-- Benefit 2 -->
                <div class="card hover:border-coral/20">
                    <div class="w-16 h-16 bg-coral/10 rounded-2xl flex items-center justify-center mb-6">
                        <svg width="32" height="32" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24" class="text-coral">
                            <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/>
                        </svg>
                    </div>
                    <h3 class="text-2xl font-bold text-charcoal mb-4">Comunidad cercana</h3>
                    <p class="text-charcoal/70 leading-relaxed">
                        Únete a otros mecenas que celebran el arte diferente y la neurodivergencia. Conexión real, 
                        conversaciones auténticas, sin intermediarios.
                    </p>
                </div>
                
                <!-- Benefit 3 -->
                <div class="card hover:border-coral/20">
                    <div class="w-16 h-16 bg-coral/10 rounded-2xl flex items-center justify-center mb-6">
                        <svg width="32" height="32" fill="currentColor" viewBox="0 0 24 24" class="text-coral">
                            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                        </svg>
                    </div>
                    <h3 class="text-2xl font-bold text-charcoal mb-4">Acceso prioritario</h3>
                    <p class="text-charcoal/70 leading-relaxed">
                        Sé el primero en ver nuevas creaciones, recibe descuentos exclusivos en piezas y participa 
                        en decisiones creativas. Tu voz importa.
                    </p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Testimonials Section -->
    <section class="section bg-white">
        <div class="container">
            <div class="text-center mb-16">
                <h2 class="text-4xl lg:text-5xl font-bold text-charcoal mb-4">Voces de la comunidad</h2>
                <p class="text-xl text-charcoal/70">Lo que dicen quienes ya apoyan este proyecto</p>
            </div>
            
            <div class="testimonial-grid">
                <div class="testimonial-card">
                    <p class="text-charcoal/80 leading-relaxed mb-4">
                        "Apoyar a Daniel no es caridad. Es invertir en una visión del mundo que solo un artista 
                        neurodivergente puede ofrecer. Sus piezas son poesía visual."
                    </p>
                    <div class="testimonial-author">
                        <div class="testimonial-avatar"></div>
                        <div>
                            <div class="testimonial-name">María G.</div>
                            <div class="testimonial-role">Mecenas desde 2024</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card">
                    <p class="text-charcoal/80 leading-relaxed mb-4">
                        "Ver el proceso detrás de cada pieza es mágico. Daniel transforma la arcilla con una 
                        sensibilidad que nunca había visto. Vale cada peso."
                    </p>
                    <div class="testimonial-author">
                        <div class="testimonial-avatar"></div>
                        <div>
                            <div class="testimonial-name">Carlos M.</div>
                            <div class="testimonial-role">Mecenas desde 2023</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card">
                    <p class="text-charcoal/80 leading-relaxed mb-4">
                        "Su viaje a Japón será transformador. Me emociona ser parte de algo tan especial y auténtico. 
                        El arte neurodivergente merece ser celebrado."
                    </p>
                    <div class="testimonial-author">
                        <div class="testimonial-avatar"></div>
                        <div>
                            <div class="testimonial-name">Ana R.</div>
                            <div class="testimonial-role">Mecenas desde 2024</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- CTA Section -->
    <section class="section" style="background: linear-gradient(135deg, #ff6b6b 0%, #ee5a6f 100%);">
        <div class="container text-center" style="max-width: 800px;">
            <div class="mb-8">
                <div class="w-20 h-20 mx-auto mb-6 flex items-center justify-center" 
                     style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 50%;">
                    <svg width="40" height="40" fill="none" stroke="white" stroke-width="2" viewBox="0 0 24 24">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                    </svg>
                </div>
                <h2 class="text-4xl lg:text-6xl font-bold text-white mb-6">
                    Sé parte de esta historia
                </h2>
                <p class="text-xl text-white/90 mb-8">
                    Desde $99 MXN al mes, puedes hacer la diferencia en la vida de un artista y ser testigo de 
                    un viaje único: de México a Japón, del barro al oro.
                </p>
            </div>
            
            <a href="https://www.patreon.com/cw/aoi_kitsune" target="_blank" rel="noopener"
               class="btn btn-lg btn-rounded"
               style="background: white; color: #ff6b6b; font-size: 1.25rem; padding: 1.25rem 3rem; display: inline-flex; align-items: center; gap: 0.75rem;">
                Únete en Patreon ahora
                <svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M5 12h14M12 5l7 7-7 7"/>
                </svg>
            </a>
            
            <p class="text-white/80 text-sm mt-6">
                Cancela cuando quieras • Sin compromisos • 100% transparente
            </p>
            
            <div class="flex flex-wrap items-center justify-center gap-8 mt-12 pt-8" 
                 style="border-top: 1px solid rgba(255,255,255,0.2);">
                <div class="text-center">
                    <div class="text-3xl font-bold text-white">22</div>
                    <div class="text-sm text-white/80">años creando</div>
                </div>
                <div class="text-center">
                    <div class="text-3xl font-bold text-white">200+</div>
                    <div class="text-sm text-white/80">piezas únicas</div>
                </div>
                <div class="text-center">
                    <div class="text-3xl font-bold text-white">47</div>
                    <div class="text-sm text-white/80">mecenas activos</div>
                </div>
            </div>
        </div>
    </section>
    
</div>
