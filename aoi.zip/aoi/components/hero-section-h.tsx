"use client"

import { Button } from "@/components/ui/button"
import { Play, ChevronDown } from "lucide-react"
import Image from "next/image"

export function HeroSectionH() {
  const scrollToFeatures = () => {
    const element = document.getElementById("features-section-h")
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-background">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/elegant-ceramic-bowl-with-gold-kintsugi-repair-on-.jpg"
          alt="Ceramic art hero"
          fill
          className="object-cover"
          quality={95}
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-black/20 to-background" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 py-32 text-center">
        {/* Top badge */}
        <div className="inline-flex items-center gap-2 bg-accent/10 backdrop-blur-sm border border-accent/30 rounded-full px-6 py-2 mb-8 animate-fade-in-up">
          <span className="text-xs uppercase tracking-widest text-accent font-medium">Nuevo Proyecto</span>
        </div>

        {/* Main Title */}
        <h1
          className="text-6xl md:text-7xl lg:text-8xl font-bold leading-tight mb-6 text-balance animate-fade-in-up text-foreground"
          style={{ animationDelay: "0.1s", opacity: 0, animationFillMode: "forwards" }}
        >
          Cerámica que cuenta
          <span className="block text-accent">historias doradas</span>
        </h1>

        {/* Subtitle */}
        <p
          className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12 leading-relaxed text-pretty animate-fade-in-up"
          style={{ animationDelay: "0.2s", opacity: 0, animationFillMode: "forwards" }}
        >
          Un viaje único de México a Japón para dominar el arte del Kintsugi y crear piezas exclusivas hechas a mano
        </p>

        {/* CTA Buttons */}
        <div
          className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16 animate-fade-in-up"
          style={{ animationDelay: "0.3s", opacity: 0, animationFillMode: "forwards" }}
        >
          <Button
            size="lg"
            className="h-14 px-10 text-lg bg-accent hover:bg-accent/90 text-accent-foreground transition-all duration-300 hover:scale-105 shadow-lg"
          >
            Apoya el proyecto
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="h-14 px-10 text-lg border-2 transition-all duration-300 hover:scale-105 group bg-transparent"
          >
            <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" />
            Ver video
          </Button>
        </div>

        {/* Stats */}
        <div
          className="flex flex-wrap justify-center gap-8 md:gap-12 animate-fade-in-up"
          style={{ animationDelay: "0.4s", opacity: 0, animationFillMode: "forwards" }}
        >
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold text-accent mb-2">8</div>
            <div className="text-sm text-muted-foreground uppercase tracking-wider">Meses de aprendizaje</div>
          </div>
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold text-accent mb-2">1200+</div>
            <div className="text-sm text-muted-foreground uppercase tracking-wider">Apoyadores</div>
          </div>
          <div className="text-4xl md:text-5xl font-bold text-muted-foreground/30">|</div>
          <div className="text-center">
            <div className="text-4xl md:text-5xl font-bold text-accent mb-2">100%</div>
            <div className="text-sm text-muted-foreground uppercase tracking-wider">Hecho a mano</div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={scrollToFeatures}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce cursor-pointer bg-transparent border-none hover:scale-110 transition-transform"
        aria-label="Scroll to features"
      >
        <ChevronDown className="w-8 h-8 text-muted-foreground" />
      </button>
    </section>
  )
}
