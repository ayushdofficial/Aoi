"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useRouter } from "next/navigation"

export function FinalCTA() {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      setIsSubmitted(true)
      setTimeout(() => {
        router.push("/recompensas")
      }, 1500)
    }
  }

  return (
    <section className="py-24 px-6 bg-foreground text-background relative overflow-hidden">
      <div
        className="absolute top-0 left-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl animate-pulse"
        style={{ animationDuration: "4s" }}
      />
      <div
        className="absolute bottom-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl animate-pulse"
        style={{ animationDuration: "6s", animationDelay: "1s" }}
      />
      {/* </CHANGE> */}

      <div className="max-w-3xl mx-auto text-center relative z-10">
        <div className="mb-8 opacity-30 animate-fade-in-scale">
          <span className="text-7xl md:text-8xl font-light">金継ぎ</span>
        </div>
        {/* </CHANGE> */}

        <h2
          className="text-4xl md:text-6xl font-light mb-8 leading-tight animate-fade-in-up"
          style={{ animationDelay: "0.2s", opacity: 0, animationFillMode: "forwards" }}
        >
          Esto no es solo un proyecto de arte.
          <span className="block text-accent mt-2">
            Es una apuesta por lo frágil, lo imperfecto, lo que vale la pena reparar.
          </span>
        </h2>
        {/* </CHANGE> */}

        <div className="space-y-4 text-xl md:text-2xl text-background/80 mb-12">
          <p
            className="animate-fade-in-up"
            style={{ animationDelay: "0.4s", opacity: 0, animationFillMode: "forwards" }}
          >
            Gracias por ver lenguaje en la arcilla.
          </p>
          <p
            className="animate-fade-in-up"
            style={{ animationDelay: "0.6s", opacity: 0, animationFillMode: "forwards" }}
          >
            Gracias por creer que el arte puede ser un puente, no un muro.
          </p>
          <p
            className="text-accent font-medium animate-fade-in-up"
            style={{ animationDelay: "0.8s", opacity: 0, animationFillMode: "forwards" }}
          >
            Gracias por ayudarme a transformar el silencio en oro.
          </p>
        </div>
        {/* </CHANGE> */}

        <div className="animate-fade-in-up" style={{ animationDelay: "1s", opacity: 0, animationFillMode: "forwards" }}>
          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-8">
              <Input
                type="email"
                placeholder="Tu correo electrónico"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-14 px-6 text-lg bg-background/10 border-background/30 text-background placeholder:text-background/50 focus:border-accent transition-all duration-300 hover:bg-background/20"
                required
              />
              <Button
                type="submit"
                className="h-14 px-8 text-lg bg-accent hover:bg-accent/90 text-accent-foreground whitespace-nowrap transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-accent/20"
              >
                Únete ahora
              </Button>
            </form>
          ) : (
            <div className="bg-accent/20 border border-accent/30 rounded-lg p-6 max-w-lg mx-auto mb-8 animate-success-notification">
              <p className="text-2xl font-medium">¡Gracias!</p>
              <p className="text-lg text-background/80 mt-2">Tu apoyo hace posible este viaje.</p>
            </div>
          )}
        </div>
        {/* </CHANGE> */}

        <div
          className="pt-8 border-t border-background/20 animate-fade-in-up"
          style={{ animationDelay: "1.2s", opacity: 0, animationFillMode: "forwards" }}
        >
          <p className="text-xl italic mb-1">— Aoi</p>
          <p className="text-base text-background/60">@aoi_ceramica</p>
        </div>
        {/* </CHANGE> */}
      </div>
    </section>
  )
}
