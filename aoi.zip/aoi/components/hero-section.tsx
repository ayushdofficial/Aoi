"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ArrowDown, Users, Sparkles } from "lucide-react"
import { useRouter } from "next/navigation"

export function HeroSection() {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const router = useRouter()

  const [timeLeft, setTimeLeft] = useState({
    days: 45,
    hours: 12,
    minutes: 30,
    seconds: 0,
  })

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 }
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])
  // </CHANGE>

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      setIsSubmitted(true)
      setTimeout(() => {
        router.push("/recompensas")
      }, 1500)
    }
  }

  const scrollToProgress = () => {
    const element = document.getElementById("journey-section")
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative min-h-screen flex flex-col justify-center items-center px-6 py-20 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/50 to-background" />

      {/* Decorative vertical line */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-32 bg-gradient-to-b from-transparent via-accent to-transparent animate-pulse"
        style={{ animationDuration: "3s" }}
      />

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Japanese character */}
        <div className="mb-8 animate-fade-in-scale">
          <span className="text-8xl md:text-9xl font-light text-accent opacity-60">金</span>
        </div>

        <div
          className="flex items-center justify-center gap-2 mb-6 animate-fade-in-up"
          style={{ animationDelay: "0.1s", opacity: 0, animationFillMode: "forwards" }}
        >
          <Users className="w-5 h-5 text-accent" />
          <p className="text-base text-muted-foreground">
            Más de <span className="text-accent font-semibold">1,200 personas</span> siguen este proyecto
          </p>
        </div>
        {/* </CHANGE> */}

        <p
          className="text-base md:text-lg uppercase tracking-[0.3em] text-muted-foreground mb-6 animate-fade-in-up"
          style={{ animationDelay: "0.2s", opacity: 0, animationFillMode: "forwards" }}
        >
          Cerámica · Arte · Kintsugi
        </p>

        <h1
          className="text-5xl md:text-6xl lg:text-8xl font-light leading-tight mb-8 text-balance animate-fade-in-up"
          style={{ animationDelay: "0.4s", opacity: 0, animationFillMode: "forwards" }}
        >
          Transforma el silencio
          <span className="block text-accent font-medium">en oro</span>
        </h1>

        <p
          className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed text-pretty animate-fade-in-up"
          style={{ animationDelay: "0.6s", opacity: 0, animationFillMode: "forwards" }}
        >
          Un puente cultural de cerámica entre México y Japón. Acompáñame en este viaje donde las fracturas no se
          ocultan, sino que se iluminan.
        </p>

        <div
          className="mb-8 animate-fade-in-up"
          style={{ animationDelay: "0.7s", opacity: 0, animationFillMode: "forwards" }}
        >
          <p className="text-sm uppercase tracking-widest text-muted-foreground mb-4">Lanzamiento en</p>
          <div className="flex justify-center gap-4">
            {[
              { value: timeLeft.days, label: "Días" },
              { value: timeLeft.hours, label: "Horas" },
              { value: timeLeft.minutes, label: "Min" },
              { value: timeLeft.seconds, label: "Seg" },
            ].map((item, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="bg-card border border-accent/20 rounded-sm px-4 py-3 min-w-[70px]">
                  <span className="text-3xl md:text-4xl font-bold text-accent">
                    {String(item.value).padStart(2, "0")}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground mt-2 uppercase tracking-wider">{item.label}</span>
              </div>
            ))}
          </div>
        </div>
        {/* </CHANGE> */}

        <div
          className="animate-fade-in-up"
          style={{ animationDelay: "0.8s", opacity: 0, animationFillMode: "forwards" }}
        >
          {!isSubmitted ? (
            <>
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto mb-4">
                <Input
                  type="email"
                  placeholder="Tu correo electrónico"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-14 px-6 text-lg bg-card/80 backdrop-blur-sm border-border/50 focus:border-accent transition-all duration-300 hover:border-accent/50"
                  required
                />
                <Button
                  type="submit"
                  className="h-14 px-8 text-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-accent/20"
                >
                  Únete al viaje
                </Button>
              </form>

              <Button
                onClick={scrollToProgress}
                variant="outline"
                className="h-12 px-6 text-base border-accent/30 hover:border-accent hover:bg-accent/10 transition-all duration-300 bg-transparent"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Seguir el progreso
              </Button>
              {/* </CHANGE> */}
            </>
          ) : (
            <div className="bg-accent/20 border border-accent/30 rounded-lg p-6 max-w-md mx-auto animate-success-notification">
              <p className="text-xl font-medium text-foreground">¡Gracias por unirte!</p>
              <p className="text-muted-foreground mt-2">Pronto recibirás noticias de este viaje.</p>
            </div>
          )}

          <p className="text-base text-muted-foreground mt-6">Sé parte de la creación. Sin spam, solo arte.</p>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ArrowDown className="w-6 h-6 text-muted-foreground" />
      </div>
    </section>
  )
}
