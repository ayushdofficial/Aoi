<!-- Version G: Urgencia - Urgency-driven with countdown -->
<section class="hero-section" style="background: var(--charcoal); color: white;">
    <div class="container hero-content">
        <div style="display: inline-block; background: var(--accent); color: white; padding: 8px 16px; border-radius: 20px; font-weight: 700; margin-bottom: 16px;">
            ⏰ Oferta por tiempo limitado
        </div>
        <h1 class="hero-title" style="color: white;">¡Solo quedan<br/><span style="color: var(--accent);">47 espacios!</span></h1>
        <p class="hero-subtitle" style="color: rgba(255,255,255,0.8);">Únete ahora y asegura tu lugar en esta comunidad exclusiva de mecenas</p>
        
        <div class="countdown" data-countdown="2026-08-01T00:00:00">
            <div class="countdown-item">
                <div class="countdown-value" data-days>45</div>
                <div class="countdown-label">Días</div>
            </div>
            <div class="countdown-item">
                <div class="countdown-value" data-hours>12</div>
                <div class="countdown-label">Horas</div>
            </div>
            <div class="countdown-item">
                <div class="countdown-value" data-minutes>30</div>
                <div class="countdown-label">Min</div>
            </div>
            <div class="countdown-item">
                <div class="countdown-value" data-seconds>00</div>
                <div class="countdown-label">Seg</div>
            </div>
        </div>

        <div style="margin-top: 32px;">
            <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-primary btn-lg">Asegurar mi lugar ahora</a>
        </div>
        
        <p style="margin-top: 16px; color: rgba(255,255,255,0.7); font-size: 0.875rem;">🔥 12 personas viendo esta página ahora</p>
    </div>
</section>

<?php get_template_part('template-parts/sections/story'); ?>
<?php get_template_part('template-parts/sections/gallery'); ?>

<section class="section" style="background: var(--accent); color: white; text-align: center;">
    <div class="container">
        <h2 style="font-size: 2.5rem; margin-bottom: 16px; color: white;">No pierdas esta oportunidad</h2>
        <p style="font-size: 1.25rem; margin-bottom: 32px; color: rgba(255,255,255,0.9);">Los primeros 50 mecenas reciben beneficios exclusivos permanentes</p>
        <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-lg" style="background: white; color: var(--accent);">Unirme ahora</a>
    </div>
</section>

<?php get_template_part('template-parts/sections/faq'); ?>
