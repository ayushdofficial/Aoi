"use client"

import { useEffect, useRef, useState } from "react"
import { Video, Vote, Gift, BookOpen, MessageCircle, Sparkles, Package, Heart } from "lucide-react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function BenefitsSection() {
  const header = useScrollAnimation()
  const digitalBenefits = useScrollAnimation()
  const physicalBenefits = useScrollAnimation()

  const digital = [
    {
      icon: MessageCircle,
      title: "Private Discord Community",
      description:
        "Direct connection with me and other patrons. Share ideas, ask questions, and be part of the creative process.",
    },
    {
      icon: Video,
      title: "Exclusive Live Streams",
      description: "Watch my work in real-time from the studio, including special broadcasts from Japan.",
    },
    {
      icon: Vote,
      title: "Weighted Voting Power",
      description: "Your voice matters. Decide which pieces I create and which places I visit in Japan.",
    },
    {
      icon: BookOpen,
      title: "Digital Library",
      description: "Access to ceramic recipes, techniques, and guides in PDF format.",
    },
  ]

  const physical = [
    {
      icon: Package,
      title: "Handmade Ceramics",
      description: "Original pieces from my new collection and personal archive, shipped with care.",
    },
    {
      icon: Gift,
      title: "Surprise Rewards",
      description: "Mysterious pieces specially selected for you, carrying memories from my journey.",
    },
    {
      icon: Sparkles,
      title: "Kintsugi Pieces",
      description: "Unique works created during my time in Japan, repaired with gold.",
    },
    {
      icon: Heart,
      title: "Personal Collection",
      description: "Access to pieces from my archive—years of exploration and learning.",
    },
  ]

  return (
    <section className="py-24 px-6 bg-secondary/30 overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-16 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">What You Get</p>
          <h2 className="text-4xl md:text-6xl font-light mb-6">
            Benefits for <span className="text-accent">patrons</span>
          </h2>
          <div className="flex justify-center mb-6">
            <div
              className={`h-0.5 bg-gradient-to-r from-transparent via-accent to-transparent transition-all duration-1000 delay-300 ${
                header.isVisible ? "w-32" : "w-0"
              }`}
            />
          </div>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto">
            Your support unlocks exclusive access to the creative process and unique rewards.
          </p>
        </div>

        {/* Digital Benefits */}
        <div ref={digitalBenefits.ref} className="mb-16">
          <h3
            className={`text-2xl font-medium text-center mb-8 transition-all duration-700 ${
              digitalBenefits.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            Digital Rewards
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {digital.map((benefit, index) => (
              <div
                key={index}
                className={`bg-card border border-border/50 rounded-sm p-6 hover:border-accent/50 transition-all duration-700 hover:-translate-y-1 ${
                  digitalBenefits.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                  <benefit.icon className="w-6 h-6 text-accent" />
                </div>
                <h4 className="font-medium text-lg mb-2">{benefit.title}</h4>
                <p className="text-base text-muted-foreground">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Physical Benefits */}
        <div ref={physicalBenefits.ref}>
          <h3
            className={`text-2xl font-medium text-center mb-8 transition-all duration-700 ${
              physicalBenefits.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            Physical Rewards
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {physical.map((benefit, index) => (
              <div
                key={index}
                className={`bg-card border border-border/50 rounded-sm p-6 hover:border-accent/50 transition-all duration-700 hover:-translate-y-1 ${
                  physicalBenefits.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center mb-4">
                  <benefit.icon className="w-6 h-6 text-accent" />
                </div>
                <h4 className="font-medium text-lg mb-2">{benefit.title}</h4>
                <p className="text-base text-muted-foreground">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>

        <SectionCTA text="Unlock your rewards" />
      </div>
    </section>
  )
}
