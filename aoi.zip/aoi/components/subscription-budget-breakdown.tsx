"use client"

import type React from "react"

import { DollarSign, Plane, Users, Code } from "lucide-react"

interface BudgetItem {
  label: string
  percentage: number
  description: string
  icon: React.ReactNode
  color: string
}

const budgetItems: BudgetItem[] = [
  {
    label: "Materiales & Artesanía",
    percentage: 40,
    description: "Cerámica premium, oro, arcillas especiales de Japón",
    icon: <DollarSign className="w-6 h-6" />,
    color: "bg-accent",
  },
  {
    label: "Viaje & Investigación",
    percentage: 30,
    description: "Viaje a Japón, maestros kintsugi, documentación y aprendizaje",
    icon: <Plane className="w-6 h-6" />,
    color: "bg-blue-500",
  },
  {
    label: "Comunidad",
    percentage: 20,
    description: "Plataforma Discord, hosting, eventos virtuales, sesiones Q&A",
    icon: <Users className="w-6 h-6" />,
    color: "bg-purple-500",
  },
  {
    label: "Tecnología",
    percentage: 10,
    description: "Website, videos, documentación, software creativo",
    icon: <Code className="w-6 h-6" />,
    color: "bg-green-500",
  },
]

export function SubscriptionBudgetBreakdown() {
  return (
    <section className="py-20 px-6 bg-secondary/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-light mb-4">Cómo se usa tu apoyo</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Transparencia total. Tu dinero financia directamente la creación artística y la comunidad
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Pie Chart Simulation */}
          <div className="flex items-center justify-center">
            <div className="relative w-64 h-64">
              <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                {/* Materiales 40% */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="20"
                  className="text-accent"
                  strokeDasharray="125.6 314"
                  strokeLinecap="round"
                />
                {/* Viaje 30% */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="20"
                  className="text-blue-500"
                  strokeDasharray="94.2 314"
                  strokeLinecap="round"
                  strokeDashoffset="-125.6"
                />
                {/* Comunidad 20% */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="20"
                  className="text-purple-500"
                  strokeDasharray="62.8 314"
                  strokeLinecap="round"
                  strokeDashoffset="-219.8"
                />
                {/* Tecnología 10% */}
                <circle
                  cx="50"
                  cy="50"
                  r="40"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="20"
                  className="text-green-500"
                  strokeDasharray="31.4 314"
                  strokeLinecap="round"
                  strokeDashoffset="-282.6"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <p className="text-4xl font-bold text-foreground">100%</p>
                  <p className="text-sm text-muted-foreground">Dedicado</p>
                </div>
              </div>
            </div>
          </div>

          {/* Budget Items */}
          <div className="space-y-6">
            {budgetItems.map((item, i) => (
              <div key={i} className="space-y-2">
                <div className="flex items-center gap-3 mb-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${item.color}`}>
                    {item.icon}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{item.label}</p>
                    <p className="text-xs text-muted-foreground">{item.description}</p>
                  </div>
                  <p className="text-2xl font-bold text-accent">{item.percentage}%</p>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className={`h-full ${item.color} transition-all duration-500`}
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
