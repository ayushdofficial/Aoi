import type React from "react"
import Image from "next/image"
import { Zap, Users, Sparkles, Award } from "lucide-react"

interface BenefitCard {
  icon: React.ReactNode
  title: string
  description: string
  image: string
}

const benefits: BenefitCard[] = [
  {
    icon: <Zap className="w-6 h-6" />,
    title: "Real Transformation",
    description: "Learn authentic techniques from Japanese master artisans",
    image: "/japanese-pottery-master-teaching-ceramic-technique.jpg",
  },
  {
    icon: <Users className="w-6 h-6" />,
    title: "Global Community",
    description: "Connect with artists from around the world who share your passion",
    image: "/diverse-community-artists-crafting-together-worksh.jpg",
  },
  {
    icon: <Sparkles className="w-6 h-6" />,
    title: "Beauty in Brokenness",
    description: "Discover how to turn imperfections into masterpieces",
    image: "/kintsugi-broken-pottery-repaired-with-gold-artisti.jpg",
  },
  {
    icon: <Award className="w-6 h-6" />,
    title: "Recognition",
    description: "Exhibit your work in galleries and international spaces",
    image: "/art-gallery-exhibition-ceramic-pieces-displayed-co.jpg",
  },
]

export function BenefitsSectionWithImages() {
  return (
    <section className="py-24 px-6 bg-gradient-to-b from-background to-secondary/20">
      <div className="max-w-7xl mx-auto">
        <div className="mb-16 text-center">
          <h2 className="text-5xl md:text-6xl font-light mb-6 text-balance">
            Why join this
            <span className="block text-accent font-medium">transformative journey</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-12">
          {benefits.map((benefit, index) => (
            <div key={index} className={`flex flex-col gap-6 ${index % 2 === 1 ? "md:order-1" : "md:order-2"}`}>
              <div className="bg-card rounded-lg overflow-hidden shadow-lg h-64">
                <Image src={benefit.image || "/placeholder.svg"} alt={benefit.title} fill className="object-cover" />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="text-accent">{benefit.icon}</div>
                  <h3 className="text-2xl font-medium">{benefit.title}</h3>
                </div>
                <p className="text-muted-foreground text-lg leading-relaxed">{benefit.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
