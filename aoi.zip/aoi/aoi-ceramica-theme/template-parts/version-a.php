<!-- Version A: Clásica -->
<?php get_template_part('template-parts/sections/hero'); ?>
<?php get_template_part('template-parts/sections/story'); ?>
<?php get_template_part('template-parts/sections/gallery'); ?>
<?php get_template_part('template-parts/sections/journey'); ?>
<?php get_template_part('template-parts/sections/email-capture'); ?>
<?php get_template_part('template-parts/sections/benefits'); ?>
<?php get_template_part('template-parts/sections/faq'); ?>
