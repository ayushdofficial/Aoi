"use client"

import { Sparkles, Heart, Award, Globe } from "lucide-react"
import Image from "next/image"

export function FeaturesShowcaseH() {
  const features = [
    {
      icon: Sparkles,
      title: "Técnica Tradicional Japonesa",
      description: "Aprende directamente con maestros certificados en Japón",
      image: "/japanese-kintsugi-master-working-on-ceramic.jpg",
    },
    {
      icon: Heart,
      title: "Piezas Únicas Exclusivas",
      description: "Cada pieza cuenta una historia de transformación",
      image: "/beautiful-gold-repaired-ceramic-bowl-close-up.jpg",
    },
    {
      icon: Award,
      title: "Certificación Oficial",
      description: "Formación reconocida por instituciones japonesas",
      image: "/japanese-certification-document-with-gold-seal.jpg",
    },
    {
      icon: Globe,
      title: "Puente Cultural",
      description: "Conectando México y Japón a través del arte",
      image: "/mexico-and-japan-flags-with-ceramic-art.jpg",
    },
  ]

  return (
    <section id="features-section-h" className="py-24 px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="inline-block bg-accent/10 border border-accent/30 rounded-full px-6 py-2 mb-6">
            <span className="text-sm uppercase tracking-widest text-accent font-medium">¿Por qué este proyecto?</span>
          </div>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-balance">
            Calidad sin<span className="text-accent"> compromiso</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Este proyecto combina tradición milenaria con pasión artesanal para crear algo verdaderamente único
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid gap-16">
          {features.map((feature, index) => {
            const Icon = feature.icon
            const isEven = index % 2 === 0

            return (
              <div
                key={index}
                className={`grid md:grid-cols-2 gap-8 items-center ${isEven ? "" : "md:flex-row-reverse"}`}
              >
                {/* Image */}
                <div
                  className={`relative aspect-[4/3] rounded-2xl overflow-hidden ${isEven ? "md:order-1" : "md:order-2"}`}
                >
                  <Image
                    src={feature.image || "/placeholder.svg"}
                    alt={feature.title}
                    fill
                    className="object-cover hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-accent/20 to-transparent" />
                </div>

                {/* Content */}
                <div className={`${isEven ? "md:order-2" : "md:order-1"}`}>
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-accent/10 border border-accent/30 mb-6">
                    <Icon className="w-8 h-8 text-accent" />
                  </div>
                  <h3 className="text-3xl md:text-4xl font-bold mb-4">{feature.title}</h3>
                  <p className="text-lg text-muted-foreground leading-relaxed">{feature.description}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
