"use client"
import { Button } from "@/components/ui/button"
import { ArrowDown, Heart } from "lucide-react"
import Image from "next/image"
import { useRouter } from "next/navigation"

export function HeroSectionD() {
  const router = useRouter()

  const scrollToTiers = () => {
    const element = document.querySelector("[data-tiers-section]")
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative min-h-screen flex flex-col justify-center items-center px-6 py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/50 to-background" />

      <div className="absolute inset-0 opacity-20">
        <Image
          src="/artisan-hands-crafting-ceramic-pottery-close-up-wa.jpg"
          alt="Hands crafting"
          fill
          className="object-cover"
          priority
        />
      </div>

      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/65 to-black/70 backdrop-blur-sm" />

      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-32 bg-gradient-to-b from-transparent via-accent to-transparent animate-pulse"
        style={{ animationDuration: "3s" }}
      />

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <div className="mb-8 animate-fade-in-scale">
          <Heart className="w-16 h-16 text-accent mx-auto opacity-60" />
        </div>

        <p
          className="text-base md:text-lg uppercase tracking-[0.3em] text-muted-foreground mb-6 animate-fade-in-up"
          style={{ animationDelay: "0.2s", opacity: 0, animationFillMode: "forwards" }}
        >
          Apoyo Continuo
        </p>

        <h1
          className="text-5xl md:text-6xl lg:text-7xl font-light leading-tight mb-6 text-balance animate-fade-in-up"
          style={{ animationDelay: "0.4s", opacity: 0, animationFillMode: "forwards" }}
        >
          Apoya el proceso creativo
          <span className="block text-accent font-medium">mes a mes</span>
        </h1>

        <p
          className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed text-pretty animate-fade-in-up"
          style={{ animationDelay: "0.6s", opacity: 0, animationFillMode: "forwards" }}
        >
          No es solo una donación única. Es un viaje continuo donde tu apoyo mensual permite crear arte sin
          interrupciones, documentar procesos únicos y construir una comunidad real.
        </p>

        <div
          className="grid grid-cols-3 gap-6 max-w-2xl mx-auto mb-12 animate-fade-in-up"
          style={{ animationDelay: "0.7s", opacity: 0, animationFillMode: "forwards" }}
        >
          <div className="text-center">
            <div className="text-3xl font-bold text-accent mb-2">500+</div>
            <p className="text-sm text-muted-foreground">Suscriptores</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-accent mb-2">12</div>
            <p className="text-sm text-muted-foreground">Meses de arte</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-accent mb-2">24/7</div>
            <p className="text-sm text-muted-foreground">Acceso comunidad</p>
          </div>
        </div>

        <div
          className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up"
          style={{ animationDelay: "0.8s", opacity: 0, animationFillMode: "forwards" }}
        >
          <Button
            onClick={scrollToTiers}
            className="h-14 px-8 text-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-accent/20"
          >
            Ver Planes
          </Button>
          <Button
            variant="outline"
            className="h-14 px-8 text-lg border-accent/30 hover:border-accent hover:bg-accent/10 transition-all duration-300 bg-transparent"
            onClick={() => router.push("/?variant=b")}
          >
            ¿Prefieres Mecenazgo?
          </Button>
        </div>

        <p
          className="text-base text-muted-foreground mt-6 animate-fade-in-up"
          style={{ animationDelay: "0.9s", opacity: 0, animationFillMode: "forwards" }}
        >
          Cancela cuando quieras, sin compromisos
        </p>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ArrowDown className="w-6 h-6 text-muted-foreground" />
      </div>
    </section>
  )
}
