# Aoi Cerámica - WordPress Theme

Complete WordPress theme with 8 sales funnel versions for ceramic artist crowdfunding campaign.

## Installation

1. **Upload the theme:**
   - Download the `aoi-ceramica-theme` folder
   - Upload to `wp-content/themes/` on your WordPress site
   - Or compress to ZIP and install via WordPress admin

2. **Activate:**
   - Go to Appearance → Themes in WordPress
   - Click "Activate" on Aoi Cerámica theme

3. **Add images:**
   - Add your ceramic images to `wp-content/themes/aoi-ceramica-theme/images/`
   - Update image paths in template files

4. **Configure:**
   - Update Patreon link in `functions.php` (line 68)
   - Set countdown date in `js/main.js` (line 60)
   - Customize colors in `style.css` if needed

## Features

### 8 Complete Versions

- **Version A (Clásica):** Traditional flow with countdown, hero, gallery, story
- **Version B (Testimonios):** Testimonial-focused layout
- **Version C (Timeline):** Timeline storytelling approach
- **Version D (Personalizada):** Multi-step subscription wrapper
- **Version F (Educativa):** 2-step educational process
- **Version G (Urgencia):** Urgency-driven with countdown
- **Version H (Premium):** Premium positioning
- **Version I (Patreon):** Main 3-step Patreon-focused flow

### Included Functionality

- ✅ Bottom tab navigation (switches between all 8 versions)
- ✅ Cookie persistence (remembers user's selected version)
- ✅ URL parameters (`?variant=i` to force a version)
- ✅ Countdown timer (JavaScript)
- ✅ FAQ accordion
- ✅ Email capture forms (AJAX)
- ✅ Scroll animations
- ✅ Scroll-to-top button
- ✅ Fully responsive

## File Structure

```
aoi-ceramica-theme/
├── style.css                 # Main styles + theme header
├── functions.php             # WordPress functions & AJAX
├── index.php                 # Main template
├── header.php               # HTML head
├── footer.php               # HTML footer
├── js/
│   └── main.js              # All JavaScript
├── template-parts/
│   ├── version-a.php        # Version A
│   ├── version-b.php        # Version B
│   ├── version-c.php        # Version C
│   ├── version-d.php        # Version D
│   ├── version-f.php        # Version F
│   ├── version-g.php        # Version G
│   ├── version-h.php        # Version H
│   ├── version-i.php        # Version I
│   └── sections/
│       ├── hero.php         # Hero section
│       ├── story.php        # Story section
│       ├── gallery.php      # Gallery section
│       ├── journey.php      # Journey timeline
│       ├── email-capture.php # Email form
│       ├── benefits.php     # Benefits section
│       └── faq.php          # FAQ accordion
└── images/                   # Your images here
```

## Customization

### Colors

Edit `:root` variables in `style.css`:

```css
--cream: #faf8f5;
--charcoal: #2c2c2c;
--coral: #ff5349;
```

### Patreon Link

Update in `functions.php` line 68:

```php
return '<a href="https://www.patreon.com/YOUR_USERNAME"...
```

### Email Integration

Add your email service API in `functions.php` in the `aoi_handle_email_capture()` function.

## Support

- Email: aoiceramica@gmail.com
- Instagram: @aoi_ceramica
- Patreon: https://www.patreon.com/aoi_kitsune

## License

GPL v2 or later
