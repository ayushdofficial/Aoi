import { SubscriptionStepWrapper } from "@/components/subscription-step-wrapper"

export function PageVersionD() {
  return <SubscriptionStepWrapper />
}
