"use client"

import { Button } from "@/components/ui/button"
import { SubscriptionTiers } from "@/components/subscription-tiers"
import { SubscriptionComparison } from "@/components/subscription-comparison"
import { SubscriptionTestimonials } from "@/components/subscription-testimonials"
import { SubscriptionBudgetBreakdown } from "@/components/subscription-budget-breakdown"
import { SubscriptionPolicies } from "@/components/subscription-policies"
import { SubscriptionFAQDynamic } from "@/components/subscription-faq-dynamic"

interface SubscriptionStep2Props {
  email: string
  onPrevious: () => void
}

export function SubscriptionStep2({ email, onPrevious }: SubscriptionStep2Props) {
  return (
    <div className="space-y-0">
      {/* Header with back button */}
      <div className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-accent/10 py-4 px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <Button variant="ghost" onClick={onPrevious} className="text-muted-foreground hover:text-foreground">
            ← Atrás
          </Button>
          <p className="text-sm text-muted-foreground">Confirmado: {email}</p>
        </div>
      </div>

      <SubscriptionTestimonials />

      {/* Tiers Section */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h1 className="text-5xl md:text-6xl font-light mb-6">Elige tu nivel de apoyo</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Cada plan ofrece beneficios únicos para que disfrutes de la creación artística de cerca
            </p>
          </div>

          <SubscriptionTiers />
        </div>
      </section>

      <SubscriptionBudgetBreakdown />

      {/* Comparison */}
      <section className="py-20 px-6 bg-secondary/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-light text-center mb-12">¿Qué diferencia hay con el mecenazgo?</h2>
          <SubscriptionComparison />
        </div>
      </section>

      <SubscriptionPolicies />

      <SubscriptionFAQDynamic />

      {/* Final CTA */}
      <section className="py-20 px-6 bg-accent/10 border-t border-accent/20">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-light mb-6">¿Listo para comenzar?</h2>
          <p className="text-lg text-muted-foreground mb-8">
            Selecciona tu plan arriba para comenzar tu suscripción. Tu apoyo comienza inmediatamente.
          </p>
          <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-medium h-12">
            Ir a Planes
          </Button>
        </div>
      </section>
    </div>
  )
}
