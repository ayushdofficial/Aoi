<section class="section bg-white">
    <div class="container" style="max-width: 900px;">
        <div class="section-header">
            <p style="text-transform: uppercase; letter-spacing: 0.2em; color: var(--accent); margin-bottom: 16px;">Preguntas</p>
            <h2 class="section-title">Preguntas Frecuentes</h2>
        </div>
        
        <div>
            <div class="faq-item">
                <button class="faq-question">
                    <span>¿Cómo funciona el crowdfunding?</span>
                    <span class="faq-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 9l6 6 6-6"/>
                        </svg>
                    </span>
                </button>
                <div class="faq-answer">
                    <p>El proyecto se ejecutará en Kickstarter, una plataforma de crowdfunding todo o nada. Esto significa que si alcanzamos la meta de financiación, todos los mecenas serán cargados y las recompensas serán entregadas.</p>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">
                    <span>¿Cuándo viajas a Japón?</span>
                    <span class="faq-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 9l6 6 6-6"/>
                        </svg>
                    </span>
                </button>
                <div class="faq-answer">
                    <p>El viaje a Japón está programado para agosto de 2026. Asistiré a la residencia Toma House AIR en Narita para un mes de entrenamiento intensivo en kintsugi.</p>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">
                    <span>¿Cómo recibiremos las recompensas?</span>
                    <span class="faq-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 9l6 6 6-6"/>
                        </svg>
                    </span>
                </button>
                <div class="faq-answer">
                    <p>Las recompensas de esta página se enviarán tan pronto como el usuario contribuya. Los enlaces para unirse a Discord se enviarán por correo electrónico dentro de las 48 horas de tu contribución.</p>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">
                    <span>¿Cuánto tardan las piezas hechas a mano?</span>
                    <span class="faq-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 9l6 6 6-6"/>
                        </svg>
                    </span>
                </button>
                <div class="faq-answer">
                    <p>Estimado de 1 a 2 meses debido al número de apoyadores en el proyecto de Kickstarter. La cerámica hecha a mano requiere tiempo y cuidado. Cada pieza es única y hecha con intención.</p>
                </div>
            </div>

            <div class="faq-item">
                <button class="faq-question">
                    <span>¿Qué pasa si una pieza llega dañada?</span>
                    <span class="faq-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M6 9l6 6 6-6"/>
                        </svg>
                    </span>
                </button>
                <div class="faq-answer">
                    <p>Si alguna pieza de cerámica llega dañada, simplemente envíame una foto y la reemplazaré. Utilizo embalaje profesional diseñado para cerámica frágil para minimizar este riesgo.</p>
                </div>
            </div>
        </div>
    </div>
</section>
