"use client"
import { useState } from "react"
import type React from "react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { CheckCircle2, Mail } from "lucide-react"
import Image from "next/image"

export function EmailCaptureWithImage() {
  const [email, setEmail] = useState("")
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError("Please enter a valid email")
      return
    }

    try {
      const response = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      })

      if (response.ok) {
        setSubmitted(true)
        setEmail("")
        setTimeout(() => {
          router.push("/recompensas")
        }, 1500)
      }
    } catch (err) {
      setError("Something went wrong. Please try again.")
    }
  }

  return (
    <section data-email-section className="py-24 px-6 bg-gradient-to-b from-background to-secondary/30">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Image side */}
          <div className="relative h-96 md:h-full min-h-96 rounded-lg overflow-hidden shadow-2xl">
            <Image
              src="/artisan-hands-crafting-ceramic-pottery-close-up-wa.jpg"
              alt="Artisan creating ceramics"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
          </div>

          {/* Form side */}
          <div className="flex flex-col gap-8">
            <div>
              <h2 className="text-4xl md:text-5xl font-light mb-6 text-balance">
                Secure your access<span className="block text-accent font-medium">before launch</span>
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">The first 500 accesses include:</p>
              <ul className="mt-6 space-y-3">
                {["30% discount on launch", "Exclusive access to workshops", "Private community of artists"].map(
                  (item, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckCircle2 className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{item}</span>
                    </li>
                  ),
                )}
              </ul>
            </div>

            {/* Form */}
            {!submitted ? (
              <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
                  <Input
                    type="email"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-12 h-14 bg-card border-accent/20 focus:border-accent rounded-lg text-base"
                  />
                </div>
                <Button
                  type="submit"
                  className="h-14 bg-primary hover:bg-primary/90 text-primary-foreground text-base font-medium transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-accent/20"
                >
                  Get Exclusive Access
                </Button>
                {error && <p className="text-red-500 text-sm">{error}</p>}
              </form>
            ) : (
              <div className="text-center py-8">
                <CheckCircle2 className="w-16 h-16 text-accent mx-auto mb-4" />
                <h3 className="text-2xl font-medium mb-2">Email registered!</h3>
                <p className="text-muted-foreground">Redirecting to your rewards...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
