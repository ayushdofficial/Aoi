"use client"

import { useEffect, useRef, useState } from "react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function GallerySection() {
  const header = useScrollAnimation()
  const gallery = useScrollAnimation()
  const [selectedImage, setSelectedImage] = useState<number | null>(null)

  const pieces = [
    {
      image: "/handmade-ceramic-vase-earth-tones-minimalist-potte.jpg",
      title: "Vessel of Silence",
      description: "Hand-modeled stoneware",
      tags: ["Handmade", "Limited edition"],
    },
    {
      image: "/ceramic-bowl-kintsugi-gold-repair-japanese-techniq.jpg",
      title: "Repaired Memory",
      description: "Kintsugi technique",
      tags: ["Kintsugi", "Wabi-sabi"],
    },
    {
      image: "/sculptural-ceramic-art-piece-organic-forms-contemp.jpg",
      title: "Whispers in Clay",
      description: "Sculptural piece",
      tags: ["Handmade", "Unique"],
    },
    {
      image: "/ceramic-planter-pot-artisan-mexican-style-terracot.jpg",
      title: "Earth and Root",
      description: "Planter collection",
      tags: ["Handmade", "Limited edition"],
    },
    {
      image: "/ceramic-tea-bowl-wabi-sabi-imperfect-beauty-japane.jpg",
      title: "Tea Ceremony",
      description: "Wabi-sabi bowl",
      tags: ["Wabi-sabi", "Unique"],
    },
    {
      image: "/ceramic-sculpture-abstract-form-golden-accents-mix.jpg",
      title: "Golden Fractures",
      description: "Mixed technique",
      tags: ["Kintsugi", "Unique"],
    },
  ]

  return (
    <section className="pt-8 pb-16 px-6 bg-card overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-16 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">Gallery</p>
          <h2 className="text-4xl md:text-6xl font-light mb-6">My Work</h2>
          <div className="flex justify-center mb-6">
            <div
              className={`h-0.5 bg-gradient-to-r from-transparent via-accent to-transparent transition-all duration-1000 delay-300 ${
                header.isVisible ? "w-32" : "w-0"
              }`}
            />
          </div>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto">
            Each piece carries time, intention, and a fragment of my journey as a ceramist.
          </p>
        </div>

        <div ref={gallery.ref} className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6">
          {pieces.map((piece, index) => (
            <div
              key={index}
              onClick={() => setSelectedImage(index)}
              className={`group relative overflow-hidden rounded-sm transition-all duration-700 cursor-pointer ${
                gallery.isVisible ? "opacity-100 translate-y-0 scale-100" : "opacity-0 translate-y-12 scale-95"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="aspect-square overflow-hidden">
                <img
                  src={piece.image || "/placeholder.svg"}
                  alt={piece.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
              </div>
              <div className="absolute top-2 left-2 flex flex-wrap gap-1">
                {piece.tags.map((tag, i) => (
                  <span
                    key={i}
                    className="px-2 py-1 bg-accent/90 text-accent-foreground text-xs font-medium rounded backdrop-blur-sm"
                  >
                    {tag}
                  </span>
                ))}
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div className="absolute bottom-0 left-0 right-0 p-4 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                  <h3 className="text-background font-medium text-lg">{piece.title}</h3>
                  <p className="text-background/70 text-sm">{piece.description}</p>
                  <p className="text-background/60 text-xs mt-2">Click to enlarge</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <SectionCTA text="Support the creation" variant="subtle" />
      </div>
    </section>
  )
}
