import { HeroSection } from "@/components/hero-section"
import { StorySection } from "@/components/story-section"
import { GallerySection } from "@/components/gallery-section"
import { ProjectDetailSection } from "@/components/project-detail-section"
import { JourneySection } from "@/components/journey-section"
import { WhySupportSection } from "@/components/why-support-section"
import { ImprovedEmailCapture } from "@/components/improved-email-capture"
import { BenefitsSection } from "@/components/benefits-section"
import { FAQSection } from "@/components/faq-section"
import { TrustSection } from "@/components/trust-section"
import { FinalCTA } from "@/components/final-cta"

export function PageVersionA() {
  return (
    <>
      <HeroSection />
      <StorySection />
      <GallerySection />
      <ProjectDetailSection />
      <JourneySection />
      <WhySupportSection />
      <ImprovedEmailCapture />
      <BenefitsSection />
      <FAQSection />
      <TrustSection />
      <FinalCTA />
    </>
  )
}
