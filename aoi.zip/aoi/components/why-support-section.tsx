"use client"

import { useEffect, useRef, useState } from "react"
import { Heart, Zap, Gift, TrendingUp } from "lucide-react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function WhySupportSection() {
  const header = useScrollAnimation()
  const reasons = useScrollAnimation()
  const funds = useScrollAnimation()

  return (
    <section className="py-16 px-6 bg-card overflow-hidden">
      <div className="max-w-5xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-16 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">Why it matters</p>
          <h2 className="text-4xl md:text-6xl font-light mb-6">
            Why support <span className="text-accent">this project?</span>
          </h2>
          <div className="flex justify-center mb-6">
            <div
              className={`h-0.5 bg-gradient-to-r from-transparent via-accent to-transparent transition-all duration-1000 delay-300 ${
                header.isVisible ? "w-32" : "w-0"
              }`}
            />
          </div>
        </div>

        {/* Main reasons grid */}
        <div ref={reasons.ref} className="grid md:grid-cols-2 gap-6 mb-16">
          {[
            {
              icon: Heart,
              title: "Project vehicle",
              desc: "This is not a commercial project. It's a journey of learning, cultural exchange and artistic growth. Your support makes it possible for me to dedicate a full month to immersing myself in the tradition of kintsugi in Japan, learning from local masters and documenting every step of the process.",
              color: "text-rose-500",
            },
            {
              icon: Zap,
              title: "Early supporter benefits",
              desc: "The first to support this project will have exclusive access to content, voting and rewards that won't be available after launch. You'll be part of decision-making from the start: which pieces I create, which places I visit, which techniques I explore.",
              color: "text-amber-500",
            },
            {
              icon: Gift,
              title: "Unique project reasons",
              desc: "This is the first project that combines my Mexican heritage of traditional ceramics with Japanese kintsugi techniques. It's a unique cultural bridge that explores how two millennial ceramic traditions can dialogue and enrich each other.",
              color: "text-accent",
            },
            {
              icon: TrendingUp,
              title: "Transparent use of funds",
              desc: "Every dollar raised has a clear destination: kintsugi course at Toma House AIR, specialized materials and tools, accommodation and subsistence during the month in Japan, process documentation (camera, lighting), and exploration of ceramic workshops and towns.",
              color: "text-blue-500",
            },
          ].map((item, index) => (
            <div
              key={index}
              className={`bg-background border border-border/50 rounded-sm p-8 hover:border-accent/30 transition-all duration-700 ${
                reasons.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <item.icon className={`w-12 h-12 ${item.color} mb-4`} />
              <h3 className="text-2xl font-medium mb-3">{item.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>

        {/* Funds breakdown */}
        <div
          ref={funds.ref}
          className={`bg-gradient-to-br from-accent/5 to-accent/10 border border-accent/20 rounded-sm p-8 md:p-12 transition-all duration-1000 ${
            funds.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
          }`}
        >
          <h3 className="text-3xl font-light mb-8 text-center">How funds will be used</h3>

          <div className="space-y-4">
            {[
              { item: "Kintsugi course at Toma House AIR (Narita, Japan)", percentage: 40 },
              { item: "Accommodation and subsistence for 1 month", percentage: 25 },
              { item: "Specialized materials (urushi lacquer, gold, tools)", percentage: 15 },
              { item: "Process documentation (video/photo equipment)", percentage: 10 },
              { item: "Exploration of ceramic workshops and towns", percentage: 10 },
            ].map((budget, index) => (
              <div
                key={index}
                className={`transition-all duration-700 ${
                  funds.isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="flex justify-between items-center mb-2">
                  <span className="text-base">{budget.item}</span>
                  <span className="text-accent font-bold">{budget.percentage}%</span>
                </div>
                <div className="h-3 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-accent to-amber-400 transition-all duration-1000 ease-out"
                    style={{
                      width: funds.isVisible ? `${budget.percentage}%` : "0%",
                      transitionDelay: `${index * 100 + 200}ms`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          <p className="text-center text-muted-foreground mt-8 text-lg">
            Total transparency. Every cent invested in creating art and documenting the process.
          </p>
        </div>

        <SectionCTA text="Join this journey" />
      </div>
    </section>
  )
}
