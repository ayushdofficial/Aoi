<!-- Version D: Personalizada - Multi-step subscription wrapper -->
<section class="hero-section" style="background: linear-gradient(to bottom right, var(--accent), var(--terracotta));">
    <div class="container hero-content" style="color: white;">
        <h1 class="hero-title" style="color: white;">Personaliza tu apoyo</h1>
        <p class="hero-subtitle" style="color: rgba(255,255,255,0.9);">Elige el plan que mejor se adapte a ti y sé parte de este viaje creativo</p>
        <div style="margin-top: 32px;">
            <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-lg" style="background: white; color: var(--accent);">Ver planes disponibles</a>
        </div>
    </div>
</section>

<section class="section bg-white">
    <div class="container" style="max-width: 1000px;">
        <div class="section-header">
            <h2 class="section-title">Niveles de suscripción</h2>
            <p class="section-subtitle">Cada nivel ofrece beneficios únicos para disfrutar del arte de cerca</p>
        </div>
        <div class="tiers-grid">
            <div class="tier-card">
                <h3 style="font-size: 1.5rem; margin-bottom: 8px;">Aprendiz</h3>
                <div class="tier-price">$99<span style="font-size: 1rem; font-weight: 400;">/mes</span></div>
                <ul class="tier-features">
                    <li>✓ Acceso a contenido exclusivo</li>
                    <li>✓ Videos del proceso creativo</li>
                    <li>✓ Comunidad en Discord</li>
                </ul>
                <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-primary" style="width: 100%; margin-top: 16px;">Seleccionar</a>
            </div>
            <div class="tier-card">
                <div class="tier-badge">Popular</div>
                <h3 style="font-size: 1.5rem; margin-bottom: 8px;">Artesano</h3>
                <div class="tier-price">$299<span style="font-size: 1rem; font-weight: 400;">/mes</span></div>
                <ul class="tier-features">
                    <li>✓ Todo de Aprendiz</li>
                    <li>✓ Descuentos en piezas</li>
                    <li>✓ Sesiones en vivo mensuales</li>
                    <li>✓ Acceso anticipado a nuevas creaciones</li>
                </ul>
                <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-primary" style="width: 100%; margin-top: 16px;">Seleccionar</a>
            </div>
            <div class="tier-card">
                <h3 style="font-size: 1.5rem; margin-bottom: 8px;">Mecenas</h3>
                <div class="tier-price">$999<span style="font-size: 1rem; font-weight: 400;">/mes</span></div>
                <ul class="tier-features">
                    <li>✓ Todo de Artesano</li>
                    <li>✓ Pieza exclusiva anual</li>
                    <li>✓ Videollamadas privadas</li>
                    <li>✓ Crédito en documentación</li>
                </ul>
                <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-primary" style="width: 100%; margin-top: 16px;">Seleccionar</a>
            </div>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/sections/faq'); ?>
