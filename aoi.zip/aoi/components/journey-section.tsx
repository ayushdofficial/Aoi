"use client"

import { useEffect, useRef, useState } from "react"
import { Plane, BookOpen, Users, Heart } from "lucide-react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation(delay = 0) {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay)
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [delay])

  return { ref, isVisible }
}

export function JourneySection() {
  const header = useScrollAnimation()
  const timeline = useScrollAnimation()
  const impact = useScrollAnimation()

  const phases = [
    {
      icon: BookOpen,
      title: "Learn Japanese",
      description:
        "Personalized classes three times a week for three months, preparing me to understand every nuance of the courses.",
      image: "/japanese-calligraphy-learning-study-books-language.jpg",
      detail: "Overcoming the limitations of Mexico, where learning is often limited and not very immersive.",
    },
    {
      icon: Plane,
      title: "Toma House AIR Residency",
      description: "A specialized Japanese ceramics course in Narita, Japan, with emphasis on kintsugi.",
      image: "/traditional-japanese-ceramic-workshop-studio-potte.jpg",
      detail: "Where fractures are not hidden, but illuminated with gold.",
    },
    {
      icon: Users,
      title: "Connect with artisans",
      description: "Converse with local artisans and explore rural workshops that will breathe new life into my work.",
      image: "/japanese-master-potter-teaching-ceramic-art-tradit.jpg",
      detail: "Deciphering a world of sensations, tradition, and wisdom.",
    },
    {
      icon: Heart,
      title: "Build bridges",
      description: "Fuse Mexican and Japanese techniques into unique pieces charged with history and sensitivity.",
      image: "/mexican-japanese-fusion-ceramic-art-golden-kintsug.jpg",
      detail: "A shared journey where art becomes experience and connection.",
    },
  ]

  return (
    <section className="py-24 px-6 bg-card overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-20 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">The Project</p>
          <h2 className="text-4xl md:text-6xl font-light mb-6 text-balance">
            A cultural bridge between
            <span className="block text-accent">Mexico and Japan</span>
          </h2>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto">
            I was accepted into the Toma House AIR residency, for a specialized course where fractures are not hidden,
            but illuminated with gold.
          </p>
        </div>

        <div ref={timeline.ref} className="relative">
          {/* Connection line */}
          <div
            className={`absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-accent via-accent/50 to-accent transition-all duration-1500 origin-top hidden md:block ${
              timeline.isVisible ? "scale-y-100" : "scale-y-0"
            }`}
            style={{ transitionDuration: "1.5s" }}
          />

          <div className="space-y-16">
            {phases.map((phase, index) => (
              <div
                key={index}
                className={`relative transition-all duration-700 ${
                  timeline.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
                }`}
                style={{ transitionDelay: `${index * 200 + 300}ms` }}
              >
                <div className={`md:grid md:grid-cols-2 md:gap-16 ${index % 2 === 0 ? "" : ""}`}>
                  {/* Content side */}
                  <div className={`${index % 2 === 0 ? "md:pr-16" : "md:order-2 md:pl-16"}`}>
                    <div className="bg-secondary/50 p-8 rounded-sm border border-border/50 hover:border-accent/50 transition-colors duration-300">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                          <phase.icon className="w-6 h-6 text-accent" />
                        </div>
                        <h3 className="text-2xl font-medium">{phase.title}</h3>
                      </div>
                      <p className="text-lg text-muted-foreground mb-4">{phase.description}</p>
                      <p className="text-base text-accent/80 italic">{phase.detail}</p>
                    </div>
                  </div>

                  {/* Image side */}
                  <div className={`mt-6 md:mt-0 ${index % 2 === 0 ? "md:order-2 md:pl-16" : "md:pr-16"}`}>
                    <div className="relative overflow-hidden rounded-sm group">
                      <img
                        src={phase.image || "/placeholder.svg"}
                        alt={phase.title}
                        className="w-full h-48 md:h-56 object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
                      <div className="absolute bottom-4 left-4 right-4">
                        <span className="text-xs uppercase tracking-widest text-accent">Phase {index + 1} of 4</span>
                      </div>
                    </div>
                  </div>

                  {/* Timeline dot - centered */}
                  <div
                    className={`hidden md:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center transition-all duration-500 ${
                      timeline.isVisible ? "scale-100 opacity-100" : "scale-0 opacity-0"
                    }`}
                    style={{ transitionDelay: `${index * 200 + 500}ms` }}
                  >
                    <div className="w-6 h-6 rounded-full bg-accent border-4 border-background shadow-lg shadow-accent/20" />
                    <div
                      className="absolute w-12 h-12 rounded-full bg-accent/20 animate-ping"
                      style={{ animationDuration: "2s" }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div
          ref={impact.ref}
          className={`mt-24 text-center bg-gradient-to-br from-accent/5 to-accent/10 border border-accent/20 rounded-sm p-8 md:p-12 transition-all duration-1000 ${
            impact.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
          }`}
        >
          <div className="max-w-3xl mx-auto">
            <p className="text-2xl md:text-3xl font-light leading-relaxed mb-6">
              It's not just about learning a language: it's about{" "}
              <span className="text-accent font-medium">deciphering a world of sensations</span>, tradition, and wisdom.
            </p>
            <p className="text-lg md:text-xl text-muted-foreground">
              By supporting this phase, you become part of the creation. You'll be able to participate in polls, follow
              live streams, and accompany me as each piece comes to life in clay and gold.
            </p>
          </div>
        </div>

        <SectionCTA text="Support the project" variant="subtle" />
      </div>
    </section>
  )
}
