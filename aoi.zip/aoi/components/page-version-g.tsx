"use client"

import { useState, useEffect } from "react"
import { SubscriptionStep1VersionG } from "@/components/subscription-step-1-version-g"
import { SubscriptionStep2 } from "@/components/subscription-step-2"

export function PageVersionG() {
  const [step, setStep] = useState(1)
  const [email, setEmail] = useState("")

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [step])

  const handleNextStep = (userEmail: string) => {
    setEmail(userEmail)
    setStep(2)
  }

  const handlePreviousStep = () => {
    setStep(1)
  }

  return (
    <div className="min-h-screen bg-background">
      {step === 1 && <SubscriptionStep1VersionG onNext={handleNextStep} />}
      {step === 2 && <SubscriptionStep2 email={email} onPrevious={handlePreviousStep} />}
    </div>
  )
}
