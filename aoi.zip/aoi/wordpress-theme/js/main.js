/**
 * Main JavaScript for Aoi Ceramica Theme
 */

;(() => {
  // Wait for DOM to be ready
  document.addEventListener("DOMContentLoaded", () => {
    // ============================================================
    // VERSION TAB SWITCHING
    // ============================================================
    const versionTabs = document.querySelectorAll(".version-tab")

    versionTabs.forEach((tab) => {
      tab.addEventListener("click", function () {
        const variant = this.dataset.variant

        // Set cookie
        document.cookie = `aoi_variant=${variant}; path=/; max-age=31536000`

        // Reload page with variant
        const url = new URL(window.location)
        url.searchParams.set("variant", variant)
        window.location.href = url.toString()
      })
    })

    // ============================================================
    // SCROLL TO TOP BUTTON
    // ============================================================
    const scrollToTopBtn = document.getElementById("scrollToTop")

    if (scrollToTopBtn) {
      window.addEventListener("scroll", () => {
        if (window.pageYOffset > 300) {
          scrollToTopBtn.classList.add("visible")
        } else {
          scrollToTopBtn.classList.remove("visible")
        }
      })

      scrollToTopBtn.addEventListener("click", () => {
        window.scrollTo({
          top: 0,
          behavior: "smooth",
        })
      })
    }

    // ============================================================
    // SMOOTH SCROLLING FOR ANCHOR LINKS
    // ============================================================
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener("click", function (e) {
        const href = this.getAttribute("href")
        if (href === "#") return

        const target = document.querySelector(href)
        if (target) {
          e.preventDefault()
          target.scrollIntoView({
            behavior: "smooth",
            block: "start",
          })
        }
      })
    })

    // ============================================================
    // FAQ ACCORDION
    // ============================================================
    const faqQuestions = document.querySelectorAll(".faq-question")

    faqQuestions.forEach((question) => {
      question.addEventListener("click", function () {
        const faqItem = this.parentElement
        const wasActive = faqItem.classList.contains("active")

        // Close all other FAQs
        document.querySelectorAll(".faq-item").forEach((item) => {
          item.classList.remove("active")
        })

        // Toggle current FAQ
        if (!wasActive) {
          faqItem.classList.add("active")
        }
      })
    })

    // ============================================================
    // EMAIL CAPTURE FORM
    // ============================================================
    const emailForms = document.querySelectorAll(".email-capture-form")

    emailForms.forEach((form) => {
      form.addEventListener("submit", (e) => {
        e.preventDefault()

        const emailInput = form.querySelector('input[type="email"]')
        const submitBtn = form.querySelector('button[type="submit"]')
        const email = emailInput.value

        if (!email) return

        // Disable form
        submitBtn.disabled = true
        submitBtn.textContent = "Enviando..."

        // Get variant
        const variant = getActiveVariant()

        // Send to WordPress via AJAX
        const formData = new FormData()
        formData.append("action", "capture_email")
        formData.append("nonce", window.aoiCeramica.nonce) // Declare aoiCeramica before using it
        formData.append("email", email)
        formData.append("variant", variant)

        fetch(window.aoiCeramica.ajaxUrl, {
          method: "POST",
          body: formData,
        })
          .then((response) => response.json())
          .then((data) => {
            if (data.success) {
              // Show success message
              form.innerHTML = `
                            <div class="success-message">
                                <p class="text-xl font-semibold text-accent">¡Gracias por unirte!</p>
                                <p class="text-muted-foreground">Pronto recibirás noticias de este viaje.</p>
                            </div>
                        `

              // Optional: redirect after delay
              // setTimeout(() => window.location.href = '/siguiente-paso', 2000);
            } else {
              alert("Error: " + data.data.message)
              submitBtn.disabled = false
              submitBtn.textContent = "Intentar de nuevo"
            }
          })
          .catch((error) => {
            console.error("Error:", error)
            alert("Hubo un error. Por favor intenta de nuevo.")
            submitBtn.disabled = false
            submitBtn.textContent = "Intentar de nuevo"
          })
      })
    })

    // ============================================================
    // COUNTDOWN TIMER (for urgency versions)
    // ============================================================
    function updateCountdown() {
      const countdownElements = document.querySelectorAll(".countdown")

      countdownElements.forEach((countdown) => {
        const targetDate = new Date(countdown.dataset.target).getTime()

        const interval = setInterval(() => {
          const now = new Date().getTime()
          const distance = targetDate - now

          if (distance < 0) {
            clearInterval(interval)
            countdown.innerHTML = '<p class="text-xl font-bold text-accent">¡Campaña iniciada!</p>'
            return
          }

          const days = Math.floor(distance / (1000 * 60 * 60 * 24))
          const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
          const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
          const seconds = Math.floor((distance % (1000 * 60)) / 1000)

          const daysEl = countdown.querySelector(".countdown-days")
          const hoursEl = countdown.querySelector(".countdown-hours")
          const minutesEl = countdown.querySelector(".countdown-minutes")
          const secondsEl = countdown.querySelector(".countdown-seconds")

          if (daysEl) daysEl.textContent = String(days).padStart(2, "0")
          if (hoursEl) hoursEl.textContent = String(hours).padStart(2, "0")
          if (minutesEl) minutesEl.textContent = String(minutes).padStart(2, "0")
          if (secondsEl) secondsEl.textContent = String(seconds).padStart(2, "0")
        }, 1000)
      })
    }

    updateCountdown()

    // ============================================================
    // LAZY LOAD IMAGES
    // ============================================================
    if ("IntersectionObserver" in window) {
      const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const img = entry.target
            img.src = img.dataset.src
            img.classList.remove("lazy")
            observer.unobserve(img)
          }
        })
      })

      document.querySelectorAll("img.lazy").forEach((img) => {
        imageObserver.observe(img)
      })
    }

    // ============================================================
    // UTILITY FUNCTIONS
    // ============================================================
    function getActiveVariant() {
      const cookies = document.cookie.split(";")
      for (const cookie of cookies) {
        const [name, value] = cookie.trim().split("=")
        if (name === "aoi_variant") {
          return value
        }
      }
      return "i" // default
    }

    function setCookie(name, value, days) {
      const expires = new Date()
      expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000)
      document.cookie = `${name}=${value};expires=${expires.toUTCString()};path=/`
    }

    // ============================================================
    // SCROLL ANIMATIONS
    // ============================================================
    const animateOnScroll = () => {
      const elements = document.querySelectorAll(".animate-on-scroll")

      elements.forEach((el) => {
        const rect = el.getBoundingClientRect()
        const isVisible = rect.top < window.innerHeight && rect.bottom > 0

        if (isVisible) {
          el.classList.add("animated")
        }
      })
    }

    window.addEventListener("scroll", animateOnScroll)
    animateOnScroll() // Initial check
  })
})()
