<section class="hero-section" style="background: linear-gradient(to bottom, rgba(250,248,245,1), rgba(229,227,223,0.5));">
    <div class="container hero-content">
        <div style="text-align: center; margin-bottom: 32px;">
            <span style="font-size: 5rem; color: var(--accent); opacity: 0.6;">金</span>
        </div>
        <p style="text-transform: uppercase; letter-spacing: 0.2em; color: var(--muted-foreground); margin-bottom: 16px; text-align: center;">Cerámica · Arte · Kintsugi</p>
        <h1 class="hero-title">Transforma el silencio<br/><span style="color: var(--accent); font-weight: 600;">en oro</span></h1>
        <p class="hero-subtitle">Un puente cultural de cerámica entre México y Japón. Acompáñame en este viaje donde las fracturas no se ocultan, sino que se iluminan.</p>
        
        <div class="countdown" data-countdown="2026-08-01T00:00:00">
            <div class="countdown-item">
                <div class="countdown-value" data-days>45</div>
                <div class="countdown-label">Días</div>
            </div>
            <div class="countdown-item">
                <div class="countdown-value" data-hours>12</div>
                <div class="countdown-label">Horas</div>
            </div>
            <div class="countdown-item">
                <div class="countdown-value" data-minutes>30</div>
                <div class="countdown-label">Min</div>
            </div>
            <div class="countdown-item">
                <div class="countdown-value" data-seconds>00</div>
                <div class="countdown-label">Seg</div>
            </div>
        </div>

        <form class="email-capture-form" style="display: flex; gap: 16px; max-width: 600px; margin: 32px auto 0; flex-wrap: wrap; justify-content: center;">
            <input type="email" name="email" placeholder="Tu correo electrónico" required class="input-field" style="flex: 1; min-width: 250px;" />
            <button type="submit" class="btn btn-primary btn-lg">Únete al viaje</button>
        </form>
        <p style="text-align: center; margin-top: 16px; color: var(--muted-foreground); font-size: 0.875rem;">Sé parte de la creación. Sin spam, solo arte.</p>
    </div>
</section>
