"use client"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowDown, Users } from "lucide-react"
import { useRouter } from "next/navigation"
import Image from "next/image"

export function HeroSectionB() {
  const [timeLeft, setTimeLeft] = useState({
    days: 45,
    hours: 12,
    minutes: 30,
    seconds: 0,
  })

  const router = useRouter()

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 }
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const scrollToEmail = () => {
    const element = document.querySelector("[data-email-section]")
    element?.scrollIntoView({ behavior: "smooth" })
  }

  const scrollToGallery = () => {
    const element = document.querySelector("[data-gallery-section]")
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative min-h-screen flex flex-col justify-center items-center px-6 py-20 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-secondary/50 to-background" />

      <div className="absolute inset-0 opacity-20">
        <Image
          src="/beautiful-ceramic-pottery-art-kintsugi-gold.jpg"
          alt="Ceramic background"
          fill
          className="object-cover"
          priority
        />
      </div>

      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/65 to-black/70 backdrop-blur-sm" />

      {/* Decorative vertical line */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-32 bg-gradient-to-b from-transparent via-accent to-transparent animate-pulse"
        style={{ animationDuration: "3s" }}
      />

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Japanese character */}
        <div className="mb-8 animate-fade-in-scale">
          <span className="text-8xl md:text-9xl font-light text-accent opacity-60">金</span>
        </div>

        <div
          className="flex items-center justify-center gap-2 mb-6 animate-fade-in-up"
          style={{ animationDelay: "0.1s", opacity: 0, animationFillMode: "forwards" }}
        >
          <Users className="w-5 h-5 text-accent" />
          <p className="text-base text-muted-foreground">
            Over <span className="text-accent font-semibold">1,200 people</span> following this project
          </p>
        </div>

        <p
          className="text-base md:text-lg uppercase tracking-[0.3em] text-muted-foreground mb-6 animate-fade-in-up"
          style={{ animationDelay: "0.2s", opacity: 0, animationFillMode: "forwards" }}
        >
          Ceramics · Art · Kintsugi
        </p>

        <h1
          className="text-5xl md:text-6xl lg:text-7xl font-light leading-tight mb-6 text-balance animate-fade-in-up"
          style={{ animationDelay: "0.4s", opacity: 0, animationFillMode: "forwards" }}
        >
          Transform silence
          <span className="block text-accent font-medium">into gold</span>
        </h1>

        <p
          className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed text-pretty animate-fade-in-up"
          style={{ animationDelay: "0.6s", opacity: 0, animationFillMode: "forwards" }}
        >
          A journey of ceramics and kintsugi between Mexico and Japan. Fractures are not hidden, they are illuminated.
        </p>

        <div
          className="mb-8 animate-fade-in-up"
          style={{ animationDelay: "0.7s", opacity: 0, animationFillMode: "forwards" }}
        >
          <p className="text-sm uppercase tracking-widest text-muted-foreground mb-4">Launch in</p>
          <div className="flex justify-center gap-3 md:gap-4">
            {[
              { value: timeLeft.days, label: "Days" },
              { value: timeLeft.hours, label: "Hours" },
              { value: timeLeft.minutes, label: "Min" },
              { value: timeLeft.seconds, label: "Sec" },
            ].map((item, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="bg-card border-2 border-accent/40 rounded-sm px-3 md:px-4 py-2 md:py-3 min-w-[60px] md:min-w-[70px]">
                  <span className="text-2xl md:text-3xl font-bold text-accent">
                    {String(item.value).padStart(2, "0")}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground mt-1.5 uppercase tracking-wider">{item.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div
          className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up"
          style={{ animationDelay: "0.8s", opacity: 0, animationFillMode: "forwards" }}
        >
          <Button
            onClick={scrollToEmail}
            className="h-14 px-8 text-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-accent/20"
          >
            Exclusive Access
          </Button>
          <Button
            onClick={scrollToGallery}
            variant="outline"
            className="h-14 px-8 text-lg border-accent/30 hover:border-accent hover:bg-accent/10 transition-all duration-300 bg-transparent"
          >
            View Gallery
          </Button>
        </div>

        <p
          className="text-base text-muted-foreground mt-6 animate-fade-in-up"
          style={{ animationDelay: "0.9s", opacity: 0, animationFillMode: "forwards" }}
        >
          Be part of the creation from the start
        </p>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ArrowDown className="w-6 h-6 text-muted-foreground" />
      </div>
    </section>
  )
}
