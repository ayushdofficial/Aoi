<section class="section bg-secondary">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">¿Por qué apoyar?</h2>
        </div>
        <div class="tiers-grid">
            <div class="tier-card">
                <div style="width: 60px; height: 60px; background: rgba(255,83,73,0.1); border-radius: 50%; display: flex; align-items: center; justify-center; margin-bottom: 24px; font-size: 1.5rem;">
                    🎨
                </div>
                <h3 style="font-size: 1.25rem; margin-bottom: 12px;">Arte auténtico</h3>
                <p style="color: var(--muted-foreground);">Apoya la creación de piezas únicas que fusionan tradiciones de dos culturas.</p>
            </div>
            <div class="tier-card">
                <div style="width: 60px; height: 60px; background: rgba(255,83,73,0.1); border-radius: 50%; display: flex; align-items: center; justify-center; margin-bottom: 24px; font-size: 1.5rem;">
                    🧠
                </div>
                <h3 style="font-size: 1.25rem; margin-bottom: 12px;">Neurodiversidad</h3>
                <p style="color: var(--muted-foreground);">Celebra el arte creado desde una perspectiva neurodivergente única.</p>
            </div>
            <div class="tier-card">
                <div style="width: 60px; height: 60px; background: rgba(255,83,73,0.1); border-radius: 50%; display: flex; align-items: center; justify-center; margin-bottom: 24px; font-size: 1.5rem;">
                    🌏
                </div>
                <h3 style="font-size: 1.25rem; margin-bottom: 12px;">Puente cultural</h3>
                <p style="color: var(--muted-foreground);">Sé parte del viaje que conecta la cerámica mexicana con el kintsugi japonés.</p>
            </div>
        </div>
    </div>
</section>
