import { Card } from "@/components/ui/card"
import { Sparkles, Droplets, Shield, CheckCircle2 } from "lucide-react"

const steps = [
  {
    number: "1",
    title: "Selección del Barro",
    description: "Elijo cuidadosamente la arcilla, considerando color, textura y propiedades.",
    icon: Sparkles,
  },
  {
    number: "2",
    title: "Modelado y Forma",
    description: "Usando el torno y técnicas manuales, doy forma a la pieza.",
    icon: Shield,
  },
  {
    number: "3",
    title: "Secado y Cocción",
    description: "La pieza se seca lentamente, luego se cuece en el horno.",
    icon: Droplets,
  },
  {
    number: "4",
    title: "Kintsugi - La Reparación Sagrada",
    description: "Reparo la pieza con oro o plata, celebrando sus imperfecciones.",
    icon: CheckCircle2,
  },
]

export function ProcessStepsSection() {
  return (
    <section className="w-full py-20 px-4 bg-background">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">El Proceso, Paso a Paso</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Cada pieza que creo es una aventura neurodivergente única
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {steps.map((step, index) => {
            const Icon = step.icon
            return (
              <Card
                key={index}
                className="p-8 border border-border/50 hover:border-primary/50 transition-colors bg-card/50"
              >
                <div className="flex gap-4 mb-4">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <span className="inline-flex items-center justify-center px-3 py-1 rounded-full text-sm font-bold bg-primary/20 text-primary mb-2">
                      Paso {step.number}
                    </span>
                    <h3 className="text-xl font-bold text-foreground">{step.title}</h3>
                  </div>
                </div>
                <p className="text-muted-foreground leading-relaxed">{step.description}</p>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
