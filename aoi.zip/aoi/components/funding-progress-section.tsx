"use client"

import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Target, TrendingUp, Users, Calendar } from "lucide-react"

export function FundingProgressSection() {
  const fundingGoal = 5000
  const fundingCurrent = 2847
  const fundingPercentage = (fundingCurrent / fundingGoal) * 100

  const targetDate = new Date("2026-08-01")
  const today = new Date()
  const daysRemaining = Math.ceil((targetDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
  const monthsRemaining = Math.floor(daysRemaining / 30)

  // Funding milestones
  const milestones = [
    { amount: 1000, label: "Materiales", reached: fundingCurrent >= 1000 },
    { amount: 2500, label: "Boletos Aéreos", reached: fundingCurrent >= 2500 },
    { amount: 4000, label: "Estancia en Japón", reached: fundingCurrent >= 4000 },
    { amount: 5000, label: "Equipo de Grabación", reached: fundingCurrent >= 5000 },
  ]

  return (
    <section className="py-16 px-4 bg-gradient-to-b from-background to-secondary/10">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">El Viaje Depende de Ti</h2>
          <p className="text-xl text-foreground/80">
            Juntos financiamos la misión: apoyar arte neurodivergente desde Japón
          </p>
        </div>

        {/* Main Progress Card */}
        <Card className="p-8 mb-8 border-2 border-accent/30">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {/* Progress */}
            <div className="md:col-span-2">
              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-lg font-semibold">Progreso de Financiamiento</h3>
                  <span className="text-2xl font-bold text-accent">{fundingPercentage.toFixed(0)}%</span>
                </div>
                <Progress value={fundingPercentage} className="h-3" />
                <div className="flex justify-between text-sm text-foreground/60 mt-2">
                  <span>${fundingCurrent.toLocaleString()}</span>
                  <span>${fundingGoal.toLocaleString()}</span>
                </div>
              </div>

              <div className="flex items-center gap-2 text-accent font-semibold">
                <TrendingUp className="w-5 h-5" />
                {fundingPercentage < 100
                  ? `Necesitamos $${(fundingGoal - fundingCurrent).toLocaleString()} más`
                  : "Meta alcanzada"}
              </div>
            </div>

            {/* Deadline */}
            <div className="bg-primary/5 rounded-lg p-6 border border-primary/20">
              <div className="flex items-center gap-2 mb-3">
                <Calendar className="w-5 h-5 text-accent" />
                <span className="font-semibold">Salida a Japón</span>
              </div>
              <div className="text-4xl font-bold mb-2">Agosto 2026</div>
              <div className="text-sm text-foreground/60">
                {monthsRemaining} meses y {daysRemaining % 30} días
              </div>
              <div className="mt-4 text-xs bg-accent/10 text-accent px-2 py-1 rounded font-semibold w-fit">
                CUENTA REGRESIVA ACTIVA
              </div>
            </div>
          </div>
        </Card>

        {/* Milestones */}
        <div className="mb-8">
          <h3 className="text-xl font-bold mb-6">Hitos de Financiamiento</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {milestones.map((milestone, idx) => (
              <Card
                key={idx}
                className={`p-4 border-2 transition-all ${
                  milestone.reached ? "border-accent bg-accent/5" : "border-secondary/30 opacity-60"
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <span className="text-sm font-semibold text-foreground/70">${milestone.amount}</span>
                  {milestone.reached && (
                    <div className="w-6 h-6 rounded-full bg-accent flex items-center justify-center text-white text-sm">
                      ✓
                    </div>
                  )}
                </div>
                <p className="font-semibold">{milestone.label}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* Limited Bonuses */}
        <Card className="bg-gradient-to-r from-accent/10 to-accent/5 border-2 border-accent/30 p-6 mb-8">
          <div className="flex items-start gap-3 mb-4">
            <div className="flex-shrink-0 w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center">
              <span className="text-accent font-bold text-lg">!</span>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-2">Ofertas Limitadas en Vigencia</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  <span>Primeros 50 suscriptores: Acceso a 12 transmisiones en vivo por solo $5</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  <span>Quienes se suscriban antes de marzo 2026: Sesión privada de Q&A</span>
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-accent rounded-full"></span>
                  <span>Apoyo inicial: Descuento extra 25% en tienda exclusiva</span>
                </li>
              </ul>
            </div>
          </div>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Users className="w-5 h-5 text-accent" />
              <span className="text-2xl font-bold">487</span>
            </div>
            <p className="text-sm text-foreground/60">Mecenas Activos</p>
          </Card>
          <Card className="p-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Target className="w-5 h-5 text-accent" />
              <span className="text-2xl font-bold">${fundingCurrent.toLocaleString()}</span>
            </div>
            <p className="text-sm text-foreground/60">Recaudado</p>
          </Card>
          <Card className="p-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Calendar className="w-5 h-5 text-accent" />
              <span className="text-2xl font-bold">{monthsRemaining}m</span>
            </div>
            <p className="text-sm text-foreground/60">Para el Viaje</p>
          </Card>
        </div>
      </div>
    </section>
  )
}
