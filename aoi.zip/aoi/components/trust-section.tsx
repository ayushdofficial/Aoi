"use client"

import { useEffect, useRef, useState } from "react"
import { Calendar, Package, BookOpen, MessageCircle } from "lucide-react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function TrustSection() {
  const header = useScrollAnimation()
  const badges = useScrollAnimation()

  const guarantees = [
    {
      icon: Calendar,
      title: "Advance planning",
      description: "All trips are planned 6+ months in advance",
    },
    {
      icon: Package,
      title: "Professional packaging",
      description: "Use of professional packaging for fragile ceramics",
    },
    {
      icon: BookOpen,
      title: "Constant documentation",
      description: "Every stage will be documented so you can be part of the process",
    },
    {
      icon: MessageCircle,
      title: "Direct communication",
      description: "Constant communication via Kickstarter, email and social media",
    },
  ]

  return (
    <section className="py-24 px-6 bg-card overflow-hidden">
      <div className="max-w-5xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-16 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">Commitment</p>
          <h2 className="text-4xl md:text-5xl font-light">Your trust is sacred</h2>
          <div className="flex justify-center mt-6">
            <div
              className={`h-0.5 bg-gradient-to-r from-transparent via-accent to-transparent transition-all duration-1000 delay-300 ${
                header.isVisible ? "w-32" : "w-0"
              }`}
            />
          </div>
        </div>

        <div ref={badges.ref} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {guarantees.map((item, index) => (
            <div
              key={index}
              className={`text-center p-6 rounded-sm border border-transparent hover:border-accent/30 hover:bg-secondary/30 transition-all duration-500 hover:-translate-y-1 ${
                badges.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-secondary mb-4 transition-all duration-300 group-hover:scale-110">
                <item.icon className="w-7 h-7 text-accent" />
              </div>
              <h3 className="font-medium text-lg mb-2">{item.title}</h3>
              <p className="text-base text-muted-foreground">{item.description}</p>
            </div>
          ))}
        </div>

        <SectionCTA text="Be part of the workshop" variant="subtle" />
      </div>
    </section>
  )
}
