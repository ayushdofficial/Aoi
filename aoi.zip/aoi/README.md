# Aoi Cerámica WordPress Theme

A multi-version sales funnel WordPress theme for ceramic artist Daniel Lojo's kintsugi journey from Mexico to Japan.

## Features

- **8 Different Landing Page Versions** (A-I) with tab switching
- **Responsive Design** - Mobile-first approach
- **Scroll Animations** - Smooth entrance animations
- **Countdown Timer** - Dynamic JavaScript countdown
- **FAQ Accordion** - Expandable questions and answers  
- **Email Capture** - AJAX form submission
- **Patreon Integration** - Direct links to support
- **Cookie Persistence** - Remembers user's selected version
- **URL Parameters** - Force specific version with `?variant=i`

## Installation

### Method 1: Direct Upload

1. Download the theme files
2. Upload entire folder to `wp-content/themes/`
3. Rename folder to `aoi-ceramica`
4. Activate theme in WordPress Admin → Appearance → Themes

### Method 2: ZIP Upload

1. Create ZIP of theme folder
2. Go to WordPress Admin → Appearance → Themes → Add New → Upload Theme
3. Select ZIP file and upload
4. Activate the theme

## Setup

### Add Images

Place your ceramic images in the `images/` folder:

- `ceramic-artist-working.jpg`
- `hands-molding-clay.jpg`
- `kintsugi-gold-repair.jpg`
- `mexican-pottery.jpg`
- `japanese-pottery-studio.jpg`

Or use the placeholder URLs already in the code.

### Configure Patreon Link

Update the Patreon URL in `functions.php`:

```php
function aoi_get_patreon_link() {
    return 'https://www.patreon.com/YOUR_PATREON_USERNAME';
}
```

### Email Capture Integration

The theme includes AJAX email capture. Emails are stored in WordPress options by default. To integrate with an email service:

1. Edit `functions.php`
2. Find the `aoi_handle_email_capture()` function
3. Add your email service API integration (Mailchimp, ConvertKit, etc.)

## Theme Structure

```
aoi-ceramica/
├── style.css              # Main stylesheet with all design
├── functions.php          # Theme functions and AJAX handlers
├── index.php              # Main template with all versions
├── header.php             # Header template
├── footer.php             # Footer template
├── js/
│   └── main.js            # All JavaScript functionality
├── template-parts/
│   ├── version-a.php      # Version A: Classical
│   ├── version-i.php      # Version I: Patreon
│   └── sections/
│       ├── story.php      # Story section
│       ├── gallery.php    # Gallery section
│       ├── journey.php    # Journey section
│       └── faq.php        # FAQ section
├── images/                # Place your images here
└── README.md              # This file
```

## Version Descriptions

- **Version A (Clásica)**: Traditional flow with countdown, hero, gallery, story, journey
- **Version B (Testimonios)**: Testimonial-focused layout
- **Version C (Timeline)**: Timeline storytelling
- **Version D (Personalizada)**: Multi-step subscription
- **Version F (Educativa)**: Educational 2-step process
- **Version G (Urgencia)**: Urgency-driven flow
- **Version H (Premium)**: Premium positioning
- **Version I (Patreon)**: Main Patreon-focused 3-step flow ⭐

## Customization

### Colors

Edit design tokens in `style.css`:

```css
:root {
  --cream: #FAF7F2;
  --coral: #FF424D;
  --charcoal: #2F3437;
}
```

### Fonts

The theme uses Cormorant Garamond from Google Fonts. To change:

1. Update the `@import` URL in `style.css`
2. Change `--font-sans` variable

### Content

Edit content directly in the template part files in `template-parts/` folder.

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance

- Minimal dependencies (no frameworks)
- Optimized CSS (single file)
- Vanilla JavaScript (no jQuery)
- Lazy loading ready for images

## Support

For questions or issues:
- Email: aoiceramica@gmail.com
- GitHub: [Your repo URL]

## License

GPL v2 or later

## Credits

- Design & Development: v0.app
- Client: Daniel Lojo - Aoi Cerámica
- Fonts: Google Fonts (Cormorant Garamond)
