"use client"
import { Check, X } from "lucide-react"

export function SubscriptionComparison() {
  const features = [
    {
      category: "Acceso & Comunidad",
      items: [
        { name: "Actualizaciones por email", suscripcion: true, mecenazgo: true },
        { name: "Comunidad Discord privada", suscripcion: true, mecenazgo: false },
        { name: "Contenido exclusivo de video", suscripcion: true, mecenazgo: false },
        { name: "Acceso a tutoriales", suscripcion: true, mecenazgo: false },
      ],
    },
    {
      category: "Interacción",
      items: [
        { name: "Sesiones Q&A mensuales", suscripcion: true, mecenazgo: false },
        { name: "Video calls privados", suscripcion: "Premium", mecenazgo: false },
        { name: "Influencia en decisiones", suscripcion: true, mecenazgo: false },
        { name: "Votaciones mensuales", suscripcion: true, mecenazgo: false },
      ],
    },
    {
      category: "Recompensas Físicas",
      items: [
        { name: "Piezas exclusivas", suscripcion: "Trimestral", mecenazgo: "Una sola" },
        { name: "Envío gratis", suscripcion: "Premium", mecenazgo: false },
        { name: "Acceso a archivo personal", suscripcion: true, mecenazgo: false },
      ],
    },
  ]

  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-light mb-4">Suscripción vs Mecenazgo</h2>
          <p className="text-lg text-muted-foreground">Compara los beneficios de cada modelo de apoyo</p>
        </div>

        <div className="space-y-8">
          {features.map((section, idx) => (
            <div key={idx} className="border border-border/50 rounded-lg overflow-hidden">
              <div className="bg-secondary/30 px-6 py-4 border-b border-border/50">
                <h3 className="text-lg font-medium">{section.category}</h3>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border/50">
                      <th className="text-left px-6 py-4 font-medium">Característica</th>
                      <th className="text-center px-6 py-4 font-medium text-accent">Suscripción</th>
                      <th className="text-center px-6 py-4 font-medium">Mecenazgo</th>
                    </tr>
                  </thead>
                  <tbody>
                    {section.items.map((item, i) => (
                      <tr key={i} className="border-b border-border/30 hover:bg-secondary/20 transition-colors">
                        <td className="px-6 py-4">{item.name}</td>
                        <td className="text-center px-6 py-4">
                          {item.suscripcion === true ? (
                            <Check className="w-5 h-5 text-accent mx-auto" />
                          ) : item.suscripcion === false ? (
                            <X className="w-5 h-5 text-muted-foreground/40 mx-auto" />
                          ) : (
                            <span className="text-sm text-accent font-medium">{item.suscripcion}</span>
                          )}
                        </td>
                        <td className="text-center px-6 py-4">
                          {item.mecenazgo === true ? (
                            <Check className="w-5 h-5 text-foreground/60 mx-auto" />
                          ) : item.mecenazgo === false ? (
                            <X className="w-5 h-5 text-muted-foreground/40 mx-auto" />
                          ) : (
                            <span className="text-sm text-foreground/60">{item.mecenazgo}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-accent/5 border border-accent/20 rounded-lg p-8 text-center">
          <p className="text-lg mb-4">¿Quieres ambos? Puedes combinar suscripción y realizar una aportación única.</p>
          <p className="text-sm text-muted-foreground">
            Los fondos se utilizan para financiar investigación, materiales y el viaje a Japón.
          </p>
        </div>
      </div>
    </section>
  )
}
