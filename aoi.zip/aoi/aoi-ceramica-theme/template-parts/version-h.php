<!-- Version H: Premium - Premium positioning -->
<section class="hero-section" style="background: linear-gradient(135deg, var(--charcoal) 0%, #1a1a1a 100%); color: white;">
    <div class="container hero-content">
        <div style="width: 80px; height: 80px; background: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-center; margin: 0 auto 24px; font-size: 2rem;">
            金
        </div>
        <h1 class="hero-title" style="color: white;">Arte de colección<br/><span style="color: var(--gold);">Edición limitada</span></h1>
        <p class="hero-subtitle" style="color: rgba(255,255,255,0.8);">Piezas únicas creadas por un maestro ceramista con 22 años de experiencia</p>
        <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; margin-top: 32px;">
            <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-lg" style="background: var(--gold); color: var(--charcoal);">Explorar colección</a>
        </div>
    </div>
</section>

<section class="section bg-white">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Especificaciones técnicas</h2>
            <p class="section-subtitle">Detalles que hacen la diferencia</p>
        </div>
        <div class="tiers-grid">
            <div class="tier-card">
                <h3 style="font-size: 1.25rem; margin-bottom: 16px; color: var(--accent);">Materiales premium</h3>
                <ul style="list-style: none; padding: 0;">
                    <li style="padding: 8px 0; border-bottom: 1px solid var(--muted);">✓ Arcilla de gres de alta temperatura</li>
                    <li style="padding: 8px 0; border-bottom: 1px solid var(--muted);">✓ Esmaltes japoneses certificados</li>
                    <li style="padding: 8px 0;">✓ Oro de 24k para kintsugi</li>
                </ul>
            </div>
            <div class="tier-card">
                <h3 style="font-size: 1.25rem; margin-bottom: 16px; color: var(--accent);">Proceso artesanal</h3>
                <ul style="list-style: none; padding: 0;">
                    <li style="padding: 8px 0; border-bottom: 1px solid var(--muted);">✓ 100% hecho a mano</li>
                    <li style="padding: 8px 0; border-bottom: 1px solid var(--muted);">✓ Quema a 1280°C</li>
                    <li style="padding: 8px 0;">✓ Tiempo de creación: 4-6 semanas</li>
                </ul>
            </div>
            <div class="tier-card">
                <h3 style="font-size: 1.25rem; margin-bottom: 16px; color: var(--accent);">Autenticidad</h3>
                <ul style="list-style: none; padding: 0;">
                    <li style="padding: 8px 0; border-bottom: 1px solid var(--muted);">✓ Certificado de autenticidad</li>
                    <li style="padding: 8px 0; border-bottom: 1px solid var(--muted);">✓ Firmada por el artista</li>
                    <li style="padding: 8px 0;">✓ Numeración única</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/sections/story'); ?>
<?php get_template_part('template-parts/sections/gallery'); ?>

<section class="section bg-secondary">
    <div class="container" style="max-width: 800px; text-align: center;">
        <h2 class="section-title">Inversión en arte auténtico</h2>
        <p style="font-size: 1.125rem; color: var(--muted-foreground); margin-bottom: 32px;">Cada pieza es una inversión en creatividad neurodivergente y tradición artesanal</p>
        <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-primary btn-lg">Solicitar información</a>
    </div>
</section>

<?php get_template_part('template-parts/sections/faq'); ?>
