# Aoi Cerámica Sales Funnel WordPress Theme

Complete multi-variant sales funnel theme for Aoi Cerámica with 8 different landing page versions and A/B testing functionality.

## Features

### 8 Landing Page Versions
- **Version A (Clásica)**: Traditional marketing flow with countdown timer
- **Version B (Testimonios)**: Testimonial-focused variant
- **Version C (Timeline)**: Timeline-based storytelling
- **Version D (Personalizada)**: Multi-step subscription flow
- **Version F (Educativa)**: 2-step educational approach
- **Version G (Urgencia)**: Urgency-based messaging
- **Version H (Premium)**: Premium positioning with tech specs
- **Version I (Patreon)**: Primary Patreon-focused 3-step flow ⭐

### Core Functionality
- ✅ Tab-based version switching (bottom navigation)
- ✅ Cookie-based variant persistence
- ✅ URL parameter support (?variant=i)
- ✅ Email capture with AJAX
- ✅ FAQ accordion
- ✅ Countdown timer
- ✅ Smooth scroll animations
- ✅ Lazy loading images
- ✅ Fully responsive design
- ✅ Mobile-first approach

## Installation

### Method 1: Upload to WordPress

1. Download or copy the `wordpress-theme` folder
2. Rename to `aoi-ceramica`
3. Upload to `wp-content/themes/` via FTP or cPanel
4. Go to WordPress Admin → Appearance → Themes
5. Activate "Aoi Ceramica Sales Funnel"

### Method 2: ZIP Upload

1. Compress the `wordpress-theme` folder as a ZIP file
2. Go to WordPress Admin → Appearance → Themes → Add New
3. Click "Upload Theme" → Choose File
4. Select the ZIP file and click "Install Now"
5. Click "Activate"

## Configuration

### Add Your Images

Place your images in `wordpress-theme/images/` folder:
- `ceramic-artist-working.jpg` - Hero image for Version I
- `kintsugi-gold-repair.jpg` - Kintsugi process
- `mexican-pottery.jpg` - Traditional ceramics
- `japanese-studio.jpg` - Studio workspace
- `ceramic-hands.jpg` - Hands working with clay

### Update Patreon Links

Search and replace all instances of:
```
https://www.patreon.com/cw/aoi_kitsune
```

With your actual Patreon URL.

### Email Integration

Edit `functions.php` at line ~82 to integrate with your email service:
```php
function aoi_ceramica_handle_email_capture() {
    // Add integration with Mailchimp, ConvertKit, etc.
}
```

## Version Switching

Users can switch between variants using the bottom tab navigation. The selected variant is saved in a cookie and persists across page reloads.

### URL Parameters

Force a specific variant by adding to URL:
- `?variant=a` - Version A (Classical)
- `?variant=b` - Version B (Testimonials)
- `?variant=c` - Version C (Timeline)
- `?variant=d` - Version D (Personalized)
- `?variant=f` - Version F (Educational)
- `?variant=g` - Version G (Urgency)
- `?variant=h` - Version H (Premium)
- `?variant=i` - Version I (Patreon) - Default

## Template Files

### Core Templates
- `index.php` - Main template with version routing
- `header.php` - Site header
- `footer.php` - Site footer with tabs and FAQs
- `functions.php` - Theme functions and hooks

### Version Templates
- `template-parts/version-a.php` - Classical version
- `template-parts/version-b.php` - Testimonials version
- `template-parts/version-c.php` - Timeline version
- `template-parts/version-d.php` - Personalized version
- `template-parts/version-f.php` - Educational version
- `template-parts/version-g.php` - Urgency version
- `template-parts/version-h.php` - Premium version
- `template-parts/version-i.php` - Patreon version (Main)

## Customization

### Colors

Edit `style.css` starting at line 14:
```css
:root {
  --cream: #f9f7f4;
  --coral: #ff6b6b;
  --charcoal: #2d3436;
  --gold: #d4af37;
}
```

### Typography

The theme uses **Cormorant Garamond** from Google Fonts. To change:
1. Edit Google Fonts URL in `functions.php` (line ~31)
2. Update CSS variables in `style.css` (line ~39)

### Countdown Target Date

For versions with countdown timers, update the JavaScript in `main.js`:
```javascript
const targetDate = new Date('2025-12-31').getTime();
```

## Shortcodes

### Patreon Link
```php
[patreon_link text="Join on Patreon" class="btn btn-primary"]
```

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance

- Minified CSS/JS (production ready)
- Lazy loading images
- Optimized Google Fonts loading
- No external dependencies (except fonts)
- Lightweight (< 200KB total)

## Support

For questions or issues:
- Email: aoiceramica@gmail.com
- Instagram: [@aoi_ceramica](https://www.instagram.com/aoi_ceramica/)

## License

GPL v2 or later

## Credits

- **Design & Development**: v0.dev
- **Client**: Daniel Lojo - Aoi Cerámica
- **Inspiration**: Patreon's design system

---

**Made with ❤️ for neurodivergent artists**
