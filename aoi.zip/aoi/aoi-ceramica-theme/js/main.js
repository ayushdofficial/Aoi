;(() => {
  // Declare aoiAjax variable
  const aoiAjax = {
    nonce: "your_nonce_value_here",
    ajaxurl: "your_ajax_url_here",
  }

  // Tab Switching
  function initTabs() {
    const tabButtons = document.querySelectorAll(".tab-button")
    const versionContents = document.querySelectorAll(".version-content")

    // Check URL parameter for initial variant
    const urlParams = new URLSearchParams(window.location.search)
    const urlVariant = urlParams.get("variant")

    // Check cookie for saved variant
    const savedVariant = getCookie("aoi_selected_variant")

    // Determine initial variant
    let initialVariant = "version-a"
    if (urlVariant) {
      initialVariant = "version-" + urlVariant
    } else if (savedVariant) {
      initialVariant = savedVariant
    }

    // Set initial active state
    setActiveTab(initialVariant)

    tabButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const targetId = this.dataset.tab
        setActiveTab(targetId)

        // Save to cookie
        setCookie("aoi_selected_variant", targetId, 30)

        // Scroll to top
        window.scrollTo({ top: 0, behavior: "smooth" })
      })
    })

    function setActiveTab(targetId) {
      // Remove all active classes
      tabButtons.forEach((btn) => btn.classList.remove("active"))
      versionContents.forEach((content) => content.classList.remove("active"))

      // Add active class to target
      const targetButton = document.querySelector(`[data-tab="${targetId}"]`)
      const targetContent = document.getElementById(targetId)

      if (targetButton && targetContent) {
        targetButton.classList.add("active")
        targetContent.classList.add("active")
      }
    }
  }

  // Countdown Timer
  function initCountdown() {
    const countdownElements = document.querySelectorAll("[data-countdown]")

    countdownElements.forEach((element) => {
      const targetDate = new Date(element.dataset.countdown).getTime()

      function updateCountdown() {
        const now = new Date().getTime()
        const distance = targetDate - now

        if (distance < 0) {
          element.innerHTML = '<div class="countdown-expired">¡Campaña activa!</div>'
          return
        }

        const days = Math.floor(distance / (1000 * 60 * 60 * 24))
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60))
        const seconds = Math.floor((distance % (1000 * 60)) / 1000)

        element.querySelector("[data-days]").textContent = String(days).padStart(2, "0")
        element.querySelector("[data-hours]").textContent = String(hours).padStart(2, "0")
        element.querySelector("[data-minutes]").textContent = String(minutes).padStart(2, "0")
        element.querySelector("[data-seconds]").textContent = String(seconds).padStart(2, "0")
      }

      updateCountdown()
      setInterval(updateCountdown, 1000)
    })
  }

  // FAQ Accordion
  function initFAQ() {
    const faqQuestions = document.querySelectorAll(".faq-question")

    faqQuestions.forEach((question) => {
      question.addEventListener("click", function () {
        const faqItem = this.closest(".faq-item")
        const isActive = faqItem.classList.contains("active")

        // Close all FAQs
        document.querySelectorAll(".faq-item").forEach((item) => {
          item.classList.remove("active")
        })

        // Open clicked FAQ if it wasn't active
        if (!isActive) {
          faqItem.classList.add("active")
        }
      })
    })
  }

  // Email Capture Forms
  function initEmailForms() {
    const emailForms = document.querySelectorAll(".email-capture-form")

    emailForms.forEach((form) => {
      form.addEventListener("submit", async function (e) {
        e.preventDefault()

        const emailInput = this.querySelector('input[type="email"]')
        const submitButton = this.querySelector('button[type="submit"]')
        const email = emailInput.value
        const variant = document.querySelector(".version-content.active").dataset.variant

        // Disable button
        submitButton.disabled = true
        submitButton.innerHTML = '<span class="loading"></span> Enviando...'

        try {
          const formData = new FormData()
          formData.append("action", "aoi_email_capture")
          formData.append("nonce", aoiAjax.nonce)
          formData.append("email", email)
          formData.append("variant", variant)

          const response = await fetch(aoiAjax.ajaxurl, {
            method: "POST",
            body: formData,
          })

          const data = await response.json()

          if (data.success) {
            // Show success message
            this.innerHTML = `
                            <div class="success-message" style="background: rgba(255, 83, 73, 0.1); border: 2px solid var(--accent); border-radius: var(--radius); padding: 20px; text-align: center;">
                                <h3 style="color: var(--accent); margin-bottom: 8px;">¡Gracias por unirte!</h3>
                                <p style="color: var(--muted-foreground);">Pronto recibirás noticias de este viaje.</p>
                            </div>
                        `
          } else {
            throw new Error(data.data.message || "Error al enviar")
          }
        } catch (error) {
          alert("Hubo un error. Por favor, intenta de nuevo.")
          submitButton.disabled = false
          submitButton.innerHTML = "Únete al viaje"
        }
      })
    })
  }

  // Scroll Animations
  function initScrollAnimations() {
    const animatedElements = document.querySelectorAll(".animate-on-scroll")

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible")
          }
        })
      },
      {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px",
      },
    )

    animatedElements.forEach((el) => observer.observe(el))
  }

  // Scroll to Top Button
  function initScrollToTop() {
    const scrollButton = document.getElementById("scrollToTop")

    if (!scrollButton) return

    window.addEventListener("scroll", () => {
      if (window.pageYOffset > 300) {
        scrollButton.classList.add("visible")
      } else {
        scrollButton.classList.remove("visible")
      }
    })

    scrollButton.addEventListener("click", () => {
      window.scrollTo({ top: 0, behavior: "smooth" })
    })
  }

  // Smooth Scroll for Anchor Links
  function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
      anchor.addEventListener("click", function (e) {
        const targetId = this.getAttribute("href")
        if (targetId === "#") return

        const targetElement = document.querySelector(targetId)
        if (targetElement) {
          e.preventDefault()
          targetElement.scrollIntoView({ behavior: "smooth" })
        }
      })
    })
  }

  // Cookie Helpers
  function setCookie(name, value, days) {
    const expires = new Date()
    expires.setTime(expires.getTime() + days * 24 * 60 * 60 * 1000)
    document.cookie = name + "=" + value + ";expires=" + expires.toUTCString() + ";path=/"
  }

  function getCookie(name) {
    const nameEQ = name + "="
    const ca = document.cookie.split(";")
    for (let i = 0; i < ca.length; i++) {
      let c = ca[i]
      while (c.charAt(0) === " ") c = c.substring(1, c.length)
      if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length)
    }
    return null
  }

  // Initialize everything when DOM is ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init)
  } else {
    init()
  }

  function init() {
    initTabs()
    initCountdown()
    initFAQ()
    initEmailForms()
    initScrollAnimations()
    initScrollToTop()
    initSmoothScroll()
  }
})()
