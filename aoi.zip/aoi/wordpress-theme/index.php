<?php
/**
 * Main Template File
 *
 * @package Aoi_Ceramica
 */

get_header();

$active_variant = aoi_get_active_variant();
?>

<main id="main-content" class="site-main">
    <?php
    // Version A - Classical
    if ($active_variant === 'a') {
        get_template_part('template-parts/version-a');
    }
    // Version B - Testimonials
    elseif ($active_variant === 'b') {
        get_template_part('template-parts/version-b');
    }
    // Version C - Timeline
    elseif ($active_variant === 'c') {
        get_template_part('template-parts/version-c');
    }
    // Version D - Personalized/Multi-step
    elseif ($active_variant === 'd') {
        get_template_part('template-parts/version-d');
    }
    // Version F - Educational
    elseif ($active_variant === 'f') {
        get_template_part('template-parts/version-f');
    }
    // Version G - Urgency
    elseif ($active_variant === 'g') {
        get_template_part('template-parts/version-g');
    }
    // Version H - Premium
    elseif ($active_variant === 'h') {
        get_template_part('template-parts/version-h');
    }
    // Version I - Patreon (Default)
    else {
        get_template_part('template-parts/version-i');
    }
    ?>
</main>

<?php get_footer(); ?>
