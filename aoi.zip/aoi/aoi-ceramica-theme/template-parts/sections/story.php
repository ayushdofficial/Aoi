<section class="section bg-secondary" data-story-section>
    <div class="container animate-on-scroll">
        <div class="section-header">
            <p style="text-transform: uppercase; letter-spacing: 0.2em; color: var(--accent); margin-bottom: 16px;">Mi Historia</p>
            <h2 class="section-title">Hola, soy Daniel</h2>
            <p class="section-subtitle">Ceramista mexicano, artista neurodivergente, y contador de historias en arcilla</p>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 48px; align-items: center; margin-top: 64px;">
            <div style="aspect-ratio: 4/5; border-radius: var(--radius); overflow: hidden;">
                <div style="width: 100%; height: 100%; background: var(--muted);"></div>
            </div>
            <div>
                <p style="font-size: 1.5rem; line-height: 1.6; margin-bottom: 24px;">
                    <span style="color: var(--accent); font-weight: 600;">Cada pieza que creo es una conversación sin palabras.</span>
                </p>
                <p style="font-size: 1.125rem; color: var(--muted-foreground); line-height: 1.7; margin-bottom: 16px;">
                    Desde los 12 años, la arcilla ha sido mi lenguaje. Ahora tengo 34 y llevo 22 años creando. Crecí rodeado de hornos encendidos y las enseñanzas de dos figuras clave: Mi padre, <strong>Juan Lojo Romero</strong>, y mi maestro, <strong>Alberto Díaz de Cossío</strong>.
                </p>
            </div>
        </div>
    </div>
</section>
