"use client"

import { Star } from "lucide-react"

interface Testimonial {
  name: string
  title: string
  text: string
  rating: number
  tier: string
}

const testimonials: Testimonial[] = [
  {
    name: "María García",
    title: "Colectora desde hace 3 meses",
    text: "Soy crítica de arte y esta suscripción me permite ver el proceso creativo mes a mes. Las votaciones me hacen sentir parte real del proyecto. Recomendable 100%.",
    rating: 5,
    tier: "Colector",
  },
  {
    name: "Juan Rodríguez",
    title: "Apoyo desde el inicio",
    text: "Al principio no sabía si era la cantidad correcta, pero los emails y descuentos justifican cada peso. Ahora son mis piezas favoritas en la colección.",
    rating: 5,
    tier: "Apoyo",
  },
  {
    name: "Elena Martínez",
    title: "Mecenas+ hace 2 meses",
    text: "Los video calls privados cambiaron mi perspectiva sobre el arte y la neurodivergencia. Recibir una pieza exclusiva cada trimestre es increíble. Inversión que vale cada céntimo.",
    rating: 5,
    tier: "Mecenas+",
  },
  {
    name: "Carlos López",
    title: "Colector",
    text: "La comunidad Discord es increíble. He conocido coleccionistas de todo Latinoamérica. Las sesiones Q&A con Daniel me inspiraron a empezar a crear también.",
    rating: 5,
    tier: "Colector",
  },
]

export function SubscriptionTestimonials() {
  return (
    <section className="py-20 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-light mb-4">Lo que dicen nuestros suscriptores</h2>
          <p className="text-lg text-muted-foreground">Miles de personas apoyan este proyecto mensualmente</p>
          <div className="flex justify-center items-center gap-4 mt-8">
            <div className="text-center">
              <p className="text-4xl font-bold text-accent">1,200+</p>
              <p className="text-sm text-muted-foreground">Suscriptores activos</p>
            </div>
            <div className="w-px h-12 bg-border/50"></div>
            <div className="text-center">
              <p className="text-4xl font-bold text-accent">4.9/5</p>
              <p className="text-sm text-muted-foreground">Calificación promedio</p>
            </div>
            <div className="w-px h-12 bg-border/50"></div>
            <div className="text-center">
              <p className="text-4xl font-bold text-accent">98%</p>
              <p className="text-sm text-muted-foreground">Retención mensual</p>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {testimonials.map((testimonial, i) => (
            <div
              key={i}
              className="border border-border/50 rounded-lg p-6 bg-card/50 hover:shadow-lg hover:shadow-accent/5 transition-all duration-300"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <p className="font-medium text-foreground">{testimonial.name}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.title}</p>
                </div>
                <div className="flex gap-1">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-accent text-accent" />
                  ))}
                </div>
              </div>

              <p className="text-sm text-foreground/80 mb-4 italic">"{testimonial.text}"</p>

              <div className="inline-block px-3 py-1 bg-accent/10 text-accent text-xs rounded-full font-medium">
                {testimonial.tier}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
