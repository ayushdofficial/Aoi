<section class="section bg-secondary" id="journey-section">
    <div class="container animate-on-scroll">
        <div class="section-header">
            <h2 class="section-title">El viaje hasta aquí</h2>
        </div>
        <div class="timeline">
            <div class="timeline-line"></div>
            <div class="timeline-item">
                <div style="text-align: right;">
                    <p style="font-size: 2rem; font-weight: 700; color: var(--accent); margin-bottom: 8px;">2003</p>
                    <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">Primeros pasos</h3>
                    <p style="color: var(--muted-foreground);">A los 12 años, comienzo mi formación formal con mi padre y el maestro Alberto.</p>
                </div>
                <div class="timeline-dot"></div>
                <div></div>
            </div>
            <div class="timeline-item">
                <div></div>
                <div class="timeline-dot"></div>
                <div>
                    <p style="font-size: 2rem; font-weight: 700; color: var(--accent); margin-bottom: 8px;">2017</p>
                    <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">Taller Huellas de Agua</h3>
                    <p style="color: var(--muted-foreground);">Comienzo con la maestra Irma Giménez, profundizando en técnicas avanzadas.</p>
                </div>
            </div>
            <div class="timeline-item">
                <div style="text-align: right;">
                    <p style="font-size: 2rem; font-weight: 700; color: var(--accent); margin-bottom: 8px;">2018</p>
                    <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">Descubriendo el Kintsugi</h3>
                    <p style="color: var(--muted-foreground);">Me fascina la filosofía japonesa de reparar fracturas con oro.</p>
                </div>
                <div class="timeline-dot"></div>
                <div></div>
            </div>
            <div class="timeline-item">
                <div></div>
                <div class="timeline-dot"></div>
                <div>
                    <p style="font-size: 2rem; font-weight: 700; color: var(--accent); margin-bottom: 8px;">2026</p>
                    <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">El Viaje a Japón</h3>
                    <p style="color: var(--muted-foreground);">Un mes de inmersión en la cultura del kintsugi y cerámica japonesa.</p>
                </div>
            </div>
        </div>
    </div>
</section>
