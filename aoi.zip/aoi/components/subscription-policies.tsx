"use client"

import { Check } from "lucide-react"

export function SubscriptionPolicies() {
  return (
    <section className="py-20 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Easy Cancellation */}
          <div className="border-l-4 border-accent/50 pl-6 py-4">
            <h3 className="text-2xl font-medium mb-3 flex items-center gap-2">
              <Check className="w-6 h-6 text-accent" />
              Cancela cuando quieras
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              No hay contratos a largo plazo. Cancela tu suscripción en cualquier momento sin penalidades, preguntas
              incómodas ni sorpresas. Tu apoyo es voluntario y respetamos tu decisión.
            </p>
            <p className="text-xs text-accent font-medium mt-4">Sin preguntas. Sin sorpresas. Sin culpa.</p>
          </div>

          {/* Referral Program */}
          <div className="border-l-4 border-accent/50 pl-6 py-4">
            <h3 className="text-2xl font-medium mb-3 flex items-center gap-2">
              <Check className="w-6 h-6 text-accent" />
              Programa de referidos
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Invita a un amigo y ambos reciben <span className="font-medium text-accent">1 mes gratis</span>. No hay
              límite de referidos. Comparte el proyecto con quienes creas que les encantará.
            </p>
            <p className="text-xs text-accent font-medium mt-4">Comparte el amor. Gana acceso gratis.</p>
          </div>

          {/* Money-Back Guarantee */}
          <div className="border-l-4 border-accent/50 pl-6 py-4">
            <h3 className="text-2xl font-medium mb-3 flex items-center gap-2">
              <Check className="w-6 h-6 text-accent" />
              Garantía de satisfacción
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Si en los primeros 30 días no eres completamente feliz, devolvemos tu dinero sin preguntas. Tu
              satisfacción es lo primero.
            </p>
            <p className="text-xs text-accent font-medium mt-4">30 días de prueba. Reembolso total garantizado.</p>
          </div>

          {/* What's Included */}
          <div className="border-l-4 border-accent/50 pl-6 py-4">
            <h3 className="text-2xl font-medium mb-3 flex items-center gap-2">
              <Check className="w-6 h-6 text-accent" />
              Acceso inmediato
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Tu suscripción comienza inmediatamente después de confirmar. Acceso a toda la comunidad, archivos y
              contenido exclusivo desde el primer día.
            </p>
            <p className="text-xs text-accent font-medium mt-4">Sin esperas. Sin retrasos. Acceso completo ya.</p>
          </div>
        </div>

        <div className="mt-16 bg-accent/5 border border-accent/20 rounded-lg p-8">
          <h3 className="text-2xl font-medium mb-4 text-center">¿Alguna pregunta?</h3>
          <p className="text-muted-foreground text-center mb-6">
            No somos una empresa anónima. Soy Daniel, el artista. Respondo personalmente cada mensaje.
          </p>
          <div className="text-center">
            <button className="text-accent font-medium hover:underline">Contáctame directamente →</button>
          </div>
        </div>
      </div>
    </section>
  )
}
