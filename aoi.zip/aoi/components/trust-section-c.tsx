"use client"

import { useEffect, useRef, useState } from "react"
import { Award, Zap, Globe, Users } from "lucide-react"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function TrustSectionC() {
  const header = useScrollAnimation()
  const stats = useScrollAnimation()
  const credibilities = useScrollAnimation()

  const stats_data = [
    { number: "22", label: "Años de experiencia en cerámica" },
    { number: "1,200+", label: "Seguidores del proyecto" },
    { number: "2", label: "Maestros certificados" },
    { number: "3", label: "Países en su viaje artístico" },
  ]

  const credibilities_data = [
    {
      icon: Award,
      title: "Certificado en Kintsugi",
      desc: "Entrenamiento avanzado en técnicas tradicionales japonesas de reparación con oro",
    },
    {
      icon: Globe,
      title: "Herencia Binacional",
      desc: "Maestro mexicano formado por Juan Lojo Romero y Alberto Díaz de Cossío",
    },
    {
      icon: Zap,
      title: "Especialista Neurodivergente",
      desc: "Artista que canaliza el TDAH a través de la creación consciente",
    },
    {
      icon: Users,
      title: "Comunidad Verificada",
      desc: "Más de 1,200 personas siguiendo activamente este proyecto de transformación",
    },
  ]

  return (
    <section id="trust-section-c" className="py-24 px-6 bg-card overflow-hidden">
      <div className="max-w-5xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-20 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">Credibilidad</p>
          <h2 className="text-4xl md:text-5xl font-light">¿Por qué confiar en este viaje?</h2>
          <div className="flex justify-center mt-6">
            <div
              className={`h-0.5 bg-gradient-to-r from-transparent via-accent to-transparent transition-all duration-1000 delay-300 ${
                header.isVisible ? "w-32" : "w-0"
              }`}
            />
          </div>
          <p className="text-lg text-muted-foreground mt-8 max-w-2xl mx-auto">
            Años de experiencia, certificaciones internacionales y una comunidad que crece cada día
          </p>
        </div>

        <div
          ref={stats.ref}
          className={`grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-20 transition-all duration-1000 ${
            stats.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          {stats_data.map((item, index) => (
            <div
              key={index}
              className="text-center p-8 rounded-sm border border-accent/20 bg-secondary/30 transition-all duration-500 hover:border-accent/50 hover:bg-secondary/50 hover:-translate-y-1"
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <p className="text-4xl md:text-5xl font-bold text-accent mb-2">{item.number}</p>
              <p className="text-base text-muted-foreground">{item.label}</p>
            </div>
          ))}
        </div>

        <div ref={credibilities.ref} className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {credibilities_data.map((item, index) => (
            <div
              key={index}
              className={`p-6 rounded-sm border border-accent/20 bg-secondary/20 hover:border-accent/50 hover:bg-secondary/40 transition-all duration-500 hover:-translate-y-1 ${
                credibilities.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/10 mb-4">
                <item.icon className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-medium text-lg mb-2">{item.title}</h3>
              <p className="text-sm text-muted-foreground">{item.desc}</p>
            </div>
          ))}
        </div>

        <div
          ref={credibilities.ref}
          className={`bg-gradient-to-r from-accent/10 to-accent/5 border border-accent/30 rounded-lg p-8 md:p-12 transition-all duration-1000 ${
            credibilities.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
          }`}
        >
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="flex-1">
              <p className="text-2xl md:text-3xl font-light italic mb-6 text-foreground">
                "Daniel no es solo un artista, es un puente entre culturas que honra la tradición mientras crea algo
                completamente nuevo."
              </p>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <p className="font-medium text-foreground">Comunidad de seguidores</p>
                  <p className="text-sm text-muted-foreground">Verificados en Kickstarter</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
