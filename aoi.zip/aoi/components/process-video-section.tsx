export function ProcessVideoSection() {
  return (
    <section className="w-full py-20 px-4 bg-gradient-to-b from-background to-muted/30">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">El Arte Detrás de Cada Pieza</h2>
          <p className="text-lg text-muted-foreground">Descubre el proceso completo de creación de cerámica kintsugi</p>
        </div>

        <div className="w-full aspect-video bg-muted rounded-lg overflow-hidden flex items-center justify-center">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">Video: Proceso de creación de cerámica kintsugi</p>
            <p className="text-sm text-muted-foreground">Pronto disponible</p>
          </div>
        </div>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Este video muestra el viaje completo de una pieza rota hasta convertirse en una obra maestra
        </p>
      </div>
    </section>
  )
}
