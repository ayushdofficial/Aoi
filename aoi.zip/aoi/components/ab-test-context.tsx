"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"

type Variant = "a" | "b" | "c" | "d" | "f" | "g" | "h"

interface ABTestContextType {
  variant: Variant
  setVariant: (variant: Variant) => void
}

const ABTestContext = createContext<ABTestContextType | undefined>(undefined)

export function ABTestProvider({ children }: { children: React.ReactNode }) {
  const [variant, setVariantState] = useState<Variant>("b")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const urlVariant = params.get("variant") as Variant | null

    let selectedVariant: Variant = "b"

    if (urlVariant && ["a", "b", "c", "d", "f", "g", "h"].includes(urlVariant)) {
      selectedVariant = urlVariant
      localStorage.setItem("ab_variant", urlVariant)
      console.log("[v0] Variant from URL:", selectedVariant)
    } else {
      const stored = localStorage.getItem("ab_variant") as Variant | null
      if (stored && ["a", "b", "c", "d", "f", "g", "h"].includes(stored)) {
        selectedVariant = stored
        console.log("[v0] Variant from localStorage:", selectedVariant)
      } else {
        selectedVariant = "b"
        localStorage.setItem("ab_variant", selectedVariant)
        console.log("[v0] Variant defaulting to B")
      }
    }

    setVariantState(selectedVariant)

    // Log analytics event
    console.log("[v0] AB Test Variant Set:", selectedVariant)
    if (typeof window.gtag !== "undefined") {
      window.gtag("event", "ab_test_assigned", {
        variant: selectedVariant,
        timestamp: new Date().toISOString(),
      })
    }

    setMounted(true)
  }, [])

  const value: ABTestContextType = {
    variant,
    setVariant: setVariantState,
  }

  if (!mounted) {
    return null
  }

  return <ABTestContext.Provider value={value}>{children}</ABTestContext.Provider>
}

export function useABTest() {
  const context = useContext(ABTestContext)
  if (context === undefined) {
    throw new Error("useABTest must be used within ABTestProvider")
  }
  return context
}
