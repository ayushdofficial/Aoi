"use client"

import { useState } from "react"
import { PageVersionA } from "@/components/page-version-a"
import { PageVersionB } from "@/components/page-version-b"
import { PageVersionC } from "@/components/page-version-c"
import { PageVersionD } from "@/components/page-version-d"
import { PageVersionF } from "@/components/page-version-f"
import { PageVersionG } from "@/components/page-version-g"
import { PageVersionH } from "@/components/page-version-h"
import PageVersionI from "@/components/page-version-i"
import { AnimatedNavbar } from "@/components/animated-navbar"
import { Footer } from "@/components/footer"

export default function Page() {
  const [currentVersion, setCurrentVersion] = useState<string>("i")

  const versions = [
    { id: "a", label: "Versión A", subtitle: "Clásica" },
    { id: "b", label: "Versión B", subtitle: "Testimonios" },
    { id: "c", label: "Versión C", subtitle: "Timeline" },
    { id: "d", label: "Versión D", subtitle: "Personalizada" },
    { id: "f", label: "Versión F", subtitle: "Educativa" },
    { id: "g", label: "Versión G", subtitle: "Urgencia" },
    { id: "h", label: "Versión H", subtitle: "Premium" },
    { id: "i", label: "Versión I", subtitle: "Patreon" },
  ]

  const renderVersion = () => {
    switch (currentVersion) {
      case "a":
        return <PageVersionA />
      case "b":
        return <PageVersionB />
      case "c":
        return <PageVersionC />
      case "d":
        return <PageVersionD />
      case "f":
        return <PageVersionF />
      case "g":
        return <PageVersionG />
      case "h":
        return <PageVersionH />
      case "i":
      default:
        return <PageVersionI />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <AnimatedNavbar />

      <main>{renderVersion()}</main>

      <Footer />

      {/* Version Switcher */}
      <nav className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-t border-border z-50 py-3">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-center gap-2 overflow-x-auto scrollbar-hide">
            {versions.map((version) => (
              <button
                key={version.id}
                onClick={() => setCurrentVersion(version.id)}
                className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  currentVersion === version.id
                    ? "bg-accent text-accent-foreground"
                    : "bg-secondary text-secondary-foreground hover:bg-accent/10"
                }`}
              >
                <span className="block">{version.label}</span>
                <span className="block text-xs opacity-75">{version.subtitle}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>
    </div>
  )
}
