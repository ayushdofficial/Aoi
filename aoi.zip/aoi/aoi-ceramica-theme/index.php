<?php
/**
 * Main Template File
 */
get_header();
?>

<main id="main-content">
    <!-- Version A: Clásica -->
    <div id="version-a" class="version-content active" data-variant="a">
        <?php get_template_part('template-parts/version', 'a'); ?>
    </div>

    <!-- Version B: Testimonios -->
    <div id="version-b" class="version-content" data-variant="b">
        <?php get_template_part('template-parts/version', 'b'); ?>
    </div>

    <!-- Version C: Timeline -->
    <div id="version-c" class="version-content" data-variant="c">
        <?php get_template_part('template-parts/version', 'c'); ?>
    </div>

    <!-- Version D: Personalizada -->
    <div id="version-d" class="version-content" data-variant="d">
        <?php get_template_part('template-parts/version', 'd'); ?>
    </div>

    <!-- Version F: Educativa -->
    <div id="version-f" class="version-content" data-variant="f">
        <?php get_template_part('template-parts/version', 'f'); ?>
    </div>

    <!-- Version G: Urgencia -->
    <div id="version-g" class="version-content" data-variant="g">
        <?php get_template_part('template-parts/version', 'g'); ?>
    </div>

    <!-- Version H: Premium -->
    <div id="version-h" class="version-content" data-variant="h">
        <?php get_template_part('template-parts/version', 'h'); ?>
    </div>

    <!-- Version I: Patreon -->
    <div id="version-i" class="version-content" data-variant="i">
        <?php get_template_part('template-parts/version', 'i'); ?>
    </div>
</main>

<!-- Tab Navigation -->
<nav class="tab-navigation">
    <div class="tab-nav-container">
        <button class="tab-button active" data-tab="version-a">
            <span>Versión A</span>
            <span class="tab-subtitle">Clásica</span>
        </button>
        <button class="tab-button" data-tab="version-b">
            <span>Versión B</span>
            <span class="tab-subtitle">Testimonios</span>
        </button>
        <button class="tab-button" data-tab="version-c">
            <span>Versión C</span>
            <span class="tab-subtitle">Timeline</span>
        </button>
        <button class="tab-button" data-tab="version-d">
            <span>Versión D</span>
            <span class="tab-subtitle">Personalizada</span>
        </button>
        <button class="tab-button" data-tab="version-f">
            <span>Versión F</span>
            <span class="tab-subtitle">Educativa</span>
        </button>
        <button class="tab-button" data-tab="version-g">
            <span>Versión G</span>
            <span class="tab-subtitle">Urgencia</span>
        </button>
        <button class="tab-button" data-tab="version-h">
            <span>Versión H</span>
            <span class="tab-subtitle">Premium</span>
        </button>
        <button class="tab-button" data-tab="version-i">
            <span>Versión I</span>
            <span class="tab-subtitle">Patreon</span>
        </button>
    </div>
</nav>

<!-- Scroll to Top Button -->
<button class="scroll-to-top" id="scrollToTop">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M12 19V5M5 12l7-7 7 7"/>
    </svg>
</button>

<?php get_footer(); ?>
