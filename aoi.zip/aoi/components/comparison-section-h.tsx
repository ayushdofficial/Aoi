"use client"

import { Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function ComparisonSectionH() {
  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-block bg-accent/10 border border-accent/30 rounded-full px-6 py-2 mb-6">
            <span className="text-sm uppercase tracking-widest text-accent font-medium">Comparison</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Why choose this project?</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            It's not just ceramics, it's a complete cultural transformation experience
          </p>
        </div>

        {/* Comparison Table */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {/* Other Projects */}
          <div className="bg-muted/50 rounded-2xl p-8 border border-border">
            <h3 className="text-2xl font-bold mb-6 text-center">Other Projects</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <span className="text-muted-foreground">No official certification</span>
              </li>
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <span className="text-muted-foreground">Limited content</span>
              </li>
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <span className="text-muted-foreground">No community access</span>
              </li>
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <span className="text-muted-foreground">Mass-produced pieces</span>
              </li>
            </ul>
          </div>

          {/* This Project - Highlighted */}
          <div className="bg-accent rounded-2xl p-8 border-2 border-accent shadow-2xl shadow-accent/20 md:scale-105 relative">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-background px-4 py-1 rounded-full border border-accent">
              <span className="text-sm font-semibold text-accent">RECOMMENDED</span>
            </div>
            <h3 className="text-2xl font-bold mb-6 text-center text-accent-foreground">This Project</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-accent-foreground mt-0.5 flex-shrink-0" />
                <span className="text-accent-foreground font-medium">Official Japanese certification</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-accent-foreground mt-0.5 flex-shrink-0" />
                <span className="text-accent-foreground font-medium">Weekly live streams</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-accent-foreground mt-0.5 flex-shrink-0" />
                <span className="text-accent-foreground font-medium">Exclusive Discord community</span>
              </li>
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-accent-foreground mt-0.5 flex-shrink-0" />
                <span className="text-accent-foreground font-medium">100% handmade</span>
              </li>
            </ul>
            <Button className="w-full mt-8 bg-background text-accent hover:bg-background/90 font-semibold">
              Support now
            </Button>
          </div>

          {/* Traditional Courses */}
          <div className="bg-muted/50 rounded-2xl p-8 border border-border">
            <h3 className="text-2xl font-bold mb-6 text-center">Traditional Courses</h3>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Check className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                <span>Certification available</span>
              </li>
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <span className="text-muted-foreground">No journey tracking</span>
              </li>
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <span className="text-muted-foreground">No exclusive rewards</span>
              </li>
              <li className="flex items-start gap-3">
                <X className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <span className="text-muted-foreground">Very high cost</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="text-center">
          <p className="text-muted-foreground mb-6">Join over 1,200 people who already trust this project</p>
          <Button size="lg" className="h-14 px-10 text-lg bg-accent hover:bg-accent/90">
            View support levels
          </Button>
        </div>
      </div>
    </section>
  )
}
