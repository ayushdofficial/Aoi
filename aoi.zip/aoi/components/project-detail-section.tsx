"use client"

import { useEffect, useRef, useState } from "react"
import { Flame, Hand, Mountain, Sparkles } from "lucide-react"
import { SectionCTA } from "@/components/section-cta"

function useScrollAnimation() {
  const ref = useRef<HTMLDivElement>(null)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 },
    )

    if (ref.current) {
      observer.observe(ref.current)
    }

    return () => observer.disconnect()
  }, [])

  return { ref, isVisible }
}

export function ProjectDetailSection() {
  const header = useScrollAnimation()
  const materials = useScrollAnimation()
  const techniques = useScrollAnimation()
  const process = useScrollAnimation()

  return (
    <section id="project-detail" className="py-24 px-6 bg-secondary/30 overflow-hidden">
      <div className="max-w-5xl mx-auto">
        <div
          ref={header.ref}
          className={`text-center mb-16 transition-all duration-1000 ${
            header.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">El Proyecto en Detalle</p>
          <h2 className="text-4xl md:text-6xl font-light mb-6">Del barro al oro</h2>
          <div className="flex justify-center mb-6">
            <div
              className={`h-0.5 bg-gradient-to-r from-transparent via-accent to-transparent transition-all duration-1000 delay-300 ${
                header.isVisible ? "w-32" : "w-0"
              }`}
            />
          </div>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Un viaje profundo hacia los materiales, técnicas y procesos que dan vida a cada pieza.
          </p>
        </div>

        {/* Materials Section */}
        <div ref={materials.ref} className="mb-20">
          <div
            className={`flex items-center gap-3 mb-8 transition-all duration-700 ${
              materials.isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"
            }`}
          >
            <Mountain className="w-8 h-8 text-accent" />
            <h3 className="text-3xl font-light">Materiales</h3>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            <div
              className={`transition-all duration-700 delay-100 ${
                materials.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              <div className="bg-card border border-border/50 rounded-sm p-6 h-full hover:border-accent/30 transition-colors">
                <h4 className="text-xl font-medium mb-3">Arcillas naturales</h4>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Trabajo principalmente con gres de alta temperatura y porcelana, arcillas que permiten tanto la
                  fortaleza estructural como la delicadeza estética. Cada tipo de arcilla tiene su propia personalidad y
                  responde de manera única al fuego.
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-accent">•</span>
                    <span>Gres: resistencia y tonos terrosos</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-accent">•</span>
                    <span>Porcelana: elegancia y translucidez</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-accent">•</span>
                    <span>Terracota: calidez y tradición</span>
                  </li>
                </ul>
              </div>
            </div>

            <div
              className={`transition-all duration-700 delay-200 ${
                materials.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              <div className="bg-card border border-border/50 rounded-sm p-6 h-full hover:border-accent/30 transition-colors">
                <h4 className="text-xl font-medium mb-3">Oro y laca urushi</h4>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Para el kintsugi, utilizo laca urushi auténtica y polvo de oro de 24 quilates. Esta combinación
                  tradicional japonesa no solo repara: transforma las fracturas en vetas luminosas que cuentan una
                  historia.
                </p>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-accent">•</span>
                    <span>Laca urushi: adhesivo natural japonés</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-accent">•</span>
                    <span>Oro 24k: belleza que perdura</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-accent">•</span>
                    <span>Plata y cobre: alternativas expresivas</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Techniques Section */}
        <div ref={techniques.ref} className="mb-20">
          <div
            className={`flex items-center gap-3 mb-8 transition-all duration-700 ${
              techniques.isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"
            }`}
          >
            <Hand className="w-8 h-8 text-accent" />
            <h3 className="text-3xl font-light">Técnicas</h3>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                title: "Modelado a mano",
                desc: "Cada pieza nace de las manos, sin moldes. El torno, el pellizco y el acordonado son mis principales herramientas para dar forma a la arcilla.",
              },
              {
                title: "Kintsugi tradicional",
                desc: "La técnica japonesa de reparar con oro. Un proceso meditativo que requiere paciencia, precisión y respeto por la imperfección.",
              },
              {
                title: "Esmaltado artesanal",
                desc: "Desarrollo mis propias recetas de esmaltes, experimentando con óxidos y materiales naturales para lograr acabados únicos.",
              },
            ].map((item, index) => (
              <div
                key={index}
                className={`bg-card border border-border/50 rounded-sm p-6 hover:border-accent/30 transition-all duration-700 ${
                  techniques.isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <h4 className="text-lg font-medium mb-3">{item.title}</h4>
                <p className="text-muted-foreground leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Process Section */}
        <div ref={process.ref}>
          <div
            className={`flex items-center gap-3 mb-8 transition-all duration-700 ${
              process.isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"
            }`}
          >
            <Flame className="w-8 h-8 text-accent" />
            <h3 className="text-3xl font-light">El Proceso</h3>
          </div>

          <div className="grid md:grid-cols-2 gap-8 items-center mb-12">
            <div
              className={`order-2 md:order-1 space-y-6 transition-all duration-1000 ${
                process.isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"
              }`}
            >
              <div className="space-y-4">
                {[
                  {
                    num: "01",
                    title: "Preparación",
                    desc: "La arcilla se amasa y se prepara, eliminando burbujas de aire. Un proceso meditativo que conecta con el material.",
                  },
                  {
                    num: "02",
                    title: "Modelado",
                    desc: "Dar forma con las manos o el torno. Cada movimiento es intencional, cada curva tiene un propósito.",
                  },
                  {
                    num: "03",
                    title: "Secado",
                    desc: "Paciencia. La pieza debe secar lentamente para evitar grietas, cubierta con plástico que regula la humedad.",
                  },
                  {
                    num: "04",
                    title: "Primera quema",
                    desc: "Bizcocho a 980°C. La arcilla se transforma en cerámica, adquiriendo resistencia permanente.",
                  },
                  {
                    num: "05",
                    title: "Esmaltado",
                    desc: "Aplicación de esmaltes. Cada capa es un acto de fe: el fuego revelará los colores verdaderos.",
                  },
                  {
                    num: "06",
                    title: "Segunda quema",
                    desc: "Alta temperatura (1220-1280°C). El esmalte se funde, vitrifica y se une a la pieza para siempre.",
                  },
                  {
                    num: "07",
                    title: "Kintsugi (opcional)",
                    desc: "Si la pieza se quiebra, renace con oro. Las fracturas se convierten en su mayor belleza.",
                  },
                ].map((step, index) => (
                  <div
                    key={index}
                    className={`flex gap-4 transition-all duration-500 ${
                      process.isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
                    }`}
                    style={{ transitionDelay: `${index * 100}ms` }}
                  >
                    <span className="text-3xl font-bold text-accent/30">{step.num}</span>
                    <div>
                      <h5 className="font-medium mb-1">{step.title}</h5>
                      <p className="text-sm text-muted-foreground">{step.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div
              className={`order-1 md:order-2 relative transition-all duration-1000 delay-200 ${
                process.isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"
              }`}
            >
              <div className="aspect-[3/4] relative rounded-sm overflow-hidden">
                <img
                  src="/hands-shaping-clay-on-pottery-wheel-close-up-artis.jpg"
                  alt="Proceso de creación cerámica"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/40 to-transparent" />
              </div>
              <div className="absolute -bottom-6 -left-6 w-32 h-32 border-2 border-accent rounded-sm" />
            </div>
          </div>

          <div
            className={`bg-accent/5 border border-accent/20 rounded-sm p-8 transition-all duration-1000 ${
              process.isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
            }`}
          >
            <div className="flex items-start gap-4">
              <Sparkles className="w-6 h-6 text-accent shrink-0 mt-1" />
              <div>
                <h4 className="text-xl font-medium mb-2">Cada pieza es única</h4>
                <p className="text-muted-foreground leading-relaxed">
                  El fuego, la arcilla y el tiempo crean variaciones imposibles de replicar. Lo que algunos llaman
                  "imperfecciones" son, en realidad, la firma personal de cada obra. En esto radica la belleza del
                  wabi-sabi: aceptar y celebrar la transitoriedad y la imperfección.
                </p>
              </div>
            </div>
          </div>
        </div>

        <SectionCTA text="Apoya este proyecto" />
      </div>
    </section>
  )
}
