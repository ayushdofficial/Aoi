"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail, Check } from "lucide-react"

export function EmailCapture() {
  const [email, setEmail] = useState("")
  const [name, setName] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (email && name) {
      setIsLoading(true)
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setIsSubmitted(true)
      setIsLoading(false)
    }
  }

  return (
    <section className="py-24 px-6 bg-primary text-primary-foreground relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-accent/10 rounded-full blur-3xl" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />

      <div className="max-w-2xl mx-auto relative z-10">
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-accent/20 mb-8">
            <Mail className="w-8 h-8 text-accent" />
          </div>

          <h2 className="text-3xl md:text-4xl font-light mb-6">Be part of this journey</h2>

          <p className="text-lg text-primary-foreground/80 mb-4">By joining, you will be able to:</p>

          <ul className="text-left max-w-md mx-auto space-y-3 mb-10">
            {[
              "Participate in project surveys",
              "Access exclusive live streams",
              "Accompany me as each piece comes to life",
              "Receive early access to new collections",
            ].map((item, index) => (
              <li key={index} className="flex items-start gap-3">
                <Check className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                <span className="text-primary-foreground/90">{item}</span>
              </li>
            ))}
          </ul>

          {!isSubmitted ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="text"
                placeholder="Your name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-14 px-6 text-lg bg-primary-foreground/10 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/50 focus:border-accent"
                required
              />
              <Input
                type="email"
                placeholder="Your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-14 px-6 text-lg bg-primary-foreground/10 border-primary-foreground/20 text-primary-foreground placeholder:text-primary-foreground/50 focus:border-accent"
                required
              />
              <Button
                type="submit"
                disabled={isLoading}
                className="w-full h-14 text-lg bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                {isLoading ? "Joining..." : "I want to be part of the journey"}
              </Button>
            </form>
          ) : (
            <div className="bg-accent/20 border border-accent/30 rounded-lg p-8">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-accent/30 mb-4">
                <Check className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-2xl font-medium mb-2">Welcome to the journey, {name}!</h3>
              <p className="text-primary-foreground/80">
                Check your email to confirm your subscription and receive your first letter from the workshop.
              </p>
            </div>
          )}

          <p className="text-sm text-primary-foreground/60 mt-6">
            No algorithms or filters here, just you, me, and art.
          </p>
        </div>
      </div>
    </section>
  )
}
