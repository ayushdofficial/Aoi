"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Heart, Sparkles, Users, Shield, Star, Play, ArrowRight } from "lucide-react"

interface SubscriptionStep1Props {
  onNext: (email: string) => void
}

export function SubscriptionStep1VersionG({ onNext }: SubscriptionStep1Props) {
  const [email, setEmail] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !email.includes("@")) {
      setError("Por favor ingresa un email válido")
      return
    }

    onNext(email)
  }

  return (
    <div className="bg-white min-h-screen">
      <section className="relative overflow-hidden bg-white">
        <div className="max-w-7xl mx-auto px-6 py-20 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="inline-block">
                <div className="bg-coral-100 text-coral-600 px-4 py-2 rounded-full text-sm font-semibold">
                  Solo 47 mecenas activos
                </div>
              </div>

              <h1 className="text-6xl lg:text-7xl font-bold text-gray-900 leading-[1.1] text-balance">
                Tu apoyo hace posible
                <span className="block text-coral-500 mt-2">el arte neurodivergente</span>
              </h1>

              <p className="text-xl text-gray-600 leading-relaxed max-w-xl">
                Sé parte del viaje de un artista que ve el mundo diferente y transforma la cerámica mexicana con la
                filosofía del kintsugi japonés.
              </p>

              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                <Button
                  size="lg"
                  onClick={() => {
                    document.querySelector("[data-email-section]")?.scrollIntoView({ behavior: "smooth" })
                  }}
                  className="bg-coral-500 hover:bg-coral-600 text-white font-semibold h-14 px-8 text-lg rounded-full shadow-lg hover:shadow-xl transition-all"
                >
                  Quiero apoyar a Daniel
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <button className="flex items-center gap-3 text-gray-700 hover:text-gray-900 font-medium transition-colors group">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center group-hover:bg-gray-200 transition-colors">
                    <Play className="w-5 h-5" />
                  </div>
                  <span>Ver su historia</span>
                </button>
              </div>

              <div className="flex gap-8 pt-8 border-t border-gray-200">
                <div>
                  <div className="text-3xl font-bold text-gray-900">15+</div>
                  <div className="text-sm text-gray-600">años creando</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-gray-900">200+</div>
                  <div className="text-sm text-gray-600">piezas únicas</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-gray-900">47</div>
                  <div className="text-sm text-gray-600">suscriptores</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-square rounded-3xl overflow-hidden shadow-2xl">
                <img
                  src="/beautiful-ceramic-pottery-art-kintsugi-gold.jpg"
                  alt="Cerámica Kintsugi de Daniel"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-6 max-w-xs animate-float">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-coral-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-2xl">🎨</span>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Daniel</div>
                    <div className="text-sm text-gray-600 mb-2">Ceramista neurodivergente</div>
                    <p className="text-sm text-gray-700 italic">
                      "La neurodivergencia no es una limitación. Es mi superpoder creativo."
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* </CHANGE> */}

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-6">
              <div className="inline-block bg-coral-100 text-coral-600 px-4 py-2 rounded-full text-sm font-semibold">
                Hola, soy Daniel
              </div>
              <h2 className="text-5xl font-bold text-gray-900 leading-tight">
                De México a Japón: un viaje de transformación
              </h2>
              <div className="space-y-4 text-lg text-gray-700 leading-relaxed">
                <p>
                  Artista ceramista de <span className="font-semibold text-gray-900">México</span>, neurodivergente y
                  creador de piezas únicas que fusionan la filosofía del kintsugi japonés con la tradición cerámica
                  mexicana.
                </p>
                <p>
                  Como artista neurodivergente, el mundo del arte tradicional no siempre ha sido amable conmigo. Las
                  galerías pueden ser abrumadoras. Las negociaciones, agotadoras. Pero{" "}
                  <span className="font-semibold text-gray-900">
                    tu suscripción me permite enfocarme en lo que sé hacer: crear
                  </span>
                  .
                </p>
                <p>
                  Cada mes que me apoyas, es un mes más donde puedo dedicarme al torno, experimentar con nuevas técnicas
                  y preparar mi viaje a Japón para aprender el kintsugi de los maestros.
                </p>
              </div>

              <blockquote className="border-l-4 border-coral-500 pl-6 py-2">
                <p className="text-xl italic text-gray-700 font-medium">
                  "La neurodivergencia no es una limitación. Es la lente única que me permite transformar el silencio en
                  oro."
                </p>
                <footer className="text-sm text-gray-600 mt-2">— Daniel</footer>
              </blockquote>
            </div>

            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="aspect-square rounded-2xl overflow-hidden shadow-lg">
                    <img
                      src="/placeholder.svg?height=300&width=300"
                      alt="Taller de Daniel"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="aspect-square rounded-2xl overflow-hidden shadow-lg">
                    <img
                      src="/placeholder.svg?height=300&width=300"
                      alt="Proceso de kintsugi"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
                <div className="space-y-4 pt-8">
                  <div className="aspect-square rounded-2xl overflow-hidden shadow-lg">
                    <img
                      src="/placeholder.svg?height=300&width=300"
                      alt="Cerámica mexicana"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="aspect-square rounded-2xl overflow-hidden shadow-lg">
                    <img
                      src="/placeholder.svg?height=300&width=300"
                      alt="Técnicas japonesas"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* </CHANGE> */}

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-gray-900 mb-6">Lo que recibes al apoyar</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              No es solo una transacción. Es un acto de fe en el arte neurodivergente y en un artista que necesita de tu
              apoyo para seguir creando.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8 hover:border-coral-300 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-coral-100 rounded-2xl flex items-center justify-center mb-6">
                <Sparkles className="w-7 h-7 text-coral-500" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Contenido Exclusivo</h3>
              <p className="text-gray-600 leading-relaxed">
                Videos del proceso creativo, tutoriales y acceso a mi diario de artista. Ve cómo cada pieza cobra vida.
              </p>
            </div>

            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8 hover:border-coral-300 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-coral-100 rounded-2xl flex items-center justify-center mb-6">
                <Users className="w-7 h-7 text-coral-500" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Comunidad Cercana</h3>
              <p className="text-gray-600 leading-relaxed">
                Únete a otros mecenas que creen en el arte diferente y la neurodivergencia. Conexión real, sin
                intermediarios.
              </p>
            </div>

            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8 hover:border-coral-300 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-coral-100 rounded-2xl flex items-center justify-center mb-6">
                <Star className="w-7 h-7 text-coral-500" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Prioridad en Piezas</h3>
              <p className="text-gray-600 leading-relaxed">
                Acceso anticipado a nuevas creaciones y descuentos exclusivos. Tus manos serán las primeras en tocarlas.
              </p>
            </div>
          </div>
        </div>
      </section>
      {/* </CHANGE> */}

      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Lo que dicen los mecenas</h2>
            <p className="text-xl text-gray-600">Creatividad impulsada por la comunidad</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                  <span className="text-xl">👤</span>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">María G.</div>
                  <div className="text-sm text-gray-600">Mecenas desde 2024</div>
                </div>
              </div>
              <p className="text-gray-700 leading-relaxed">
                "Apoyar a Daniel no es caridad. Es invertir en una visión del mundo que solo un artista neurodivergente
                puede ofrecer."
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                  <span className="text-xl">👤</span>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Carlos M.</div>
                  <div className="text-sm text-gray-600">Mecenas desde 2023</div>
                </div>
              </div>
              <p className="text-gray-700 leading-relaxed">
                "Ver el proceso detrás de cada pieza es mágico. Daniel transforma la arcilla en poesía visual."
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
                  <span className="text-xl">👤</span>
                </div>
                <div>
                  <div className="font-semibold text-gray-900">Ana R.</div>
                  <div className="text-sm text-gray-600">Mecenas desde 2024</div>
                </div>
              </div>
              <p className="text-gray-700 leading-relaxed">
                "Su viaje a Japón será transformador. Me emociona ser parte de algo tan especial y ver arte auténtico."
              </p>
            </div>
          </div>
        </div>
      </section>
      {/* </CHANGE> */}

      <section className="py-24 bg-gradient-to-br from-coral-500 to-coral-600" data-email-section>
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="mb-8">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6 animate-float">
              <Heart className="w-10 h-10 text-white" />
            </div>
            <h2 className="text-5xl font-bold text-white mb-6 text-balance">Comienza a apoyar hoy</h2>
            <p className="text-xl text-coral-50 max-w-2xl mx-auto mb-8">
              Desde $99 MXN/mes puedes hacer la diferencia. Únete a 47 mecenas que están haciendo posible el arte
              neurodivergente y el viaje de Daniel a Japón.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="max-w-md mx-auto">
            <div className="bg-white rounded-2xl p-2 shadow-2xl">
              <div className="flex flex-col sm:flex-row gap-2">
                <Input
                  type="email"
                  placeholder="tu@email.com"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value)
                    setError("")
                  }}
                  className="flex-1 border-0 h-14 text-lg bg-transparent focus-visible:ring-0"
                  autoComplete="email"
                />
                <Button
                  type="submit"
                  className="bg-gray-900 hover:bg-gray-800 text-white font-semibold h-14 px-8 text-lg rounded-xl whitespace-nowrap"
                >
                  Ver Planes
                </Button>
              </div>
              {error && <p className="text-red-500 text-sm mt-2 text-left px-2">{error}</p>}
            </div>
          </form>

          <p className="text-coral-50 text-sm mt-6">
            Ya tienes cuenta?{" "}
            <button className="underline font-medium text-white hover:text-coral-50 transition-colors">
              Inicia sesión
            </button>
          </p>

          <div className="flex items-center justify-center gap-2 mt-8">
            <Shield className="w-5 h-5 text-coral-100" />
            <span className="text-sm text-coral-50">Cancela cuando quieras • Tu email está seguro</span>
          </div>
        </div>
      </section>
      {/* </CHANGE> */}

      <section className="py-16 bg-white border-t border-gray-200">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-wrap justify-center items-center gap-12 text-gray-600">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">15+</div>
              <div className="text-sm">años creando</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">200+</div>
              <div className="text-sm">piezas únicas</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">47</div>
              <div className="text-sm">mecenas activos</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">100%</div>
              <div className="text-sm">transparente</div>
            </div>
          </div>
        </div>
      </section>
      {/* </CHANGE> */}
    </div>
  )
}
