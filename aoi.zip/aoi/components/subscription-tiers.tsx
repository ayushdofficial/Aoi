"use client"
import { Button } from "@/components/ui/button"
import type React from "react"

import { Check, Users, Star, Heart, Vote, BookOpen, ShoppingBag, Plane, MessageCircle } from "lucide-react"
import { useState } from "react"

interface Tier {
  name: string
  price: number
  period: string
  description: string
  voteWeight: number
  features: string[]
  icon: React.ReactNode
  highlighted?: boolean
  cta: string
  discount?: number
}

const tiers: Tier[] = [
  {
    name: "Semilla",
    price: 1,
    period: "/mes",
    description: "Tu primer paso para apoyar el arte neurodivergente",
    voteWeight: 1,
    features: [
      "Acceso al grupo exclusivo de Discord",
      "Actualización mensual de progresos",
      "Fotos exclusivas del proceso creativo",
      "Participación en votaciones (1 voto)",
      "5% descuento en tienda de piezas",
    ],
    icon: <Heart className="w-6 h-6" />,
    cta: "Comenzar",
    discount: 5,
  },
  {
    name: "Brote",
    price: 5,
    period: "/mes",
    description: "Conexión más cercana con el proceso creativo",
    voteWeight: 5,
    features: [
      "Todo del plan Semilla",
      "Transmisiones exclusivas en vivo",
      "Sesiones de preguntas y respuestas",
      "Guía digital de técnicas (PDF)",
      "Votaciones con peso x5",
      "10% descuento en tienda de piezas",
    ],
    icon: <Users className="w-6 h-6" />,
    cta: "Unirse",
    discount: 10,
  },
  {
    name: "Florecimiento",
    price: 10,
    period: "/mes",
    description: "Acceso completo a la comunidad y contenido",
    voteWeight: 10,
    highlighted: true,
    features: [
      "Todo del plan Brote",
      "Biblioteca digital de recetas y técnicas",
      "Acceso anticipado: Viaje a Japón",
      "Votar lugares a visitar en Japón",
      "Votar qué piezas de cerámica crear",
      "Votaciones con peso x10",
      "15% descuento en tienda de piezas",
    ],
    icon: <Star className="w-6 h-6" />,
    cta: "Suscribirme",
    discount: 15,
  },
  {
    name: "Raíces",
    price: 15,
    period: "/mes",
    description: "El nivel más alto de apoyo y exclusividad",
    voteWeight: 15,
    features: [
      "Todo del plan Florecimiento",
      "Transmisiones exclusivas desde Japón",
      "Preguntas privilegiadas en transmisiones",
      "Acceso VIP a contenido del viaje",
      "Influencia directa en decisiones del proyecto",
      "Votaciones con peso x15",
      "20% descuento en tienda de piezas",
      "Mención especial en redes sociales",
    ],
    icon: <Plane className="w-6 h-6" />,
    cta: "Ser Mecenas VIP",
    discount: 20,
  },
]

export function SubscriptionTiers() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "annual">("monthly")

  return (
    <section data-tiers-section className="py-24 px-6 bg-secondary/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">Planes de Suscripción Mensual</p>
          <h2 className="text-4xl md:text-6xl font-light mb-6">
            Elige cómo quieres
            <span className="block text-accent">apoyar y participar</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Cada plan te da acceso a recompensas mensuales, contacto directo con Daniel, y un sistema de votos donde tu
            voz importa
          </p>

          <div className="bg-card/80 border border-accent/20 rounded-xl p-6 max-w-xl mx-auto mb-12">
            <div className="flex items-center justify-center gap-2 mb-3">
              <Vote className="w-5 h-5 text-accent" />
              <h3 className="font-medium text-lg">Sistema de Votos</h3>
            </div>
            <p className="text-sm text-muted-foreground">
              Tu nivel de apoyo determina el peso de tu voto. Si aportas $1 USD/mes, tu voto vale 1. Si aportas $15
              USD/mes, tu voto vale 15. Así decides qué piezas crear, qué lugares visitar en Japón, y más.
            </p>
          </div>

          {/* Billing cycle toggle */}
          <div className="flex justify-center gap-4 mb-12">
            <button
              onClick={() => setBillingCycle("monthly")}
              className={`px-6 py-2 rounded-lg transition-all ${
                billingCycle === "monthly"
                  ? "bg-accent text-accent-foreground"
                  : "bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              Mensual
            </button>
            <button
              onClick={() => setBillingCycle("annual")}
              className={`px-6 py-2 rounded-lg transition-all relative ${
                billingCycle === "annual"
                  ? "bg-accent text-accent-foreground"
                  : "bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              Anual
              <span className="absolute -top-8 left-1/2 -translate-x-1/2 bg-accent/20 text-accent text-xs px-2 py-1 rounded">
                Ahorra 20%
              </span>
            </button>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tiers.map((tier, index) => (
            <div
              key={index}
              className={`relative rounded-lg border transition-all duration-300 hover:shadow-xl hover:shadow-accent/10 ${
                tier.highlighted
                  ? "border-accent/40 bg-card/50 backdrop-blur shadow-lg shadow-accent/5 scale-105 z-10"
                  : "border-border/50 bg-card hover:-translate-y-1"
              }`}
            >
              {tier.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-accent text-accent-foreground px-4 py-1 rounded-full text-sm font-medium whitespace-nowrap">
                  Más Popular
                </div>
              )}

              <div className="p-6">
                <div className="flex items-center gap-3 mb-2">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${tier.highlighted ? "bg-accent/20 text-accent" : "bg-accent/10 text-accent/60"}`}
                  >
                    {tier.icon}
                  </div>
                  <h3 className="text-xl font-medium">{tier.name}</h3>
                </div>

                <p className="text-muted-foreground text-sm mb-4">{tier.description}</p>

                <div className="mb-4">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold text-accent">${tier.price}</span>
                    <span className="text-muted-foreground text-sm">USD{tier.period}</span>
                  </div>
                  {billingCycle === "annual" && (
                    <p className="text-sm text-accent/60 mt-1">${Math.round(tier.price * 12 * 0.8)} USD/año</p>
                  )}
                </div>

                <div className="flex items-center gap-2 mb-4 p-2 bg-accent/10 rounded-lg">
                  <Vote className="w-4 h-4 text-accent" />
                  <span className="text-sm font-medium">
                    Tu voto vale: <span className="text-accent">x{tier.voteWeight}</span>
                  </span>
                </div>

                <div className="flex items-center gap-2 mb-6 p-2 bg-primary/10 rounded-lg">
                  <ShoppingBag className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">
                    Descuento tienda: <span className="text-primary">{tier.discount}%</span>
                  </span>
                </div>

                <Button
                  className={`w-full h-11 mb-6 transition-all ${
                    tier.highlighted
                      ? "bg-accent hover:bg-accent/90 text-accent-foreground"
                      : "bg-primary hover:bg-primary/90"
                  }`}
                >
                  {tier.cta}
                </Button>

                <div className="space-y-3">
                  {tier.features.map((feature, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                      <span className="text-xs leading-relaxed">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20 grid md:grid-cols-3 gap-8">
          <div className="text-center p-6 bg-card/50 rounded-xl border border-border/50">
            <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageCircle className="w-6 h-6 text-accent" />
            </div>
            <h3 className="font-medium mb-2">Comunidad Discord Exclusiva</h3>
            <p className="text-sm text-muted-foreground">
              Conecta directamente conmigo y otros patrocinadores. Comparte ideas, recibe actualizaciones en tiempo
              real.
            </p>
          </div>
          <div className="text-center p-6 bg-card/50 rounded-xl border border-border/50">
            <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Plane className="w-6 h-6 text-accent" />
            </div>
            <h3 className="font-medium mb-2">Viaje a Japón</h3>
            <p className="text-sm text-muted-foreground">
              Vota qué lugares visitar, qué talleres conocer, y disfruta de transmisiones en vivo desde Japón.
            </p>
          </div>
          <div className="text-center p-6 bg-card/50 rounded-xl border border-border/50">
            <div className="w-12 h-12 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-6 h-6 text-accent" />
            </div>
            <h3 className="font-medium mb-2">Biblioteca Digital</h3>
            <p className="text-sm text-muted-foreground">
              Accede a guías PDF, recetas de esmaltes, técnicas de formado y más contenido educativo exclusivo.
            </p>
          </div>
        </div>

        <div className="mt-16 bg-card/50 border border-border/50 rounded-lg p-8 text-center">
          <p className="text-muted-foreground mb-4">¿Tienes dudas sobre qué plan es mejor para ti?</p>
          <Button variant="outline" className="border-accent/30 hover:border-accent bg-transparent">
            Escríbeme por Discord
          </Button>
        </div>
      </div>
    </section>
  )
}
