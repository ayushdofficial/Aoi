"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ProcessVideoSection } from "@/components/process-video-section"
import { ProcessStepsSection } from "@/components/process-steps-section"
import { SubscriberOnboardingSection } from "@/components/subscriber-onboarding-section"
import { SubscriptionTiers } from "@/components/subscription-tiers"
import { SubscriptionTestimonials } from "@/components/subscription-testimonials"
import { SubscriptionComparison } from "@/components/subscription-comparison"
import { SubscriptionPolicies } from "@/components/subscription-policies"
import { SubscriptionFAQDynamic } from "@/components/subscription-faq-dynamic"
import { Heart, Shield } from "lucide-react"
import type React from "react"

export function PageVersionF() {
  const [step, setStep] = useState(1)
  const [email, setEmail] = useState("")
  const [emailError, setEmailError] = useState("")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    window.scrollTo(0, 0)
  }, [])

  if (!mounted) return null

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!email || !email.includes("@")) {
      setEmailError("Please enter a valid email")
      return
    }

    setStep(2)
    window.scrollTo(0, 0)
  }

  const handleBackToStep1 = () => {
    setStep(1)
    window.scrollTo(0, 0)
  }

  return (
    <div className="w-full min-h-screen bg-background">
      {step === 1 ? (
        <>
          {/* Hero Section */}
          <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
            <div
              className="absolute inset-0 z-0"
              style={{
                backgroundImage: "url('/beautiful-ceramic-pottery-art-kintsugi-gold.jpg')",
                backgroundSize: "cover",
                backgroundPosition: "center",
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/75 via-black/60 to-black/80 z-10" />

            <div className="relative z-20 max-w-3xl mx-auto text-center px-6 py-20">
              <div className="mb-8 text-left bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6 max-w-xl mx-auto">
                <p className="text-sm text-accent uppercase tracking-wider font-medium mb-2">Hi, I'm</p>
                <h2 className="text-3xl md:text-4xl font-light text-white mb-3">Daniel</h2>
                <p className="text-lg text-gray-200 leading-relaxed">
                  Ceramic artist from <span className="text-accent font-medium">Mexico</span>, neurodivergent and
                  creator of unique pieces that fuse Japanese kintsugi philosophy with Mexican ceramic tradition.
                  Through my art, I transform imperfection into beauty.
                </p>
              </div>

              <div className="inline-flex items-center gap-2 bg-accent/20 backdrop-blur-sm border border-accent/30 rounded-full px-4 py-2 mb-8">
                <Heart className="w-4 h-4 text-accent" />
                <span className="text-sm text-accent font-medium">Only 47 active patrons</span>
              </div>

              <h1 className="text-5xl md:text-7xl font-light mb-6 text-white text-balance leading-tight">
                Discover the art behind each piece
              </h1>

              <p className="text-xl md:text-2xl text-gray-200 mb-6 font-light leading-relaxed max-w-2xl mx-auto">
                Understand the creative process of a neurodivergent artist and support the fusion of Mexican ceramic
                tradition with Japanese kintsugi.
              </p>

              <Button
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground font-medium h-14 px-8 text-lg"
                onClick={() => {
                  document.querySelector("[data-video-section]")?.scrollIntoView({ behavior: "smooth" })
                }}
              >
                See the Process
                <Heart className="ml-2 w-5 h-5" />
              </Button>
            </div>

            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 animate-bounce">
              <div className="w-6 h-10 border-2 border-white/30 rounded-full flex items-start justify-center p-2">
                <div className="w-1 h-2 bg-white/50 rounded-full" />
              </div>
            </div>
          </section>

          {/* Video Section */}
          <div data-video-section>
            <ProcessVideoSection />
          </div>

          {/* Process Steps */}
          <ProcessStepsSection />

          {/* Subscriber Onboarding */}
          <SubscriberOnboardingSection />

          {/* Email Capture */}
          <section className="py-20 px-6 bg-secondary/50">
            <div className="max-w-3xl mx-auto">
              <div className="mb-12 text-center">
                <p className="text-base uppercase tracking-[0.2em] text-accent mb-4">Ready to support</p>
                <h2 className="text-4xl md:text-5xl font-light mb-6 text-balance">Now that you know the process</h2>
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                  Select your support level and join the community of patrons who believe in neurodivergent art.
                </p>
              </div>

              <div className="bg-gradient-to-br from-accent/15 to-accent/5 rounded-2xl p-8 border border-accent/20">
                <div className="flex items-center justify-center gap-2 mb-4">
                  <Shield className="w-5 h-5 text-accent" />
                  <span className="text-sm text-accent font-medium">Cancel anytime</span>
                </div>

                <h3 className="text-2xl md:text-3xl font-light mb-2 text-center">Enter your email to continue</h3>
                <p className="text-muted-foreground text-center mb-6">
                  Starting at $1 USD/month you can make a difference
                </p>

                <form onSubmit={handleEmailSubmit} className="space-y-4 max-w-md mx-auto">
                  <div>
                    <Input
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value)
                        setEmailError("")
                      }}
                      className="bg-background border-accent/30 h-14 text-lg text-center"
                      autoComplete="email"
                    />
                    {emailError && <p className="text-red-500 text-sm mt-2 text-center">{emailError}</p>}
                  </div>

                  <Button
                    type="submit"
                    className="w-full h-14 bg-accent hover:bg-accent/90 text-accent-foreground font-medium text-lg"
                  >
                    View Subscription Plans
                  </Button>

                  <p className="text-xs text-muted-foreground text-center">
                    Your email is secure. We don't share data with third parties.
                  </p>
                </form>
              </div>
            </div>
          </section>
        </>
      ) : (
        <>
          {/* Step 2: Subscription Page */}
          <div className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-accent/10 py-4 px-6">
            <div className="max-w-6xl mx-auto flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={handleBackToStep1}
                className="text-muted-foreground hover:text-foreground"
              >
                ← Back
              </Button>
              <p className="text-sm text-muted-foreground">Confirmed: {email}</p>
            </div>
          </div>

          <SubscriptionTestimonials />

          <section className="py-20 px-6">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16">
                <h1 className="text-5xl md:text-6xl font-light mb-6">Choose your support level</h1>
                <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                  Each plan offers unique benefits to enjoy the artistic creation up close
                </p>
              </div>

              <SubscriptionTiers />
            </div>
          </section>

          <SubscriptionComparison />

          <SubscriptionPolicies />

          <SubscriptionFAQDynamic />

          <section className="py-20 px-6 bg-accent/10 border-t border-accent/20">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-4xl font-light mb-6">Ready to get started?</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Select your plan above to start your subscription. Your support begins immediately.
              </p>
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground font-medium h-12">
                Go to Plans
              </Button>
            </div>
          </section>
        </>
      )}
    </div>
  )
}
