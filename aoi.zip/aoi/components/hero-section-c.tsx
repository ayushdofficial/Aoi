"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ArrowDown, Users, Award } from "lucide-react"
import Image from "next/image"

export function HeroSectionC() {
  const [email, setEmail] = useState("")
  const [isSubmitted, setIsSubmitted] = useState(false)

  const [timeLeft, setTimeLeft] = useState({
    days: 45,
    hours: 12,
    minutes: 30,
    seconds: 0,
  })

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 }
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 }
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, minutes: 59, seconds: 59 }
        } else if (prev.days > 0) {
          return { ...prev, days: prev.days - 1, hours: 23, minutes: 59, seconds: 59 }
        }
        return prev
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      setIsSubmitted(true)
    }
  }

  const scrollToTrust = () => {
    const element = document.getElementById("trust-section-c")
    element?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative min-h-screen flex flex-col justify-center items-center px-6 py-20 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <Image
          src="/beautiful-ceramic-pottery-art-kintsugi-gold.jpg"
          alt="Ceramic art background"
          fill
          className="object-cover"
          quality={90}
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/65 to-black/70" />
      </div>

      {/* Decorative vertical line */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-32 bg-gradient-to-b from-transparent via-accent to-transparent animate-pulse z-10"
        style={{ animationDuration: "3s" }}
      />

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* Japanese character */}
        <div className="mb-8 animate-fade-in-scale">
          <span className="text-8xl md:text-9xl font-light text-accent opacity-80">金</span>
        </div>

        <div
          className="flex items-center justify-center gap-2 mb-6 animate-fade-in-up bg-accent/10 backdrop-blur-sm border border-accent/30 rounded-lg py-3 px-6 inline-block"
          style={{ animationDelay: "0.1s", opacity: 0, animationFillMode: "forwards" }}
        >
          <Award className="w-5 h-5 text-accent" />
          <p className="text-base text-white">
            Artista <span className="text-accent font-semibold">certificado</span> en Kintsugi Japonés
          </p>
        </div>

        <div
          className="flex items-center justify-center gap-2 mb-6 animate-fade-in-up"
          style={{ animationDelay: "0.15s", opacity: 0, animationFillMode: "forwards" }}
        >
          <Users className="w-5 h-5 text-accent" />
          <p className="text-base text-white">
            Más de <span className="text-accent font-semibold">1,200 personas</span> confían en este proyecto
          </p>
        </div>

        <p
          className="text-base md:text-lg uppercase tracking-[0.3em] text-white/80 mb-6 animate-fade-in-up"
          style={{ animationDelay: "0.2s", opacity: 0, animationFillMode: "forwards" }}
        >
          Cerámica · Arte · Kintsugi
        </p>

        <h1
          className="text-5xl md:text-6xl lg:text-8xl font-light leading-tight mb-8 text-balance animate-fade-in-up text-white"
          style={{ animationDelay: "0.4s", opacity: 0, animationFillMode: "forwards" }}
        >
          Transforma el silencio
          <span className="block text-accent font-medium">en oro</span>
        </h1>

        <p
          className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto mb-8 leading-relaxed text-pretty animate-fade-in-up"
          style={{ animationDelay: "0.6s", opacity: 0, animationFillMode: "forwards" }}
        >
          Un puente cultural de cerámica entre México y Japón. Acompáñame en este viaje donde las fracturas no se
          ocultan, sino que se iluminan.
        </p>

        <div
          className="mb-8 animate-fade-in-up"
          style={{ animationDelay: "0.7s", opacity: 0, animationFillMode: "forwards" }}
        >
          <p className="text-sm uppercase tracking-widest text-white/60 mb-4">Lanzamiento en</p>
          <div className="flex justify-center gap-4">
            {[
              { value: timeLeft.days, label: "Días" },
              { value: timeLeft.hours, label: "Horas" },
              { value: timeLeft.minutes, label: "Min" },
              { value: timeLeft.seconds, label: "Seg" },
            ].map((item, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="bg-white/10 backdrop-blur-sm border border-accent/40 rounded-sm px-4 py-3 min-w-[70px]">
                  <span className="text-3xl md:text-4xl font-bold text-accent">
                    {String(item.value).padStart(2, "0")}
                  </span>
                </div>
                <span className="text-xs text-white/60 mt-2 uppercase tracking-wider">{item.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div
          className="animate-fade-in-up"
          style={{ animationDelay: "0.8s", opacity: 0, animationFillMode: "forwards" }}
        >
          {!isSubmitted ? (
            <>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto mb-4 justify-center">
                <Button
                  onClick={scrollToTrust}
                  className="h-14 px-8 text-lg bg-accent hover:bg-accent/90 text-accent-foreground transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-accent/40"
                >
                  Descubre por qué confían
                </Button>
                <Button
                  variant="outline"
                  className="h-14 px-8 text-lg border-white/30 text-white hover:bg-white/10 transition-all duration-300 bg-transparent"
                >
                  Ver galería
                </Button>
              </div>

              <p className="text-base text-white/70 mt-6">Sin compromisos. Solo transparencia y arte.</p>
            </>
          ) : (
            <div className="bg-accent/20 border border-accent/30 rounded-lg p-6 max-w-md mx-auto animate-success-notification">
              <p className="text-xl font-medium text-white">¡Gracias!</p>
              <p className="text-white/80 mt-2">Pronto recibirás noticias de este viaje.</p>
            </div>
          )}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce z-10">
        <ArrowDown className="w-6 h-6 text-white/60" />
      </div>
    </section>
  )
}
