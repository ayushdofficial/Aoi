<!-- Version B: Testimonios - Optimized for testimonial focus -->
<section class="hero-section" style="background: linear-gradient(135deg, var(--cream) 0%, var(--muted) 100%);">
    <div class="container hero-content">
        <p style="text-transform: uppercase; letter-spacing: 0.2em; color: var(--accent); margin-bottom: 1rem;">Cerámica · Arte · Kintsugi</p>
        <h1 class="hero-title">Testimonios que inspiran</h1>
        <p class="hero-subtitle">Descubre lo que otros dicen sobre el arte de transformar lo roto en belleza</p>
        <div style="display: flex; gap: 16px; justify-content: center; flex-wrap: wrap; margin-top: 32px;">
            <a href="https://www.patreon.com/aoi_kitsune" target="_blank" class="btn btn-primary btn-lg">Únete en Patreon</a>
            <button onclick="document.querySelector('[data-testimonials]').scrollIntoView({behavior: 'smooth'})" class="btn btn-outline btn-lg">Ver testimonios</button>
        </div>
    </div>
</section>

<section class="section" data-testimonials style="background: white;">
    <div class="container">
        <div class="section-header">
            <h2 class="section-title">Voces de la comunidad</h2>
            <p class="section-subtitle">Lo que dicen quienes ya apoyan este proyecto</p>
        </div>
        <div class="tiers-grid">
            <div class="tier-card">
                <div style="display: flex; gap: 12px; margin-bottom: 16px;">
                    <div style="width: 48px; height: 48px; border-radius: 50%; background: var(--muted);"></div>
                    <div>
                        <div style="font-weight: 600;">María G.</div>
                        <div style="font-size: 0.875rem; color: var(--muted-foreground);">Mecenas desde 2024</div>
                    </div>
                </div>
                <p style="color: var(--muted-foreground); line-height: 1.6;">"Apoyar a Daniel no es caridad. Es invertir en una visión del mundo que solo un artista neurodivergente puede ofrecer."</p>
            </div>
            <div class="tier-card">
                <div style="display: flex; gap: 12px; margin-bottom: 16px;">
                    <div style="width: 48px; height: 48px; border-radius: 50%; background: var(--muted);"></div>
                    <div>
                        <div style="font-weight: 600;">Carlos M.</div>
                        <div style="font-size: 0.875rem; color: var(--muted-foreground);">Mecenas desde 2023</div>
                    </div>
                </div>
                <p style="color: var(--muted-foreground); line-height: 1.6;">"Ver el proceso detrás de cada pieza es mágico. Daniel transforma la arcilla con una sensibilidad única."</p>
            </div>
            <div class="tier-card">
                <div style="display: flex; gap: 12px; margin-bottom: 16px;">
                    <div style="width: 48px; height: 48px; border-radius: 50%; background: var(--muted);"></div>
                    <div>
                        <div style="font-weight: 600;">Ana R.</div>
                        <div style="font-size: 0.875rem; color: var(--muted-foreground);">Mecenas desde 2024</div>
                    </div>
                </div>
                <p style="color: var(--muted-foreground); line-height: 1.6;">"Su viaje a Japón será transformador. Me emociona ser parte de algo tan especial y auténtico."</p>
            </div>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/sections/gallery'); ?>
<?php get_template_part('template-parts/sections/story'); ?>
<?php get_template_part('template-parts/sections/email-capture'); ?>
<?php get_template_part('template-parts/sections/faq'); ?>
