import { HeroSectionH } from "@/components/hero-section-h"
import { FeaturesShowcaseH } from "@/components/features-showcase-h"
import { TechSpecsH } from "@/components/tech-specs-h"
import { StorySection } from "@/components/story-section"
import { ComparisonSectionH } from "@/components/comparison-section-h"
import { GallerySectionOptimized } from "@/components/gallery-section-optimized"
import { CTASectionH } from "@/components/cta-section-h"
import { FAQSection } from "@/components/faq-section"
import { TrustSection } from "@/components/trust-section"

export function PageVersionH() {
  return (
    <>
      <HeroSectionH />
      <FeaturesShowcaseH />
      <TechSpecsH />
      <StorySection />
      <ComparisonSectionH />
      <GallerySectionOptimized />
      <CTASectionH />
      <FAQSection />
      <TrustSection />
    </>
  )
}
