"use client"

import { useState } from "react"
import { SubscriptionStep1VersionI } from "./subscription-step-1-version-i"
import { SubscriptionStep2 } from "./subscription-step-2"
import { SubscriptionStep3 } from "./subscription-step-3"

export default function PageVersionI() {
  const [step, setStep] = useState(1)
  const [email, setEmail] = useState("")
  const [planId, setPlanId] = useState("")

  return (
    <div>
      {step === 1 && <SubscriptionStep1VersionI onNext={setEmail} />}
      {step === 2 && <SubscriptionStep2 email={email} onNext={setPlanId} onBack={() => setStep(1)} />}
      {step === 3 && <SubscriptionStep3 email={email} planId={planId} onBack={() => setStep(2)} />}
    </div>
  )
}
